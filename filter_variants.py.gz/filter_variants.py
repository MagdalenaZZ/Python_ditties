#!/usr/bin/env python
from __future__ import print_function
import argparse
import sys
#import math
#import re
import os
import json
import gzip
import pysam
import re

"""

Script for filtering a somatic VCF file based on json annotation

"""


epi = ('\
    \n\
    Script for filtering a somatic VCF file based on json annotation\nApplies Genomics England five filtering criteria. \n\
    Example usage (default filters):  python ~/bin/Python_ditties/filter_variants.py -j somatic.annotation.json.gz -v somatic.normalised.vcf.gz  \n\
    Example usage (custom filters):  python ~/bin/Python_ditties/filter_variants.py -j somatic.annotation.json.gz -v somatic.normalised.vcf.gz -hp 10 -sr False -n 1 \n\
    The filters above resets H-flag from 8 to 10 (more lenient), sets N-flag to the max (1) thereby disabling that filter, and sets SR-flag to false, so that filter will not be applied\n\
    Further information about the filters are in the Technical information \n\
    https://www.genomicsengland.co.uk/information-for-gmc-staff/cancer-programme/cancer-genome-analysis/ \n\
    \n\
    The output file *.filter can be used for bcftools annotation. bgzip *filter; tabix -s1 -b2 -e2 *.filter.gz; bcftools annotate -a *filter.gz -h header.line -c CHROM,FROM,INFO/G,INFO/H,INFO/N,INFO/R,INFO/SR \n\
    See bcftools documentation for further support to construct header and other options\n\
    \n\
    The right VCF file for input should be found at a position somewhat reminiscent of: \n\
    /genomes/analysis/singlesample/LP3XXXXX/*/vcf_cleanup_somatic/*/2/output/LP*.duprem.left.split.reheadered.vcf.gz \n\
    The right json file for input may be found somewhere that looks like this, but is not available for all samples:\n\
    /genomes/bertha-prod/analysis/singlesample/LP3XXXXXX/*/index_somatic_variants/*/1/output/LP*.duprem.left.split.json.gz\n\
    \n\
    The custom filters have not been extensively tested\n\n\n\
')


# Describe what the script does
parser = argparse.ArgumentParser(description='This script parses a json tiering file and applies custom filtering', epilog= epi, formatter_class=argparse.RawTextHelpFormatter)

# Get inputs
parser.add_argument('-j', '--json', default=None, dest='jso', action='store', required=True,  help="json file")
parser.add_argument('-v', '--vcf', default=None, dest='vcf', action='store', required=False, help="Somatic VCF file")
parser.add_argument('-g', '--germline', default=0.01, dest='gco', action='store', required=False, help="Germline cut-off, range:0-1, default >0.01")
parser.add_argument('-hp', '--homopolymer', default=8, dest='hco', action='store', required=False, help="Homopolymer cut-off, appr 0-100, default>=8")
parser.add_argument('-n', '--noise', default=0.1, dest='nco', action='store', required=False, help="Indel noise cut-off, range:0-1, default >0.1")
parser.add_argument('-r', '--repeat', default=0.05, dest='rco', action='store', required=False, help="Indel noise cut-off, range:0-1, default >0.05")
parser.add_argument('-sr', '--simple_repeat', default='True', dest='srco', action='store', required=False, help="Simple repeat annotation, default = True")

# Check for no input
if len(sys.argv)==1:
    parser.print_help()
    sys.exit(1)

args  = parser.parse_args()

# Check if input files exist
if not os.path.isfile(args.jso)==True:
    print("Cannot find input file ", args.jso)
    sys.exit(1)

# Check if input files exist
if not os.path.isfile(args.vcf)==True:
    print("Cannot find input file ",args.vcf)
    sys.exit(1)

# Make output vcf
output=args.vcf+".filtered.vcf"
outfil=args.vcf+".filtered"
of = open(outfil, 'w')
# Make srco boolean
srco=True
if re.match( "false" ,args.srco, re.IGNORECASE):
    srco=False
elif re.match( "true" ,args.srco, re.IGNORECASE):
    srco=True
else:
    print ('Please set -sr to True or False, you set it to: ',args.srco)
    quit()

# Read input and save the filter for each variant
filter={}

with gzip.open(args.jso, 'rb') as f:
    for line in f:
        j = json.loads(line)
        filts = ""

        # Create a position and unique variant identifier
        pos = "0"
        ref='N'
        alt='N'
        try:
            pos = int(j['studies'][0]['files'][0]['call'].split(':')[0])
        except:
            pos=str(j['start'])
            pass
        try:
            ref=j['studies'][0]['files'][0]['call'].split(':')[1]
            alt = j['studies'][0]['files'][0]['call'].split(':')[2]
            #print ("Found call", ref, alt)
        except:
            ref=j['reference']
            alt=j['alternate']
        pos = str(pos) + '_' + ref + '_' + alt
        #print(pos, ref, alt)
        #pos = pos + "_" + str(j['alternate'])

        # This is the H-flag
        h = 0
        hval=0
        try:
            hval=j['studies'][0]['files'][0]['attributes']['IHP']
            hval=int(hval)
            if hval >= int(args.hco):
                h=1
                filts=filts + 'H'
        except:
            pass

        # This is the N-flag
        n = 0
        nval=0
        try:
            #print("try N")
            # Get position in format that has the sought values
            fdp50pos= [i for i, x in enumerate(j['studies'][0]['format']) if x == 'FDP50']
            dp50pos= [i for i, x in enumerate(j['studies'][0]['format']) if x == 'DP50']
            fdp50=j['studies'][0]['samplesData'][0][fdp50pos[0]]
            dp50=j['studies'][0]['samplesData'][0][dp50pos[0]]
            #print("try N", dp50pos, fdp50pos, dp50, fdp50 )
            if fdp50 != '.':
                indel_noise = float(fdp50) / float(dp50)
                nval = round(indel_noise, 6)
            if float(nval) > float(args.nco):
                n=1
                filts = filts + 'N'
        except:
            pass

        # This is the G-flag
        g = 0
        gval=0
        try:
            gval=j['annotation']['additionalAttributes']['GEL.GL.6628']['attribute']['AF']
            gval=float(gval)
            if gval > float(args.gco):
                g=1
                filts = filts + 'G'
                #print("FiltG",filts)
        except:
            pass

        # This is the R-flag
        r=0
        rvalm=0
        try:
            rval=j['annotation']['additionalAttributes']['somatic_agg_vcf']['attribute'].values()
            if any(float(i) >= args.rco for i in rval):
                r=1
                filts = filts + 'R'
            rvalm=max(rval)
        except:
            pass

        # This is the SR-flag
        sr=0
        try:
            #print ("Try SR", srco)
            if j['annotation']['repeat'][0]['source'] == 'trf':
                if srco==True:
                    sr = 1
                    filts = filts + 'SR'

            # There can be multiple repeat annotations, so if the first didnt check out, look at all
            else:
                srvals=[]
                for i in j['annotation']['repeat']:
                    srvals.append(dict(i)['source'])
                if any('trf' == i for i in srvals):
                    sr = 1
                    filts = filts + 'SR'
        except:
            pass

        # Summarise filter


        if not j['chromosome'] in  filter:
            filter[j['chromosome']]={}
        if not pos in  filter[j['chromosome']]:
            if n+g+h+r+sr >=1:
                filter[j['chromosome']][pos] = filts
        chr='chr'+j['chromosome']
        print (chr, pos.split('_')[0], gval, hval, nval,rvalm, sr, filts, sep='\t', file=of)

of.close()

# Now read in the VCF, and apply the filtering

# read the input file, and prepare output VCF
myvcf = pysam.VariantFile(args.vcf, "r")
vcf_out = pysam.VariantFile(output, 'w', header=myvcf.header)

# Add the new HP format to all samples
for r in myvcf:
    chr=r.chrom.translate(None, 'chr')
    #print (chr, r.pos,r.filter.items()[0][0])

    # Remove all non-pass variants
    if r.filter.items()[0][0]=="PASS":

        if chr in filter:
            var = str(r.pos) +  "_" + str(r.ref) + "_" + str(r.alts[0])
            #print (var)
            if var in filter[chr]:
                #r.id=filter[chr][var]
                #r.qual=1
                vcf_out.write(r)
            else:
                vcf_out.write(r)
        else:
            vcf_out.write(r)

vcf_out.close()

quit()



# The original flag annotation from cellbase

def annotate_simple_repeat(variant, cellbase_client):
    """
    Annotate if variant overlaps a simple repeat
    :type variant: GelVariant
    :param variant: variant
    :type cellbase_client: CellBaseClient
    :param cellbase_client: pycellbase client
    """

    # Getting variant id
    if isinstance(variant.alternateBases, list):
        alternate = variant.alternateBases[0]
    else:
        alternate = variant.alternateBases
    var = '{chrom}:{pos}:{ref}:{alt}'.format(
        chrom=variant.referenceName, pos=variant.start + 1,
        ref=variant.referenceBases, alt=alternate
    )

    # Annotating flag if variant overlaps a simple repeat
    vc = cellbase_client.get_variant_client()
    vtext = variant.info['additionalTextualVariantAnnotations']
    result = vc.get_annotation(var, assembly='grch38')[0]['result'][0]
    if 'repeat' in result:
        for repeat in result['repeat']:
            if repeat['source'] == 'trf':
                vtext['simple_repeat'] = 'SR'
                break


def annotate_somatic_prep_freqs(variant):
    """
    Annotate flags for GEL preparation method frequencies
    :type variant: GelVariant
    :param variant: variant
    """
    textual, numeric = variant.annotation.get_custom_annotation(
        {'somatic_agg_vcf': ['AF_FFPE', 'AF_FFpcrfree', 'AF_FFnano']}
    )
    for key in numeric:
        value = float(numeric[key])
        variant.info['additionalNumericVariantAnnotations'][key] = value
        if value > 0.05:
            variant.info['additionalTextualVariantAnnotations'][key] = 'R'


def annotate_germline_freqs(variant):
    """
    Annotate flags for GEL germline frequencies
    :type variant: GelVariant
    :param variant: variant
    """
    textual, numeric = variant.annotation.get_custom_annotation(
        {'GEL.GL.6628': ['AF']}
    )
    for key in numeric:
        value = float(numeric[key])
        variant.info['additionalNumericVariantAnnotations'][key] = value
        if value > 0.01:
            variant.info['additionalTextualVariantAnnotations'][key] = 'G'


def annotate_ihp(variant, vcf_variant_info):
    """
    Annotate flag for IHP (largest reference interrupted homopolymer length
    intersecting with the indel)
    :type variant: GelVariant
    :param variant: variant
    :type vcf_variant_info: dict
    :param vcf_variant_info: INFO field from the original VCF record
    """
    ihp = (int(vcf_variant_info['IHP']) if 'IHP' in vcf_variant_info else None)
    variant.info['IHP'] = ihp
    if ihp is not None:
        variant.info['additionalNumericVariantAnnotations']['IHP'] = int(ihp)
        if 'IHP' in variant.info['additionalTextualVariantAnnotations']:
            del variant.info['additionalTextualVariantAnnotations']['IHP']
        if ihp >= 8:
            variant.info['additionalTextualVariantAnnotations']['IHP'] = 'H'


def annotate_indel_noise(variant, sample_info):
    """
    Annotate flag for indel in the regions with high levels of sequencing noise
    :type variant: GelVariant
    :param variant: variant
    :type sample_info: dict
    :param sample_info: INFO field from the original VCF record
    """

    vtext = variant.info['additionalTextualVariantAnnotations']
    vnum = variant.info['additionalNumericVariantAnnotations']
    if 'FDP50' in sample_info and 'DP50' in sample_info:
        fdp50, dp50 = sample_info['FDP50'][0], sample_info['DP50'][0]
        if fdp50 != '.':
            indel_noise = float(fdp50) / float(dp50)
            vnum['indel_noise'] = round(indel_noise, 6)
            if indel_noise > 0.1:
                vtext['indel_noise'] = 'N'




# return filtered output


