#! python3
import igraph
from igraph import *

# Create graph 
g = Graph()


# Add 3 nodes, these are implicitly named 0,1,2
g.add_vertices(3)

# Add edges between the nodes
g.add_edges([(0,1), (1,2)])

# Do more 
g.add_edges([(2, 0)])
g.add_vertices(3)
g.add_edges([(2, 3), (3, 4), (4, 5), (5, 3)])
print(g)


# Delete an edge
# First get its id
g.get_eid(2, 3)
# Then delete it
g.delete_edges(3)


# Little network
g3 = Graph([(0,1), (0,2), (2,3), (3,4), (4,2), (2,5), (5,0), (6,3), (5,6)])

g3.vs["name"] = ["Alice", "Bob", "Claire", "Dennis", "Esther", "Frank", "George"]
g3.vs["age"] = [25, 31, 18, 47, 22, 23, 50]
g3.vs["gender"] = ["f", "m", "f", "m", "f", "m", "m"]
g3.es["is_formal"] = [False, False, True, True, True, False, True, False, False]


# Check the attribute and change it
g.es[0].attributes()
g.es[0]["is_formal"] = True

# Select a layout and plot
layout = g3.layout("kamada_kawai")
plot(g3, layout = layout)

# Make prettier
g3.vs["label"] = g3.vs["name"]
color_dict = {"m": "blue", "f": "pink"}
g3.vs["color"] = [color_dict[gender] for gender in g3.vs["gender"]]
plot(g3, layout = layout, bbox = (300, 300), margin = 20)

# Make very pretty
visual_style = {}
visual_style["vertex_size"] = 20
visual_style["vertex_label_angle"] = 20
visual_style["vertex_label_distance"] = 20
visual_style["vertex_color"] = [color_dict[gender] for gender in g3.vs["gender"]]
visual_style["vertex_label"] = g3.vs["name"]

visual_style["edge_width"] = [1 + 2 * int(is_formal) for is_formal in g3.es["is_formal"]]
visual_style["layout"] = layout
visual_style["bbox"] = (300, 300)
visual_style["margin"] = 20
plot(g3, **visual_style)


# Save the plot
plot(g, "social_network.pdf", **visual_style)


# Own graph
g = Graph()
g.add_vertices(6)
g.add_edges([(1, 4)])
g.add_edges([(2, 5)])
g.add_edges([(3, 2)])
g.add_edges([(1, 2)])
g.vs["name"] = ["o","A","B","C","D","E"]
plot(g, **visual_style)

# Mapping data

g = Graph()
g.add_vertices(2271)


g.vs["name"] = ["ABC.pl","Ace","Ace::Object","Ace::Sequence","AssemblyMapper::BlastzAligner","BEGIN","BLAT2GFF.pl","BLAT_controller.pl","Best_BLAST_Objects","Bio::AlignIO","Bio::DB::Fasta","Bio::EnsEMBL::AltAlleleGroup","Bio::EnsEMBL::Analysis","Bio::EnsEMBL::ApiVersion","Bio::EnsEMBL::Attribute","Bio::EnsEMBL::Chromosome","Bio::EnsEMBL::Clone","Bio::EnsEMBL::Compara::DBSQL::DBAdaptor","Bio::EnsEMBL::Compara::GenomeDB","Bio::EnsEMBL::Compara::Method","Bio::EnsEMBL::Compara::SpeciesSet","Bio::EnsEMBL::Compara::Utils::MasterDatabase","Bio::EnsEMBL::CoordSystem","Bio::EnsEMBL::DBEntry","Bio::EnsEMBL::DBSQL::DBAdaptor","Bio::EnsEMBL::DBSQL::DBConnection","Bio::EnsEMBL::DBSQL::SimpleFeatureAdaptor","Bio::EnsEMBL::DBSQL::SliceAdaptor","Bio::EnsEMBL::Exon","Bio::EnsEMBL::FeaturePair","Bio::EnsEMBL::Gene","Bio::EnsEMBL::IdMapping::Archiver","Bio::EnsEMBL::IdMapping::Cache","Bio::EnsEMBL::IdMapping::ExonScoreBuilder","Bio::EnsEMBL::IdMapping::GeneScoreBuilder","Bio::EnsEMBL::IdMapping::InternalIdMapper","Bio::EnsEMBL::IdMapping::ResultAnalyser","Bio::EnsEMBL::IdMapping::ScoredMappingMatrix","Bio::EnsEMBL::IdMapping::StableIdMapper","Bio::EnsEMBL::IdMapping::SyntenyFramework","Bio::EnsEMBL::IdMapping::TranscriptScoreBuilder","Bio::EnsEMBL::Pipeline::Analysis","Bio::EnsEMBL::Pipeline::DBSQL::DBAdaptor","Bio::EnsEMBL::Pipeline::Runnable::Blat","Bio::EnsEMBL::Pipeline::SeqFetcher::OBDAIndexSeqFetcher","Bio::EnsEMBL::Pipeline::SeqFetcher::Pfetch","Bio::EnsEMBL::Production::DBSQL::DBAdaptor","Bio::EnsEMBL::RawContig","Bio::EnsEMBL::Registry","Bio::EnsEMBL::SeqFeature","Bio::EnsEMBL::SeqRegionSynonym","Bio::EnsEMBL::SimpleFeature","Bio::EnsEMBL::Slice","Bio::EnsEMBL::Transcript","Bio::EnsEMBL::Translation","Bio::EnsEMBL::Utils::CliHelper","Bio::EnsEMBL::Utils::ConfParser","Bio::EnsEMBL::Utils::ConfigRegistry","Bio::EnsEMBL::Utils::ConversionSupport","Bio::EnsEMBL::Utils::Exception","Bio::EnsEMBL::Utils::IO::FileFaidx","Bio::EnsEMBL::Utils::IO::GTFSerializer","Bio::EnsEMBL::Utils::Logger","Bio::EnsEMBL::Utils::TranscriptSelector","Bio::EnsEMBL::Variation::DBSQL::DBAdaptor","Bio::Graphics::Wiggle","Bio::Graphics::Wiggle::Loader","Bio::LocatableSeq","Bio::Location::Simple","Bio::Location::SplitLocationI","Bio::PrimarySeq","Bio::Root::RootI","Bio::Seq","Bio::SeqFeature::Tools::IDHandler","Bio::SeqFeature::Tools::TypeMapper","Bio::SeqFeature::Tools::Unflattener","Bio::SeqIO","Bio::SimpleAlign","Bio::Tools::Blat","Bio::Tools::Run::Alignment::Muscle","Bottom_frame","CDS.pl","CDS_table","CGI","CRC64","CarryOver.pl","CheckPredictedGenes","CheckSize","Check_current_version","Class","Clone2Acc","CloneTests","Cmd","Config::IniFiles","Config::Tiny","Coords_converter","CoreCreation::Conf","CoreCreation::Fasta","CreateCosmidDirStructure","CreateFile4CopyDBoverServer.pl","Cwd","DBBackupandCompare","DBD::mysql","DBI","DB_File","DESTROY","DNA_revcomp","DNA_string_reverse","Data::Compare","Data::Dumper","DateTime","DbWrite","Dump_Subseq.pl","Dump_new_prot_only.pl","Dumper","EMBL_Sequencefetch.pl","EMBLdump.pl","EMBLsubmit.pl","EMBLupdate.pl","EXAMPLE.use_mapping.pl","E_registry.pl","English","Entity1","Entity2","Expect","FTP_versions","Feature_mapper","FileHandle","FindBin","Force","GAF","GD::Graph::lines","GDBM_File","GENEACE::EMBL_feature_parser","GENEACE::GGeneace","GENEACE::Geneace","GFF","GFF_CDS_with_accessions","GFF_clones_with_accessions","GFF_genes_with_accessions","GFF_method_dump.pl","GFF_post_process.pl","GFF_with_UTR","GFF_with_acc","GFFmunger.pl","GFFsplitter.pl","GSI","GeneID_updater.pl","Geneace","GenomeBrowser::JBrowseDisplay","GenomeBrowser::RnaseqHub","GetInterPro_motifs.pl","GetPFAM_motifs.pl","GetRepeatInfo","Getopt::Std","HTML::Entities","HTTP::Date","HTTP::Request","IKMC_get_data.pl","IO::Dir","IO::File","IO::Handle","IO::String","IO::Uncompress::Gunzip","IPC::Open2","JSON","KEGG.pl","LSF","LSF::JobManager","LWP::Simple","LWP::UserAgent","Log::Any::Adapter","Map_pos_GFFprocess.pl","MaskSequence","Middle_frame","Modules::AGR","Modules::CDS","Modules::CarryOver","Modules::Curate","Modules::EBI_datafetch","Modules::Features","Modules::GFF_feature","Modules::Isoformer","Modules::Map_Helper","Modules::Overlap","Modules::PWM","Modules::Physical_map","Modules::RNASeq","Modules::Remap_Sequence_Change","Modules::SequenceObj","Modules::Strand_transformer","Modules::Transcript","Modules::WBSRS","Modules::map_Alleles","MyUtilLib","MysqlPair","NStest.pl","NameDB","NameDB_handler","Nameserver.pl","Net::FTP","New","Old","Overlap.pl","PCR_product2Genome.pl","PFAM_active_sites.pl","POSIX","PrepareCosmidSubmission","PrintHelp","ProductionMysql","RNASeq_Study.ini_update.pl","RNASeq_align.pl","RNASeq_align_job.pl","RNASeq_cleanup.pl","RNASeq_determine_strandedness.pl","RNASeq_edit_config_files.pl","RNASeq_find_TSL.pl","RNASeq_intron_parser.pl","RNASeq_make_analysis_objects.pl","RNASeq_status.pl","RNASeq_update_config_files.pl","RNAi2Genome.pl","Remap_wig","Reset","RunBlat","RunBlat.pl","SangerWeb","Sequence_extract","SingleSequenceMap","Socket","Species","SpeciesFtp","Spreadsheet::WriteExcel","Status","Storable","Submit","Sys::Hostname","TEST_BUILD)ratherthan","TSL_table","TSLcheck.pl","Term::ANSIColor","Term::ReadKey","Text::Wrap","TextANSIColor","Tie::IxHash","Time::Piece","Time::localtime","Tk","Tk::Dialog","Tk::DialogBox","Tk::FileDialog","Tk::SplitFrame","Top_frame","TransferDB.pl","Transposon_sync.pl","URI::Escape","Update_Biotype.pl","WBGene_span.pl","WbpsExpression","Website::Utilities::Mail","WormBase","WormBase2Ensembl","WormBaseConf","Wormbase","Wormy","XML::LibXML","XML::LibXML::Reader","XML::Simple","X_mapping","XrefMapper::BasicMapper","XrefMapper::CoordinateMapper","XrefMapper::CoreInfo","XrefMapper::DirectXrefs","XrefMapper::DisplayXrefs","XrefMapper::OfficialNaming","XrefMapper::ProcessMappings","XrefMapper::ProcessPaired","XrefMapper::ProcessPrioritys","XrefMapper::RNACentralMapper","XrefMapper::SubmitMapper","XrefMapper::TestMappings","XrefMapper::UniParcMapper","XrefMapper::XrefLoader","XrefMapper::db","XrefParser::BaseParser","XrefParser::ProcessData","YAML","_add_flattened_SeqFeatures","_all_dbs","_check_gene","_check_name","_check_strain","_check_var","_cmd_line_to_array","_crc64","_feature_flip","_getVariation_byOtherName","_get_variationId","_host","_hostname_opts_from_config","_incrementGFF3ID","_init","_next_name","_postprocess","_run_table_maker","_set_opts_from_hostname","_setup_dir","_sql_dir","_store","about","accession","acdeb2nameDB.pl","ace","ace_output","acecompress.pl","acediff.pl","acezip.pl","activate_text","add","addData","addFlyData","addWormData","add_RG_header_to_BAM_file","add_additional_qualifiers","add_canvas","add_collection_db","add_compara_db","add_creation_events_for_current_and_not_archived_or_mapped_genes","add_elegans_aliases_to_gff.pl","add_evidence","add_generic_id","add_ikmc_as_simple_features.pl","add_info_to_MassSpec_GFF.pl","add_kill_events_for_archived_and_not_current_or_mapped_genes","add_last_rev","add_link_events_for_mapped_genes","add_link_events_for_unmapped_genes_matching_ids","add_name","add_ncrna_data","add_new_species_web_data_to_prod_db.pl","add_nonrna_data","add_orthologs_to_ftp.pl","add_pseudo_data","add_quick_entry","add_rem","add_remark","add_rnacentral_xrefs","add_row","add_seq_region_synonyms.pl","add_species_db","add_species_to_BLAT_GFF.pl","add_status_line","add_text","add_to_feature","addname","addscore","addtoGFF","agp2dna.pl","agp2fasta.pl","agp_files","agr_orthologs.pl","agrxref","align","align_by_clone_identity.pl","align_nonident_regions.pl","align_nonident_regions_wrapper.pl","allcmid","alt_alleles.pl","amend_history_convert","analyse","analyse_results","analysis_setup.pl","and_make_embl_files","any_current_live_genes","append_splits_files","append_supplementary_files","archive","archive_builddir.pl","archive_where_seq_changed","args","assemblies_for_taxon.pl","assign_external_db_ids.pl","assign_new_ids","assign_orientation.pl","assign_stable_ids","atcg.pl","attach_other_nematode_ests.pl","autoace_builder.pl","autodie","backup_db","backup_table","backup_tables","batch_BLAT.pl","batch_addname.pl","batch_delName.pl","batch_features.pl","batch_genefind.pl","batch_genes.pl","batch_id_history.pl","batch_kill.pl","batch_merge.pl","batch_new.pl","batch_newfeature.pl","batch_pname_update.pl","batch_split.pl","batch_transcript_build.pl","batch_variation_merge.pl","batch_variation_new.pl","batch_variations.pl","bestname","blast_TC1_seq","blast_builder.pl","blast_kill_list.pl","blastfilter.pl","blastp_dump","blastx_dump.pl","blastx_store.pl","blat","blat2ace.pl","blat_them_all.pl","bless_prediction","box_merge","bsubmit","build_cache_all","build_cache_auto","build_cache_by_seq_region","build_chain_mappings","build_dumpGFF.pl","build_insert_sql","build_light.pl","build_pepace.pl","build_release","build_release_files.pl","build_scores","build_search_struct","build_webdb.pl","buildrelease","byRelease","calc_RPKM.pl","calc_mean","calc_median","calculate_dinucleotides","calculate_mononucleotides","caltech","camace_nameDB_comm.pl","camcheck.pl","can_use_key","capture_user_input","cds2gene.pl","cgc_allele_parser.pl","cgc_dump.pl","cgc_strain_parser.pl","change_DNA_in_db","change_assembly_tags","change_cds","change_chromosome_length_on_chrom","change_class","change_clone_length_on_superlink","change_clone_overlaps","change_clone_to_left","change_confirmed_intron","change_exons","change_feature_data_on_chrom","change_feature_data_on_clone","change_feature_data_on_superlink","change_feature_method","change_flanking_sequences","change_group","change_homol_data_on_chrom","change_homol_data_on_clone","change_homol_data_on_superlink","change_name","change_superlink_length_on_chrom","change_transcript","change_transcripts_to_noncoding.pl","changed_swissprot_proteins.pl","changegene.pl","check","check4bigstuff.pl","checkData","check_DNA.pl","check_EMBL_submissions.pl","check_TSL_site","check_allele_mapping.pl","check_and_shatter","check_cgc","check_class.pl","check_class_tags.pl","check_classes_and_ids","check_command_line_options","check_complete","check_data","check_date","check_details","check_dubious_multi_pt_2_locus.pl","check_dubious_multipt_gene_connections","check_evidence","check_existing","check_exit_status","check_fate_of_gene","check_flipped","check_for_backup_table","check_for_convert","check_for_duplicate","check_for_existing_Feature","check_for_missing_data","check_for_missing_data2","check_for_missing_tags","check_for_tables","check_gene","check_genes.pl","check_genetics_coords_mapping","check_go_term","check_homol_size.pl","check_if_DB_contains_DNA","check_if_replacing","check_is_pipeline_db","check_its_worked","check_loci_in_out_in_DfDp.pl","check_make_autoace","check_manifest","check_mapping.pl","check_md5sum","check_mysql","check_name_exists","check_non_redundant","check_non_translations","check_operons","check_options","check_opts","check_other_name_and_seq_ver","check_other_name_in_mapping_data.pl","check_overlap_right","check_overlapping_features","check_polyA_signal","check_polyA_site","check_predicted_genes.pl","check_primary_database.pl","check_protein_ID.pl","check_script","check_sequence_inheritance.pl","check_sequence_span","check_sequence_version","check_split_camaces.pl","check_start_and_stop","check_superlink_sequence","check_superlinks.pl","check_the_file","check_translation","check_translations","check_unique_genomic_from_Bargmann_lab","check_user","check_var","check_worm_transcripts","checkchars","checkfile","checksum","choice_to_string","choose_best_cluster","choose_best_gene","chromosome_dump.pl","chromosome_script_lsf_manager.pl","chunk_reads","cigar2ace","cigar_to_almost_cigar","class_summary","classes","classify","clean_blasts","clean_dna_align_features","clean_input_ids","clean_old_results","clean_out_mlss_data","clean_previous_output","clean_tmpfiles","cleanse_gff.pl","cleanup","cleanup_tmp_tables.pl","clear","clear_cloned","clear_cloned_prop","clear_current_dir","clear_data","clear_dbh","clear_down","clear_evi","clear_gen","clear_gene","clear_last_rev","clear_nonRNAdata","clear_proposed","clear_pseudo_data","clear_rem","clear_tables","clear_up","clear_up_down_window","clone_gene","clustal_runner.pl","cluster_gene_connection.pl","codon_to_seq","collate_and_sort","command_chosen","comment_sf","compara_tests.pl","compare","compare_assemblies.pl","compare_backups","compare_cds","compare_chromosomes","compare_displays.pl","compare_docs_against_current_staging.pl","compare_exons","compare_features","compare_genes","compare_mapping.pl","compare_results.pl","compare_scores","compare_scores.pl","compare_transcripts","compare_translations","compare_xrefs_by_source.pl","composition","compress","concatenate_gff","config","confirm","confirm_case","confirm_genes.pl","confirm_introns","confirm_message","connect_to_database","conservation_statistics.pl","conv","convert_all_tables","convert_chromblast2clone.pl","convert_date","convert_protein_coords_to_chrom_coords","convert_seqstore.pl","convert_tables_MyISAM_InnoDB.pl","convert_to_geneID","convert_to_name","convert_to_wdb","convert_xrefs_to_all_translations.pl","coords_lookup.pl","copy2acari","copy_acedb_files","copy_annotations_files","copy_assembly_manifest","copy_blastx","copy_dna_files","copy_est_files","copy_files_to_acari.pl","copy_gff_files","copy_homol_data","copy_multi_species","copy_ontology_files","copy_release_letter","copy_report_files","copy_rna_files","copy_to_gxa_staging_area.pl","copy_worm_proteins","copy_wormpep_files","core_vega_link_check.pl","correlate_Protein_IDs.pl","count","countUniquePeptides","count_class","count_classes","count_isoforms","crc64fasta.pl","createDB","create_currentDB_loci_pages","create_db","create_exons","create_gene","create_index","create_log_files","create_mapping_session","create_md5sum","create_ortholog_flatfiles.pl","create_public_name_data","create_release_tasks.pl","create_seq_obj","create_split_wormpep","create_stable_id_events","create_ticket","create_transcript_file","create_ucsc_chains","create_windows_and_lbl","create_wormbase_conf.pl","createdirs","cufflinks2ace.pl","curate.pl","curate_test","current_DB_check.pl","current_dir","data","data_checks.pl","data_submission","data_upload","date","date_convert","datomic_check_classes.pl","db-space.pl","db_backup_and_compare.pl","db_connect","dbcomp.pl","dbfetch.pl","dbh","dbxref","dbxrefP","dbxrefS","debug","defaults","delete","delete_anomalies","delete_existing","delete_from_tables","delete_gene_by_translation","delete_genes.pl","delete_incorrect_orthology","delete_results","delete_tables","delete_text","detectdifference","determine_deleted","determine_last_vers","diagnostics","diff","dna_files","do_a_quick_test","do_analysis_check","do_assembly_stuff","do_chromosome","doc_for_assembly.pl","doesnt_match_an_old_gene_name","draw_graph","drop_backup_tables","dry","dump","dump.pl","dumpData","dump_BLAT_ace_data","dump_BLAT_data","dump_TRF.pl","dump_alaska_ids.pl","dump_all","dump_all_clustal.pl","dump_blastp_from_file.pl","dump_blastx.pl","dump_by_seq_region.pl","dump_cache.pl","dump_cdna2orf.pl","dump_citindex.pl","dump_clustal.pl","dump_confirmed_genes.pl","dump_data","dump_dna","dump_existing_events","dump_feature","dump_gene","dump_geneid_list.pl","dump_genome.pl","dump_get_Sequences","dump_gff","dump_gff.pl","dump_gff3.pl","dump_gff_batch.pl","dump_gpi.pl","dump_gpiv2.pl","dump_gtf_from_ensembl.pl","dump_gtf_from_gff3.pl","dump_interpolated.pl","dump_interpro_motif.pl","dump_ko.pl","dump_me","dump_molecules.pl","dump_motif.pl","dump_mysql.pl","dump_oligo_sets_from_ensembl.pl","dump_pairwise.pl","dump_pcr_list.pl","dump_primary_seq_data.pl","dump_promoters.pl","dump_protein_domains.pl","dump_protein_features.pl","dump_protein_features_gff.pl","dump_proteins.pl","dump_repeats.pl","dump_resource_laboratory_designations.pl","dump_scores","dump_scores.pl","dump_sdb","dump_species_functional_descriptions.pl","dump_species_gene_interactions.pl","dump_species_orthologs.pl","dump_sql_to_path","dump_swissprot.pl","dump_transcripts.pl","dump_translations","dump_translations.pl","dumpace","embl_header","emit_canonical_encodings.pl","empty_out_old_gene_set","ena_entry_version","ens_genome_xrefs.pl","ensembl2gtf_lite.pl","ensembl_assembly_to_chain.pl","ensembl_blat.pl","ensembl_genblast.pl","ensembl_to_ucsc_name","ensembldoxygenfilter.pl","entry_dialog","eradicateSingleBaseDiff","erase_isoforms","error","error_warning","est_star_hive.pl","execute_ace_command","exon","exon_conservation_check.pl","exons_to_codons","expr_store.pl","expression_data_from_tiling_array.pl","extra_build_checks","extract_attribute","extract_canonical_geneset.pl","fake_stable_id_mapping.pl","fasta","fasta2agp.pl","fasta2gsi.pl","fasta_dumper.pl","fastq","fastq_to_fasta","feature2ace","feature_finder","feature_server.pl","feature_store.pl","fetch_EMBL_seqs_for_blatting.pl","fetch_artificialintrons","fetch_assembly","fetch_attrib_type_id_by_code","fetch_balancers","fetch_cds2proteinid","fetch_cds2status","fetch_chromosome_lengths","fetch_clone2dbid","fetch_clone2type","fetch_current_data","fetch_database_info","fetch_features","fetch_gene2names","fetch_geneclass2desc","fetch_genes_lacking_pmap_coords","fetch_markers","fetch_motifs","fetch_selenoproteins","fetch_seqs_for_blatting.pl","fetch_trans2dbremark","fetch_transcript2briefid","fetch_transcript2gene","fetch_transcript2type","file","filter","filter_RNASeq_splice","filter_features","filter_hits","find_and_make_backups","find_anomalies.pl","find_author","find_changed_part_of_region","find_database","find_duplicate_clones.pl","find_entity","find_extent","find_gene","find_incomplete_pfam_motifs","find_intergenic.pl","find_match","find_match.pl","find_out_of_date_gene_id","find_overlaps.pl","find_seqfeature","find_short_genes.pl","find_strain","find_transcript","find_utrs.pl","find_var","find_variation","fingerprint_db.pl","finish","finish_build.pl","fix","fix_asm_overlaps.pl","fix_case","fix_cmp_overlaps.pl","fix_gene_spans.pl","fix_geneace_orthologs.pl","fix_interpolation.pl","fix_overlaps.pl","fix_treefam_from_ace.pl","flipCigarReference","footer","forum_check.pl","found_match","found_nomatch","frameshift_transcript_attribs.pl","fuller_test_genome_9_chr20.pl","further_BLAST_dump.pl","fuzzy_mode","gaf_from_gpad","gaf_to_gpad.pl","gatherDOdata","gen_perc_file.pl","genbank2gff.pl","genbank2gff3.pl","genbank_contigs_2_ace.pl","gene_ID","gene_class","gene_expression","gene_features","gene_mapping","gene_name","gene_stats.pl","gene_store.pl","geneace_check.pl","geneace_nameDB_Straincomm.pl","geneace_nameDB_Varcomm.pl","geneace_nameDB_comm.pl","geneace_patch.pl","geneclass_loci_other_name","genefinder.pl","genefinder2ace.pl","generate_OMIMXREF_query","generate_OMIM_xref.pl","generate_RRDID_query","generate_RRDIDvar_query","generate_RRID_data.pl","generate_accession_query","generate_coding_query","generate_data_from_fasta","generate_dbxref_file.pl","generate_disease_class.pl","generate_files_for_UCSC.pl","generate_gene_query","generate_gff","generate_gff_report.pl","generate_noncoding_query","generate_similarity_events","generate_stable_ids.pl","generate_xref_mindmap.pl","genes_by_lifestage.pl","genestats.pl","genome-changes.pl","getConservationScores.pl","getCurrentDate_dir","getPrefix","getProteinID.pl","getSourceInfo","getSwissGeneName","getSwissTrembldata.pl","get_1_site_flanks","get_2_site_flanks","get_30_bp_flanks","get_30bp_flank_seq","get_3_site_flanks","get_60bp_left_to_EMBL_coord","get_Analysis","get_CDSs","get_CRC64_checksum.pl","get_EMBL","get_EMBL_data.pl","get_EMBL_info.pl","get_EST_differences","get_EST_split_merged","get_GI.pl","get_GO_acc_to_term","get_GO_stats","get_Ignore","get_LG_from_strain_in_Locus_obj","get_NOT_Database","get_NS_ids.pl","get_Pseudogenes","get_RNA_bork_list","get_RNAi_from_gff","get_SRA_details","get_Slice","get_TC1_flanks.pl","get_TF","get_TFs","get_TSL_RNASeq_reads.pl","get_acc_to_id_map","get_accession","get_accession2","get_active_splits","get_adaptor","get_address","get_all_GenBlast_analyses","get_all_SeqFeatures","get_all_allele_ids_table_maker","get_all_alleles","get_all_blat_analyses","get_all_elegans_orthologues.pl","get_allele_flank_seq.pl","get_allele_flank_seq_multiple.pl","get_allele_flanking_seqs_TK.pl","get_alleles","get_amplified_info","get_anatomy","get_and_change","get_assemblies_for_taxon","get_assembly","get_assembly_mappings","get_best_CDS_matches","get_bgi","get_brief_id_query","get_candidate_genes","get_cds_confirmation_status","get_cds_details","get_cds_from_protein","get_cds_history","get_cds_name","get_cds_to_wormpep","get_cgc_name_changed_details","get_cgc_orthologs.pl","get_changed_cgc_names.pl","get_checked_confirmed_introns","get_chemical_ontology_id","get_chrom_details","get_chrom_length","get_chromosomes","get_classes_and_ids_to_check","get_clone_info","get_clone_len","get_clone_sequence","get_clone_sizes.pl","get_closest_gene","get_codon_flanks","get_colour","get_commondata","get_commondata_for_core_species","get_composition","get_condition_details","get_condition_relations","get_confirmed","get_confirmed_introns","get_contig_name","get_controls","get_coord_systems_in_order()","get_coords","get_curation_stats","get_current_timestamp","get_current_versions","get_data","get_date","get_db_connection","get_db_remark_query","get_db_version","get_deleted","get_dependent_analysis","get_desc","get_details","get_domains","get_easy_phenotypes.pl","get_embl_data","get_ena_dbh","get_ena_submission_xrefs.pl","get_equal_blat_chrom_span","get_est_mismatches","get_event","get_evidence","get_experiment_details","get_expression","get_expression_outside_transcripts","get_extdb_names","get_family_name_data","get_feat_coord_systems","get_feature_blocks","get_feature_evidence","get_feature_flanking_sequences","get_feature_id","get_feature_logics","get_file","get_filehandle","get_flanking_loci","get_flanking_sequences","get_flanking_sequences.pl","get_flanking_sequences_simple.pl","get_flanks","get_frameshifts","get_from_date","get_from_protein_id","get_gaf_line","get_genblastg_different_to_curated_CDS","get_gene_class_query","get_gene_data","get_gene_id","get_gene_ids.pl","get_gene_ids_ebiprod.pl","get_gene_longest_transcript","get_gene_name_query","get_gene_stable_id","get_gene_start","get_gene_start_ends","get_genes","get_genome_features","get_genome_mapping","get_genotype","get_highest_stable_id","get_history_version","get_id","get_ignored_EST_data","get_info","get_initial_frame","get_initial_table_def","get_input_arg","get_insdc_date","get_interpro","get_introns_refuted_by_est","get_ipi_ensembl_map","get_isolated_RST5","get_isolated_TSL","get_jigsaw_different_to_curated_CDS","get_jigsaw_with_signalp","get_lab","get_landmark_genes","get_latest_schema_build","get_life_stage","get_liftover_mappings","get_loaded_species","get_location","get_location_data","get_loci","get_logic2analysis","get_logic_names_hash","get_map_data","get_masking_data","get_mass_spec_homols_from_ace","get_matched_exons","get_matched_repeatmasker","get_matching_nematode_est","get_max_intron_size","get_max_intron_size.pl","get_max_mapping_set_id","get_max_stable_id_from_gene_archive","get_method","get_mirna_data","get_modencode_different_to_curated_CDS","get_modencode_with_signalp","get_mol_weight","get_molecular_consequences","get_multi_gene_loci","get_multiple_utr_introns","get_ncrna_type_query","get_new","get_new_cgc_details","get_next_GO_annotation_id","get_next_gene","get_non_core_species_EST.pl","get_not_predicted_by_mgene","get_novel_mgene_predictions","get_old_new_feature","get_omim2ensemblprotein.pl","get_omim_tm_def","get_omim_to_wormbase_gene_mapping","get_one2oneTrees.pl","get_operon_data","get_options","get_orthologs","get_orthos","get_paper","get_paper_bork_list","get_paper_json","get_paper_stuff","get_parent_key","get_pcr","get_pcr_products","get_pfam.pl","get_pfam_sites_from_ace","get_phenotype","get_phylup_data","get_pi_email.pl","get_pmid","get_post_translational_feats_from_ace","get_premature_stop","get_prev_count","get_prev_dat","get_previous_dbname","get_previous_two_versions","get_previous_wormpep_ids","get_protein","get_protein_details","get_protein_differences","get_protein_from_cds","get_protein_history","get_protein_id","get_protein_id_query","get_protein_ids_ebiprod.pl","get_protein_match_data","get_protein_split","get_protein_split_merged","get_protein_xrefs.pl","get_public_name","get_read_coverage","get_regexp_of_database_names","get_remark","get_removed","get_repeatmasked_chroms.pl","get_retired_cgc_details","get_reverse_assembly_mappings","get_rnai2lab","get_rnai_sequences","get_rnaseq_merged","get_scaffold_lengths_for_core_db","get_scaffold_lengths_from_report_url","get_schema_and_build","get_secondary_table_def","get_seq","get_seq_region_checksum","get_seq_region_data","get_seq_region_id","get_seq_region_ids","get_sequence_text","get_sequence_versions_ebiprod.pl","get_sequences","get_sequences_gff.pl","get_sex","get_short_exons","get_short_introns","get_species","get_species_data","get_splice_flanks.pl","get_spurious_introns","get_sql","get_status_query","get_strain","get_study_description","get_study_details","get_study_display","get_supercontig_name","get_synonym","get_table_maker_def","get_tace","get_tag","get_temperature","get_text","get_timestamp","get_tissue","get_tm_def","get_transcript_id","get_transcripts","get_translation_for_transcript","get_translation_id","get_treatment","get_treefam.pl","get_twinscan_split_merged","get_unattached_EST","get_unattached_TSL","get_unconfirmed_RNASeq_introns","get_unconfirmed_introns","get_unconfirmed_mass_spec_introns","get_uniprot","get_uniprot_dbh","get_unmatched_454","get_unmatched_SAGE","get_unmatched_ests","get_unmatched_genefinder_exons","get_unmatched_mass_spec_peptides","get_unmatched_mgene_exons","get_unmatched_twinscan_exons","get_unmatched_waba_coding","get_until_date","get_updated_database_list","get_variation_ids.pl","get_versions","get_weak_exon_splice_sites","get_whitelist","get_wormbase_go_terms","get_wormpep","get_wormpep_by_wp_id","get_wormpep_history","get_wormpep_history_proteins","get_xref","get_xrefs","getfiles","getseq","getswalldata","getsynteny.pl","gff2feature_data.pl","gff32ensembl_simple.pl","gff3ace.pl","gff_files","gff_header","gff_line","gff_string","gff_validate","go_public","goto_anomaly","goto_anomaly_window","goto_intron","goto_location","grab_disease_variations","grab_ids","group_gff_entities.pl","has_current_history","has_karyotype","header","healthcheck.pl","help","help_authentication","hinxton","history_maker.pl","human_peps2dmp.pl","id_adddomain.pl","id_addname.pl","id_addtype.pl","id_delname.pl","id_find.pl","id_init.pl","id_listdomains.pl","id_listtypes.pl","id_ls.pl","id_mapping.pl","id_newid.pl","id_resurrect.pl","id_stat.pl","id_uniquify","id_unmerge.pl","id_validate","ignore_anomaly","ignore_anomaly_window","ignore_bad_blat_alignments.pl","import_AGR_gene_objects.pl","import_bed_simple_feature.pl","import_recombinant_hotspots.pl","inactivate_text","incorporate_EMBL_names.pl","increment_gene_versions","increment_stable_id","index_fasta.pl","index_feature","inflate_conf.pl","info","info_person","inherit_GO_terms.pl","ini_to_json.pl","ini_to_species.pl","init","init_check","init_db","initialise","initialise_tiles","initiate_build.pl","inks.pl","insert_analysis","insert_key","insert_meta","insert_mtDNA","inspect-old-releases.pl","int_map_to_map_loci","interface","interpolate_gff.pl","interpolate_gmap2pmap.pl","interpolation_manager.pl","intersect_gff.pl","inverted.pl","is_authorised","is_bad_term","is_view","isoformer.pl","jbrowse_tracks_and_hub.pl","justGeneName","karyotype_rank_assigner.pl","karyotype_to_Slices","key_by_cgc","kill_ft","kill_gene","kill_people","kill_process_by_db.pl","kill_strain","kill_var","kill_variation","landmark_genes2gff.pl","last","last_versions","launch_geneace.pl","line","line_to_SimpleFeature","list_backup_counts","list_counts","list_of_matched_genes","list_of_matched_genes_by_seqname","list_table_counts","list_xrefs.pl","load","load2database.pl","load_EST_data","load_alternative_assembly.pl","load_analysis_descriptions.pl","load_anomalies.pl","load_anomalies_gff_file.pl","load_assembly","load_autoace","load_blat2db.pl","load_curation_data","load_data","load_data_sets.pl","load_database_from_ftp_site.pl","load_exceptions","load_exlusions","load_feature_mappings.pl","load_features","load_file","load_files_in_dir.pl","load_genes","load_ids","load_input_ids","load_interpolated_map.pl","load_isoformer_method","load_it","load_meta_table","load_multiple_databases.pl","load_panther_xrefs.pl","load_patch_fix_to_ref.pl","load_refseq_xrefs.pl","load_related_data_from_Build_to_geneace.pl","load_rules","load_sequence","load_species","load_uniprot_brief_ids.pl","loadace","loci_map_panel","log10","log_blat","log_cache_stats","log_file","logging","lookup_from_ebi_production_dbs","lookup_gene","lsfsubmit.pl","mail_author","mail_geneace","mail_reminder","main","main_gene_checks","makeChromLinks.pl","makeENSgenes","make_EMBL_unfinished.pl","make_FTP_sites.pl","make_GO_GAF.pl","make_GTF_transcript.pl","make_Interpro2GO_mapping.pl","make_UTR","make_UTR_GFF.pl","make_accession_list","make_acefiles.pl","make_agp_file.pl","make_agr_AGM.pl","make_agr_DAF.pl","make_agr_HTS.pl","make_agr_allele_json.pl","make_agr_basic_gene_json.pl","make_agr_construct_json.pl","make_agr_disease_json.pl","make_agr_expression_json.pl","make_agr_genetic_interaction_psimitab.pl","make_agr_gff.pl","make_agr_interactions_psimitab.pl","make_agr_phenotype_json.pl","make_analysis_xml","make_anatomy_GAF.pl","make_assembly_manifest.pl","make_autoace.pl","make_backup_table","make_bam_xml.pl","make_canvases","make_changes","make_changes_to_DNA","make_common_data.pl","make_con_from_segs","make_disease_GAF.pl","make_embl_cds","make_embl_file","make_enhancer_features.pl","make_ests","make_extras","make_fpkm","make_gene_lists","make_hash","make_history","make_input_ids","make_interpro.pl","make_isoforms.pl","make_keysets.pl","make_life_stage_expression.pl","make_lifestage_GAF.pl","make_mass_spec_ace.pl","make_md5sums","make_missing_tsl_features.pl","make_mrnas","make_multipt_obj","make_ncrnas","make_nematode_ests","make_new_feature","make_old_wormpep_hash","make_oligo_set_mapping_table.pl","make_parasite_FTP_site.pl","make_phenotype_GAF.pl","make_phenotype_GO_GAF.pl","make_pseudo_map_positions.pl","make_remap_data","make_slices","make_start_codon_features","make_stop_codon_features","make_submission_xml","make_symlinks_to_wormbase_species","make_vars.txt.pl","make_web_blast.pl","make_wormpep.pl","make_wormrna.pl","make_yeastpepfile.pl","makechromosomes.pl","makesuperlinks.pl","manage_id_mapping_tables.pl","many_lines_text","map","map_Alleles","map_Alleles.pl","map_Interaction.pl","map_Oligo_set.pl","map_PCR_products.pl","map_RNAi.pl","map_Y2H.pl","map_alleles","map_feature2gene.pl","map_features","map_features.pl","map_features_to_genome","map_gff_fails.pl","map_microarray.pl","map_nematode_contigs.pl","map_operons.pl","map_peptides_to_protein","map_sage_tag","map_sage_tag_genome","map_slice","map_tags.pl","map_tec-reds.pl","map_tec_red","map_to_gene()","map_translated_features_to_genome.pl","map_types","map_with_epcr","map_with_ipcress","mapping_conf.pl","mapping_stats.pl","maptags2gff","mark_deleted","marker_table","markup","mass_spec_table_maker_def","match","match_sequence","match_tsl","matches","matches_an_old_gene_name","matches_an_old_gene_name_as_an_isoform","md5check.pl","mean","median","merge","merge_all_species.pl","merge_cmp_gaps.pl","merge_gene","merge_genes","merge_hashes","merge_near_duplicates","merge_split_camaces.pl","merge_variation.pl","meta_coord_query","meta_levels.pl","mk_command","modify_sql","molecular_names_for_genes.pl","motif_dump","move_cgc_name.pl","move_schild_to_top_level.pl","move_to_pseudo","move_translation_fasta","multidb_sql.pl","mysql_cmd","name_change","nameserver_json.pl","ncbi_karyotype","new","new_Slice","new_ft","new_gene","new_genome_acedb.pl","new_people","new_strain","new_var","new_variation","new_wormpep_entries.pl","newgene.pl","next_builder_checks.pl","no_underscore","norm_seq","not_expected_to_be_undefined","not_usually_missing","noupdate","now","object_count.pl","oldStyleName","one_line_text","ontologies","open_TCP","open_TCP_connection","open_ace_file","open_command_line","open_gff_file","open_update_file","operon_store.pl","optimise_table","opts","order_ends","ortholog_name_transferer.pl","other_name_table","our_ini.pl","output_History","output_Species_Wormpep","output_changed_cgc","output_further_details","output_list","output_seq","output_to_database","overlap","overlapcheck.pl","overload_GFF_CDS_lines.pl","overload_gff_blat_species.pl","overload_gff_cds_wormpep.pl","overload_gff_gene.pl","overload_gff_genomic.pl","overload_gff_marker_positions.pl","overload_gff_mass_spec.pl","overload_gff_miRNA.pl","overload_gff_operon.pl","overload_gff_pcr_product.pl","overload_gff_rnai.pl","overload_gff_sage.pl","overload_gff_tf.pl","overload_gff_transposon.pl","overload_gff_variation.pl","p_value","pad","paper_tm_def","paper_tm_query","parse_IPI_human.pl","parse_NBP_alleles.pl","parse_SO_obo.pl","parse_allele_info_from_paper.pl","parse_briggsae_data","parse_brugia_data","parse_config","parse_contig","parse_contigs","parse_data","parse_deleted_files","parse_elegans_homol_data","parse_embl.pl","parse_expr_pattern_new.pl","parse_file","parse_files","parse_flatfile.pl","parse_genBlastG","parse_genes","parse_go_terms_new.pl","parse_homol_data","parse_inner_hierarchy","parse_location","parse_log.pl","parse_misc_elegans_files","parse_nematode_seqs","parse_omim_flatfile","parse_out_parent_sequences","parse_phenotype_new.pl","parse_predicted_tRNA.pl","parse_probe_to_gene_map","parse_probename_file","parse_psl","parse_remanei_data","parse_sofa.pl","parse_supercontigs_file","parse_table","parse_tickets_file","parse_wormpep_history","parseconfig","pass_check","pc","people.pl","permissions","pfam_sites_table_maker_def","physical_map_stuff","ping_ensembl.pl","pk_to_EMBL.pl","pmatch.pl","pname_update.pl","populate_anomaly_window_list","populate_genome_spreadsheet.pl","populate_meta_coord.pl","populate_stable_id_lookup.pl","populate_zero_weight_list","populated_archive","pos.pl","pos_underscore","position_change_DNA_in_db","position_make_changes_to_DNA","post_build_checks.pl","post_merge_steps","post_process_gff3.pl","post_request","pre_ftp_dumps.pl","prepare","prepare_DBXREF_data.pl","prepare_conf_and_fasta.pl","prepare_data_folder.pl","prepare_db","prepare_gdb","prepare_modelorganism_data.pl","prepare_mysql","prepare_primary_databases.pl","printAllNames","print_DAF_column_headers","print_DAF_header","print_DAF_line","print_ace","print_alignment","print_alleles","print_attribs","print_chains","print_gene","print_gff","print_held","print_history","print_javascript","print_json","print_karyotype","print_lines_sixty","print_names","print_one","print_results","print_selector","print_seq","print_term","printhelp","printtest","process","processGFF.pl","process_allele_class","process_cds","process_cds_class","process_chromosome","process_clones","process_code","process_dba","process_dbs","process_disease_variations","process_elegans_gff-standalone.pl","process_ensembl_2_omim_data.pl","process_feature_class","process_feature_table","process_file","process_gene","process_gene_class","process_gene_data","process_genes","process_genes_in_sequence","process_genes_phenotype","process_gff","process_human","process_laboratory_class","process_matches","process_paper_class","process_proteins","process_pseudogene_class","process_rearrangement","process_results","process_results_simple","process_sage_gff.pl","process_strain_class","process_strain_data","process_swissprot","process_t3_gff.pl","process_transcript_class","process_transgenes","process_trembl","process_uniprot","process_variation_data","process_worm","process_yeast","progress","project_start_ends","promote_omim_data.pl","promote_protein_xrefs_to_gene.pl","propagate_cds_xrefs_to_protein.pl","protein_ID","protein_ID_list_from_camace","protein_checks","protein_multiple_alignments.pl","protein_url","pseud","pseudo_store.pl","ptm_table_maker_def","publish_gmap.pl","purge_duplicates","purge_weakly_supported_transcript_structures","push_align_features.pl","put_anomaly_record_in_database","query","query_ENA","query_with_dna_text","query_with_pcr_product","queue_script","quick_next_cds","quick_tests","quit","raw_compute_transfer.pl","read_GFF_file","read_GFF_queries","read_acedb_queries","read_agp_file","read_agp_files","read_annotation","read_chromosome","read_chromosome()","read_chromosome_file","read_counts","read_data","read_db","read_dir","read_disease_ids","read_doc","read_entry","read_est_orientations","read_fasta","read_file","read_genome","read_genome_fasta","read_gff","read_gff_file","read_history_file","read_ids","read_input_file","read_json","read_mappings","read_matrix","read_old_build","read_positions_file","read_remove","read_seq_region","read_stranded_hits","read_templates","read_uberron","readhits","reason_changes.pl","recent_changes.pl","record_anatomy_term_name","record_go_term_name","record_lifestage_term_name","reformat","register_complete","reinitdb","release_letter.pl","release_summary.pl","remap_chromosome_homol_data.pl","remap_clone_feature_data.pl","remap_clone_homol_data.pl","remap_expression.pl","remap_file","remap_fosmids_between_releases.pl","remap_genefinder_between_releases.pl","remap_gff_between_releases.pl","remap_mass_spec_between_releases.pl","remap_misc_dynamic","remap_twinscan_between_releases.pl","remap_variation_gff_between_releases.pl","remap_wig.pl","remember_gene_extents","remove_WBGene_from_acefile.pl","remove_bogus_features","remove_cgc_gene","remove_cgc_names","remove_data","remove_data_light","remove_genes_with_paper_evidence","remove_masked_files","remove_mysqldb.pl","remove_name","remove_other_species","remove_pariah_gene","remove_selfhits","remove_tiling_data","remove_unwanted_GFF_lines.pl","rename_cds.pl","reorder_exons.pl","repeat-libraries.pl","repeat-types.pl","repeat_dump","replace_placeholders","report_gene_data","reset","reset_Force","restructure_mirnas.pl","results","resurrect_ft","resurrect_gene","resurrect_strain","resurrect_var","resurrect_variation","retrieve_subsequence","rev_comp","reverseO","reverse_cigar","reweight_anomalies","right_shift","right_tip","rnai_store.pl","rnaseq.pl","rnaseq_assign_strand.pl","rotate","run","run.pl","runTSLcheck","run_bsub","run_command","run_component","run_details","run_exonerate.pl","run_genefinder.pl","run_inverted.pl","run_mapping","run_munging_script","run_normal","run_on_dba","run_pepace","run_scripts","run_upload","runestcheck","runintroncheck","runoverlapcheck","same_assembly_names","sampleAge","sampleLocation","sanity_check","sanity_check_features","save_ace_file","save_analysis_accession","save_update_file","save_versions","scaffold_stats","schema_patcher.pl","score","script_template.pl","search","search_dbs.pl","seeker","select_canonical_transcripts.pl","send_mail","separate_gpad_by_species.pl","seq2gene","seqTPs","seq_ace","seq_fix_order","sequence_details","sequence_fetch","sequence_store.pl","set_alleles","set_canonical_transcripts.pl","set_classes","set_codon_table.pl","set_core_samples.pl","set_env","set_exon_phases","set_nonredundant_attribs.pl","set_nr_attribute","set_parameters","set_up_genome","set_web_data_to_default.pl","set_web_output","set_wormbase.pl","setup_PARASITE_CONF_folder.pl","setupdb","shatter.pl","shift_gene_models","shift_locations","short_name","shortintrons2frameshift.pl","shortintrons2frameshifts.pl","show_NS_ids.pl","show_format","show_help","show_method_status.pl","showgene.pl","shrink_trfs.pl","single","single_query_tests","sl1_store.pl","sl2_store.pl","slurp","slurp_in_file","snake","sort_by_feattype","sort_by_gene","sort_by_position","sort_feature_table.pl","sort_gff","sort_gff3.pl","sort_out_hierarchy","sort_table","species_lookup","specific_example","split_alleles.pl","split_blastx_by_centre.pl","split_check","split_databases","split_fasta.pl","split_files","split_gene","split_genome_for_ensembl.pl","split_run","splitgene.pl","splitgene_brig.pl","sql","sql_checks","stage_dump_to_submissions_repository","start_giface_server","start_mapping_session","stats","status_line","stitch_matches","stop_giface_server","store_ccds_xrefs.pl","store_count","store_counts","store_ensembl_xref","store_existing","store_feature_in_tile","store_gene","store_gene_sample","store_on_slices","strings_to_array","suball","submit","submit_and_collate","suggest","suggest_name","suppress_gene","swiss_trembl2dbm.pl","swiss_trembl2slim.pl","synteny_rescore.pl","table_four","table_one","table_three","table_two","tables","tace","tace_it","tace_query","tar_and_feather","teardown_gdb","test.remapwig.pl","test_assembly_mapping.pl","test_code_from_html.pl","test_gene_sequence_for_errors","test_locus_for_errors","test_namedb.pl","test_remap_between_releases.pl","test_xref_mapper.pl","testuser","tidy_up_senseless_records","tier3_stubs.pl","tkcurate.pl","tmpfile_hook","toggle_weighting","track_protein_history.pl","tran_fix_order","transcript","transcript_builder.pl","transcript_data_files","transcriptmasker.pl","transfer","transfer_ensembl_features.pl","transfer_from_motif","transfer_from_rnai_phenotype","transfer_from_tmhmm","transfer_interpro_GO_terms.pl","transfer_karyotype.pl","translate_clone","translation_check.pl","treefam_orthologs.pl","treefam_other_orthologs.pl","type_ace_file","type_update_file","typeorder","undo_merge_genes","undo_split_gene","unflatten_seq","uniprotxrefs.pl","unpack_db.pl","unpack_stuff","update","update_Common_data.pl","update_GO_terms.pl","update_SWALL.pl","update_analysis","update_analysis_entry","update_blastDBs.pl","update_blast_dbs","update_canonical","update_compara_master.pl","update_database","update_dna","update_dnafrags","update_ensembl_orthologs.pl","update_event","update_existing_inferred_multi_pt","update_feature_targets.pl","update_gene","update_geneace.pl","update_hs_protein_list.pl","update_inferred_multi_pt.pl","update_ipi_accession.pl","update_isl_genomes.pl","update_live_release.pl","update_many2one","update_mapping","update_mapping_set.pl","update_meta","update_meta_coord.pl","update_one2many","update_one2one","update_people","update_person.pl","update_proteins","update_rev_physicals.pl","update_strain","update_var","update_variation","update_web_gene_names.pl","upload_ace_GA","upload_ace_test","upload_archive","upload_empc_links.pl","upload_mapping_as_history.pl","upload_mapping_session_and_events","upload_stable_ids","upload_to_ebi","use_chrom_coords","use_superlink_coords","validate_id","validate_user_name","validated","variation_auto_fix.pl","variation_server.pl","variation_server_compare.pl","vega_repeat_libraries.pl","view_gmap","view_rev_physicals","virtual_objects_blat","wait_for_prompt","what_seq_id_is_next.pl","wide_confirm_message","workload.pl","wormBLAST.pl","worm_lite.pl","wormbase","wormbase_core_db_name","wormbase_ftp_dir","wormbase_gene_xrefs.pl","wormbase_gff3","wormbase_to_ensembl.pl","write.swiss_trembl.pl","write_CDS_def","write_CDS_xref_def","write_DAF_column_headers","write_DAF_header","write_DAF_line","write_DB_remark.pl","write_EST","write_Feature","write_GO_annot_def","write_GO_def","write_GO_stats","write_Gene_id","write_Pseudogenes_def","write_TM_def","write_accession","write_ace","write_ace_bottom_level","write_ace_genes","write_ace_lines","write_ace_orthologs","write_ace_top_level","write_amplified_def_file","write_anatomy_def","write_blast_pep","write_cds2cgc","write_cds2protein_id","write_cds2status","write_cds2wormpep","write_cds_confirmation_status","write_clone2accession","write_clone2centre","write_clone2dbid","write_clone2type","write_clone_def_file","write_clone_sequence_date","write_clones2seq","write_clones2sv","write_clonesize","write_config","write_data_for_treefam.pl","write_def_file","write_dna","write_exons","write_fasta","write_feature","write_feature_def","write_file","write_final_pep","write_from_date","write_genes2lab","write_gff_header","write_header","write_interpolated_map_position_query","write_into_db","write_ipi_info.pl","write_life_stage_def","write_mappings","write_method","write_mol_change_def_file","write_motif_def","write_new_orthology","write_output","write_paper_def","write_pep_gff","write_phenotype_def","write_pseudo2cgc","write_ranks","write_rna2BriefID","write_rna2cgc","write_supercontigs","write_table","write_tiles","write_tm_def","write_tm_def_file","write_tm_query","write_transcript_gtf","write_uniprot_def","write_worm_gene2cgc","write_worm_gene2class","write_worm_gene2geneID","write_wormpep_history_and_diff","writeace","xml","xref_config2sql.pl","xref_data_analysis.pl","xref_mapper.pl","xref_parser.pl","xref_tracker.pl","zip_files"]









g.add_edges([(141, 1)])
g.add_edges([(144, 1)])
g.add_edges([(145, 1)])
g.add_edges([(172, 1)])
g.add_edges([(204, 1)])
g.add_edges([(221, 1)])
g.add_edges([(399, 1)])
g.add_edges([(400, 1)])
g.add_edges([(401, 1)])
g.add_edges([(404, 1)])
g.add_edges([(407, 1)])
g.add_edges([(444, 1)])
g.add_edges([(445, 1)])
g.add_edges([(448, 1)])
g.add_edges([(449, 1)])
g.add_edges([(450, 1)])
g.add_edges([(451, 1)])
g.add_edges([(480, 1)])
g.add_edges([(487, 1)])
g.add_edges([(494, 1)])
g.add_edges([(513, 1)])
g.add_edges([(518, 1)])
g.add_edges([(531, 1)])
g.add_edges([(536, 1)])
g.add_edges([(540, 1)])
g.add_edges([(546, 1)])
g.add_edges([(597, 1)])
g.add_edges([(598, 1)])
g.add_edges([(643, 1)])
g.add_edges([(679, 1)])
g.add_edges([(692, 1)])
g.add_edges([(694, 1)])
g.add_edges([(753, 1)])
g.add_edges([(765, 1)])
g.add_edges([(768, 1)])
g.add_edges([(769, 1)])
g.add_edges([(774, 1)])
g.add_edges([(784, 1)])
g.add_edges([(806, 1)])
g.add_edges([(824, 1)])
g.add_edges([(869, 1)])
g.add_edges([(878, 1)])
g.add_edges([(880, 1)])
g.add_edges([(884, 1)])
g.add_edges([(897, 1)])
g.add_edges([(901, 1)])
g.add_edges([(926, 1)])
g.add_edges([(927, 1)])
g.add_edges([(928, 1)])
g.add_edges([(929, 1)])
g.add_edges([(954, 1)])
g.add_edges([(973, 1)])
g.add_edges([(988, 1)])
g.add_edges([(1036, 1)])
g.add_edges([(1064, 1)])
g.add_edges([(1178, 1)])
g.add_edges([(1182, 1)])
g.add_edges([(1226, 1)])
g.add_edges([(1312, 1)])
g.add_edges([(1325, 1)])
g.add_edges([(1337, 1)])
g.add_edges([(1345, 1)])
g.add_edges([(1370, 1)])
g.add_edges([(1401, 1)])
g.add_edges([(1426, 1)])
g.add_edges([(1446, 1)])
g.add_edges([(1449, 1)])
g.add_edges([(1450, 1)])
g.add_edges([(1451, 1)])
g.add_edges([(1458, 1)])
g.add_edges([(1459, 1)])
g.add_edges([(1460, 1)])
g.add_edges([(1461, 1)])
g.add_edges([(1462, 1)])
g.add_edges([(1463, 1)])
g.add_edges([(1464, 1)])
g.add_edges([(1465, 1)])
g.add_edges([(1466, 1)])
g.add_edges([(1468, 1)])
g.add_edges([(1469, 1)])
g.add_edges([(1471, 1)])
g.add_edges([(1472, 1)])
g.add_edges([(1475, 1)])
g.add_edges([(1481, 1)])
g.add_edges([(1484, 1)])
g.add_edges([(1493, 1)])
g.add_edges([(1495, 1)])
g.add_edges([(1496, 1)])
g.add_edges([(1497, 1)])
g.add_edges([(1499, 1)])
g.add_edges([(1506, 1)])
g.add_edges([(1508, 1)])
g.add_edges([(1509, 1)])
g.add_edges([(1510, 1)])
g.add_edges([(1519, 1)])
g.add_edges([(1520, 1)])
g.add_edges([(1522, 1)])
g.add_edges([(1523, 1)])
g.add_edges([(1528, 1)])
g.add_edges([(1529, 1)])
g.add_edges([(1532, 1)])
g.add_edges([(1533, 1)])
g.add_edges([(1535, 1)])
g.add_edges([(1537, 1)])
g.add_edges([(1542, 1)])
g.add_edges([(1547, 1)])
g.add_edges([(1548, 1)])
g.add_edges([(1551, 1)])
g.add_edges([(1568, 1)])
g.add_edges([(1579, 1)])
g.add_edges([(1586, 1)])
g.add_edges([(1587, 1)])
g.add_edges([(1606, 1)])
g.add_edges([(1638, 1)])
g.add_edges([(1642, 1)])
g.add_edges([(1643, 1)])
g.add_edges([(1644, 1)])
g.add_edges([(1646, 1)])
g.add_edges([(1647, 1)])
g.add_edges([(1648, 1)])
g.add_edges([(1649, 1)])
g.add_edges([(1650, 1)])
g.add_edges([(1651, 1)])
g.add_edges([(1652, 1)])
g.add_edges([(1653, 1)])
g.add_edges([(1659, 1)])
g.add_edges([(1677, 1)])
g.add_edges([(1686, 1)])
g.add_edges([(1687, 1)])
g.add_edges([(1705, 1)])
g.add_edges([(1724, 1)])
g.add_edges([(1768, 1)])
g.add_edges([(1769, 1)])
g.add_edges([(1789, 1)])
g.add_edges([(1804, 1)])
g.add_edges([(1814, 1)])
g.add_edges([(1873, 1)])
g.add_edges([(1904, 1)])
g.add_edges([(1905, 1)])
g.add_edges([(1913, 1)])
g.add_edges([(1928, 1)])
g.add_edges([(2022, 1)])
g.add_edges([(2088, 1)])
g.add_edges([(2096, 1)])
g.add_edges([(2108, 1)])
g.add_edges([(2113, 1)])
g.add_edges([(2127, 1)])
g.add_edges([(2130, 1)])
g.add_edges([(2131, 1)])
g.add_edges([(2145, 1)])
g.add_edges([(2149, 1)])
g.add_edges([(2163, 1)])
g.add_edges([(2165, 1)])
g.add_edges([(2173, 1)])
g.add_edges([(2188, 1)])
g.add_edges([(926, 2)])
g.add_edges([(2163, 2)])
g.add_edges([(783, 3)])
g.add_edges([(897, 3)])
g.add_edges([(1904, 3)])
g.add_edges([(364, 4)])
g.add_edges([(365, 4)])
g.add_edges([(812, 5)])
g.add_edges([(387, 7)])
g.add_edges([(1353, 7)])
g.add_edges([(597, 8)])
g.add_edges([(597, 9)])
g.add_edges([(603, 9)])
g.add_edges([(747, 9)])
g.add_edges([(754, 9)])
g.add_edges([(358, 10)])
g.add_edges([(367, 11)])
g.add_edges([(119, 12)])
g.add_edges([(398, 12)])
g.add_edges([(620, 12)])
g.add_edges([(770, 12)])
g.add_edges([(771, 12)])
g.add_edges([(1288, 12)])
g.add_edges([(1334, 12)])
g.add_edges([(1335, 12)])
g.add_edges([(1670, 12)])
g.add_edges([(609, 13)])
g.add_edges([(681, 13)])
g.add_edges([(951, 13)])
g.add_edges([(2120, 13)])
g.add_edges([(363, 14)])
g.add_edges([(907, 14)])
g.add_edges([(823, 15)])
g.add_edges([(925, 15)])
g.add_edges([(1623, 15)])
g.add_edges([(2007, 15)])
g.add_edges([(2008, 15)])
g.add_edges([(823, 16)])
g.add_edges([(925, 16)])
g.add_edges([(1366, 16)])
g.add_edges([(1623, 16)])
g.add_edges([(2007, 16)])
g.add_edges([(2008, 16)])
g.add_edges([(120, 17)])
g.add_edges([(603, 17)])
g.add_edges([(1003, 17)])
g.add_edges([(1025, 17)])
g.add_edges([(1166, 17)])
g.add_edges([(1288, 17)])
g.add_edges([(1981, 17)])
g.add_edges([(1991, 17)])
g.add_edges([(2100, 17)])
g.add_edges([(2101, 17)])
g.add_edges([(2120, 17)])
g.add_edges([(2124, 17)])
g.add_edges([(2120, 18)])
g.add_edges([(2120, 19)])
g.add_edges([(2120, 20)])
g.add_edges([(2120, 21)])
g.add_edges([(1670, 22)])
g.add_edges([(2175, 22)])
g.add_edges([(2179, 23)])
g.add_edges([(119, 24)])
g.add_edges([(120, 24)])
g.add_edges([(339, 24)])
g.add_edges([(348, 24)])
g.add_edges([(367, 24)])
g.add_edges([(371, 24)])
g.add_edges([(381, 24)])
g.add_edges([(398, 24)])
g.add_edges([(415, 24)])
g.add_edges([(416, 24)])
g.add_edges([(510, 24)])
g.add_edges([(615, 24)])
g.add_edges([(620, 24)])
g.add_edges([(642, 24)])
g.add_edges([(719, 24)])
g.add_edges([(762, 24)])
g.add_edges([(766, 24)])
g.add_edges([(770, 24)])
g.add_edges([(787, 24)])
g.add_edges([(788, 24)])
g.add_edges([(798, 24)])
g.add_edges([(800, 24)])
g.add_edges([(803, 24)])
g.add_edges([(807, 24)])
g.add_edges([(808, 24)])
g.add_edges([(810, 24)])
g.add_edges([(818, 24)])
g.add_edges([(823, 24)])
g.add_edges([(838, 24)])
g.add_edges([(907, 24)])
g.add_edges([(924, 24)])
g.add_edges([(925, 24)])
g.add_edges([(1025, 24)])
g.add_edges([(1099, 24)])
g.add_edges([(1143, 24)])
g.add_edges([(1159, 24)])
g.add_edges([(1163, 24)])
g.add_edges([(1198, 24)])
g.add_edges([(1208, 24)])
g.add_edges([(1224, 24)])
g.add_edges([(1288, 24)])
g.add_edges([(1290, 24)])
g.add_edges([(1334, 24)])
g.add_edges([(1335, 24)])
g.add_edges([(1373, 24)])
g.add_edges([(1399, 24)])
g.add_edges([(1411, 24)])
g.add_edges([(1424, 24)])
g.add_edges([(1524, 24)])
g.add_edges([(1581, 24)])
g.add_edges([(1623, 24)])
g.add_edges([(1670, 24)])
g.add_edges([(1812, 24)])
g.add_edges([(1817, 24)])
g.add_edges([(1827, 24)])
g.add_edges([(1927, 24)])
g.add_edges([(1967, 24)])
g.add_edges([(1976, 24)])
g.add_edges([(1980, 24)])
g.add_edges([(1981, 24)])
g.add_edges([(1984, 24)])
g.add_edges([(1991, 24)])
g.add_edges([(1998, 24)])
g.add_edges([(2007, 24)])
g.add_edges([(2008, 24)])
g.add_edges([(2015, 24)])
g.add_edges([(2042, 24)])
g.add_edges([(2072, 24)])
g.add_edges([(2092, 24)])
g.add_edges([(2099, 24)])
g.add_edges([(2120, 24)])
g.add_edges([(2124, 24)])
g.add_edges([(2132, 24)])
g.add_edges([(2174, 24)])
g.add_edges([(2175, 24)])
g.add_edges([(2179, 24)])
g.add_edges([(2181, 24)])
g.add_edges([(339, 25)])
g.add_edges([(2139, 25)])
g.add_edges([(1334, 26)])
g.add_edges([(1335, 26)])
g.add_edges([(620, 27)])
g.add_edges([(1984, 27)])
g.add_edges([(1670, 28)])
g.add_edges([(6, 29)])
g.add_edges([(1399, 30)])
g.add_edges([(1670, 30)])
g.add_edges([(1323, 31)])
g.add_edges([(1323, 32)])
g.add_edges([(1932, 32)])
g.add_edges([(2060, 32)])
g.add_edges([(1323, 33)])
g.add_edges([(1323, 34)])
g.add_edges([(1323, 35)])
g.add_edges([(1323, 36)])
g.add_edges([(791, 37)])
g.add_edges([(2060, 37)])
g.add_edges([(1323, 38)])
g.add_edges([(2060, 39)])
g.add_edges([(1323, 40)])
g.add_edges([(371, 41)])
g.add_edges([(371, 42)])
g.add_edges([(809, 42)])
g.add_edges([(1366, 42)])
g.add_edges([(6, 43)])
g.add_edges([(416, 44)])
g.add_edges([(823, 44)])
g.add_edges([(925, 44)])
g.add_edges([(1623, 44)])
g.add_edges([(1927, 44)])
g.add_edges([(1976, 44)])
g.add_edges([(2007, 44)])
g.add_edges([(2008, 44)])
g.add_edges([(416, 45)])
g.add_edges([(823, 45)])
g.add_edges([(925, 45)])
g.add_edges([(1623, 45)])
g.add_edges([(1927, 45)])
g.add_edges([(1976, 45)])
g.add_edges([(2007, 45)])
g.add_edges([(2008, 45)])
g.add_edges([(821, 46)])
g.add_edges([(1991, 46)])
g.add_edges([(823, 47)])
g.add_edges([(925, 47)])
g.add_edges([(1366, 47)])
g.add_edges([(1623, 47)])
g.add_edges([(2007, 47)])
g.add_edges([(2008, 47)])
g.add_edges([(328, 48)])
g.add_edges([(609, 48)])
g.add_edges([(659, 48)])
g.add_edges([(662, 48)])
g.add_edges([(747, 48)])
g.add_edges([(754, 48)])
g.add_edges([(779, 48)])
g.add_edges([(786, 48)])
g.add_edges([(808, 48)])
g.add_edges([(818, 48)])
g.add_edges([(821, 48)])
g.add_edges([(951, 48)])
g.add_edges([(955, 48)])
g.add_edges([(1143, 48)])
g.add_edges([(1159, 48)])
g.add_edges([(1163, 48)])
g.add_edges([(1335, 48)])
g.add_edges([(1394, 48)])
g.add_edges([(1422, 48)])
g.add_edges([(1551, 48)])
g.add_edges([(1709, 48)])
g.add_edges([(1729, 48)])
g.add_edges([(1967, 48)])
g.add_edges([(1991, 48)])
g.add_edges([(2073, 48)])
g.add_edges([(2120, 48)])
g.add_edges([(2124, 48)])
g.add_edges([(2267, 48)])
g.add_edges([(6, 49)])
g.add_edges([(807, 49)])
g.add_edges([(348, 50)])
g.add_edges([(119, 51)])
g.add_edges([(398, 51)])
g.add_edges([(1334, 51)])
g.add_edges([(1335, 51)])
g.add_edges([(620, 52)])
g.add_edges([(1670, 52)])
g.add_edges([(1670, 53)])
g.add_edges([(1670, 54)])
g.add_edges([(609, 55)])
g.add_edges([(1581, 55)])
g.add_edges([(1907, 55)])
g.add_edges([(2139, 55)])
g.add_edges([(615, 56)])
g.add_edges([(617, 56)])
g.add_edges([(750, 56)])
g.add_edges([(751, 56)])
g.add_edges([(791, 56)])
g.add_edges([(1323, 56)])
g.add_edges([(1524, 56)])
g.add_edges([(1932, 56)])
g.add_edges([(2002, 56)])
g.add_edges([(2060, 56)])
g.add_edges([(120, 57)])
g.add_edges([(818, 57)])
g.add_edges([(1143, 57)])
g.add_edges([(1159, 57)])
g.add_edges([(1991, 57)])
g.add_edges([(363, 58)])
g.add_edges([(364, 58)])
g.add_edges([(365, 58)])
g.add_edges([(521, 58)])
g.add_edges([(577, 58)])
g.add_edges([(605, 58)])
g.add_edges([(828, 58)])
g.add_edges([(882, 58)])
g.add_edges([(894, 58)])
g.add_edges([(896, 58)])
g.add_edges([(900, 58)])
g.add_edges([(1398, 58)])
g.add_edges([(1411, 58)])
g.add_edges([(1424, 58)])
g.add_edges([(1556, 58)])
g.add_edges([(1573, 58)])
g.add_edges([(2072, 58)])
g.add_edges([(2166, 58)])
g.add_edges([(803, 59)])
g.add_edges([(809, 59)])
g.add_edges([(810, 59)])
g.add_edges([(1340, 60)])
g.add_edges([(770, 61)])
g.add_edges([(771, 61)])
g.add_edges([(615, 62)])
g.add_edges([(617, 62)])
g.add_edges([(681, 62)])
g.add_edges([(750, 62)])
g.add_edges([(751, 62)])
g.add_edges([(791, 62)])
g.add_edges([(1323, 62)])
g.add_edges([(1524, 62)])
g.add_edges([(1932, 62)])
g.add_edges([(2002, 62)])
g.add_edges([(2060, 62)])
g.add_edges([(803, 63)])
g.add_edges([(1967, 63)])
g.add_edges([(1411, 64)])
g.add_edges([(1887, 65)])
g.add_edges([(1887, 66)])
g.add_edges([(747, 67)])
g.add_edges([(754, 67)])
g.add_edges([(916, 68)])
g.add_edges([(1670, 68)])
g.add_edges([(916, 69)])
g.add_edges([(357, 70)])
g.add_edges([(560, 70)])
g.add_edges([(832, 70)])
g.add_edges([(878, 70)])
g.add_edges([(1208, 70)])
g.add_edges([(1940, 70)])
g.add_edges([(1366, 71)])
g.add_edges([(358, 72)])
g.add_edges([(917, 72)])
g.add_edges([(1366, 72)])
g.add_edges([(2175, 72)])
g.add_edges([(916, 73)])
g.add_edges([(916, 74)])
g.add_edges([(916, 75)])
g.add_edges([(116, 76)])
g.add_edges([(205, 76)])
g.add_edges([(221, 76)])
g.add_edges([(357, 76)])
g.add_edges([(358, 76)])
g.add_edges([(412, 76)])
g.add_edges([(413, 76)])
g.add_edges([(438, 76)])
g.add_edges([(560, 76)])
g.add_edges([(662, 76)])
g.add_edges([(669, 76)])
g.add_edges([(755, 76)])
g.add_edges([(762, 76)])
g.add_edges([(771, 76)])
g.add_edges([(798, 76)])
g.add_edges([(800, 76)])
g.add_edges([(832, 76)])
g.add_edges([(878, 76)])
g.add_edges([(915, 76)])
g.add_edges([(916, 76)])
g.add_edges([(917, 76)])
g.add_edges([(1208, 76)])
g.add_edges([(1363, 76)])
g.add_edges([(1449, 76)])
g.add_edges([(1519, 76)])
g.add_edges([(1520, 76)])
g.add_edges([(1670, 76)])
g.add_edges([(1940, 76)])
g.add_edges([(2026, 76)])
g.add_edges([(2029, 76)])
g.add_edges([(2081, 76)])
g.add_edges([(2090, 76)])
g.add_edges([(2117, 76)])
g.add_edges([(2175, 76)])
g.add_edges([(747, 77)])
g.add_edges([(754, 77)])
g.add_edges([(221, 78)])
g.add_edges([(597, 79)])
g.add_edges([(2082, 80)])
g.add_edges([(1674, 82)])
g.add_edges([(1593, 83)])
g.add_edges([(970, 84)])
g.add_edges([(445, 86)])
g.add_edges([(1449, 87)])
g.add_edges([(118, 88)])
g.add_edges([(2082, 89)])
g.add_edges([(823, 90)])
g.add_edges([(925, 90)])
g.add_edges([(1623, 90)])
g.add_edges([(1927, 90)])
g.add_edges([(1976, 90)])
g.add_edges([(2007, 90)])
g.add_edges([(2008, 90)])
g.add_edges([(445, 91)])
g.add_edges([(2082, 92)])
g.add_edges([(210, 93)])
g.add_edges([(1346, 93)])
g.add_edges([(1347, 93)])
g.add_edges([(2266, 93)])
g.add_edges([(681, 94)])
g.add_edges([(116, 95)])
g.add_edges([(204, 95)])
g.add_edges([(216, 95)])
g.add_edges([(217, 95)])
g.add_edges([(221, 95)])
g.add_edges([(257, 95)])
g.add_edges([(387, 95)])
g.add_edges([(405, 95)])
g.add_edges([(418, 95)])
g.add_edges([(634, 95)])
g.add_edges([(643, 95)])
g.add_edges([(749, 95)])
g.add_edges([(774, 95)])
g.add_edges([(869, 95)])
g.add_edges([(932, 95)])
g.add_edges([(954, 95)])
g.add_edges([(973, 95)])
g.add_edges([(988, 95)])
g.add_edges([(1226, 95)])
g.add_edges([(1289, 95)])
g.add_edges([(1291, 95)])
g.add_edges([(1312, 95)])
g.add_edges([(1370, 95)])
g.add_edges([(1401, 95)])
g.add_edges([(1451, 95)])
g.add_edges([(1484, 95)])
g.add_edges([(1493, 95)])
g.add_edges([(1497, 95)])
g.add_edges([(1499, 95)])
g.add_edges([(1539, 95)])
g.add_edges([(1547, 95)])
g.add_edges([(1548, 95)])
g.add_edges([(1587, 95)])
g.add_edges([(1687, 95)])
g.add_edges([(1714, 95)])
g.add_edges([(1928, 95)])
g.add_edges([(2088, 95)])
g.add_edges([(1308, 96)])
g.add_edges([(1725, 97)])
g.add_edges([(118, 98)])
g.add_edges([(203, 100)])
g.add_edges([(253, 100)])
g.add_edges([(637, 100)])
g.add_edges([(773, 100)])
g.add_edges([(878, 100)])
g.add_edges([(914, 100)])
g.add_edges([(1006, 100)])
g.add_edges([(1178, 100)])
g.add_edges([(1398, 100)])
g.add_edges([(1446, 100)])
g.add_edges([(1451, 100)])
g.add_edges([(1473, 100)])
g.add_edges([(1604, 100)])
g.add_edges([(1905, 100)])
g.add_edges([(2078, 100)])
g.add_edges([(2109, 100)])
g.add_edges([(2129, 100)])
g.add_edges([(2268, 100)])
g.add_edges([(2270, 100)])
g.add_edges([(445, 101)])
g.add_edges([(952, 102)])
g.add_edges([(2171, 102)])
g.add_edges([(99, 103)])
g.add_edges([(113, 103)])
g.add_edges([(205, 103)])
g.add_edges([(331, 103)])
g.add_edges([(413, 103)])
g.add_edges([(597, 103)])
g.add_edges([(620, 103)])
g.add_edges([(638, 103)])
g.add_edges([(740, 103)])
g.add_edges([(744, 103)])
g.add_edges([(773, 103)])
g.add_edges([(777, 103)])
g.add_edges([(778, 103)])
g.add_edges([(786, 103)])
g.add_edges([(788, 103)])
g.add_edges([(873, 103)])
g.add_edges([(890, 103)])
g.add_edges([(908, 103)])
g.add_edges([(950, 103)])
g.add_edges([(952, 103)])
g.add_edges([(1099, 103)])
g.add_edges([(1198, 103)])
g.add_edges([(1224, 103)])
g.add_edges([(1255, 103)])
g.add_edges([(1312, 103)])
g.add_edges([(1379, 103)])
g.add_edges([(1400, 103)])
g.add_edges([(1401, 103)])
g.add_edges([(1492, 103)])
g.add_edges([(1581, 103)])
g.add_edges([(1590, 103)])
g.add_edges([(1593, 103)])
g.add_edges([(1710, 103)])
g.add_edges([(1809, 103)])
g.add_edges([(1897, 103)])
g.add_edges([(1906, 103)])
g.add_edges([(1965, 103)])
g.add_edges([(1984, 103)])
g.add_edges([(2004, 103)])
g.add_edges([(2097, 103)])
g.add_edges([(2171, 103)])
g.add_edges([(2173, 103)])
g.add_edges([(412, 104)])
g.add_edges([(413, 104)])
g.add_edges([(748, 104)])
g.add_edges([(1658, 104)])
g.add_edges([(2058, 104)])
g.add_edges([(2059, 104)])
g.add_edges([(2182, 104)])
g.add_edges([(2237, 104)])
g.add_edges([(774, 105)])
g.add_edges([(1497, 106)])
g.add_edges([(954, 107)])
g.add_edges([(1359, 107)])
g.add_edges([(610, 108)])
g.add_edges([(199, 109)])
g.add_edges([(438, 109)])
g.add_edges([(837, 109)])
g.add_edges([(839, 109)])
g.add_edges([(858, 109)])
g.add_edges([(887, 109)])
g.add_edges([(958, 109)])
g.add_edges([(1452, 109)])
g.add_edges([(1479, 109)])
g.add_edges([(1542, 109)])
g.add_edges([(1711, 109)])
g.add_edges([(2088, 109)])
g.add_edges([(2112, 109)])
g.add_edges([(1178, 110)])
g.add_edges([(429, 111)])
g.add_edges([(1473, 111)])
g.add_edges([(1599, 111)])
g.add_edges([(2109, 111)])
g.add_edges([(793, 114)])
g.add_edges([(794, 114)])
g.add_edges([(795, 114)])
g.add_edges([(1178, 121)])
g.add_edges([(123, 122)])
g.add_edges([(0, 124)])
g.add_edges([(411, 124)])
g.add_edges([(1731, 125)])
g.add_edges([(216, 126)])
g.add_edges([(973, 126)])
g.add_edges([(1087, 126)])
g.add_edges([(1484, 126)])
g.add_edges([(1499, 126)])
g.add_edges([(1537, 126)])
g.add_edges([(692, 127)])
g.add_edges([(703, 127)])
g.add_edges([(807, 127)])
g.add_edges([(416, 128)])
g.add_edges([(510, 128)])
g.add_edges([(681, 128)])
g.add_edges([(823, 128)])
g.add_edges([(925, 128)])
g.add_edges([(1623, 128)])
g.add_edges([(1812, 128)])
g.add_edges([(1827, 128)])
g.add_edges([(1927, 128)])
g.add_edges([(1976, 128)])
g.add_edges([(2007, 128)])
g.add_edges([(2008, 128)])
g.add_edges([(2099, 128)])
g.add_edges([(2175, 128)])
g.add_edges([(2181, 128)])
g.add_edges([(2082, 129)])
g.add_edges([(1450, 130)])
g.add_edges([(1459, 130)])
g.add_edges([(1471, 130)])
g.add_edges([(1481, 130)])
g.add_edges([(1496, 130)])
g.add_edges([(1508, 130)])
g.add_edges([(1509, 130)])
g.add_edges([(952, 131)])
g.add_edges([(113, 132)])
g.add_edges([(1313, 132)])
g.add_edges([(1521, 132)])
g.add_edges([(973, 133)])
g.add_edges([(531, 134)])
g.add_edges([(451, 135)])
g.add_edges([(494, 135)])
g.add_edges([(694, 135)])
g.add_edges([(926, 135)])
g.add_edges([(1006, 135)])
g.add_edges([(1182, 135)])
g.add_edges([(1337, 135)])
g.add_edges([(1659, 135)])
g.add_edges([(2129, 135)])
g.add_edges([(2145, 135)])
g.add_edges([(2163, 135)])
g.add_edges([(203, 136)])
g.add_edges([(145, 137)])
g.add_edges([(145, 138)])
g.add_edges([(1758, 138)])
g.add_edges([(1758, 139)])
g.add_edges([(1758, 142)])
g.add_edges([(480, 143)])
g.add_edges([(831, 146)])
g.add_edges([(2182, 146)])
g.add_edges([(531, 148)])
g.add_edges([(988, 148)])
g.add_edges([(1371, 149)])
g.add_edges([(1371, 150)])
g.add_edges([(744, 153)])
g.add_edges([(112, 154)])
g.add_edges([(203, 154)])
g.add_edges([(385, 154)])
g.add_edges([(908, 154)])
g.add_edges([(1706, 154)])
g.add_edges([(2059, 154)])
g.add_edges([(951, 155)])
g.add_edges([(311, 156)])
g.add_edges([(681, 157)])
g.add_edges([(1335, 159)])
g.add_edges([(1961, 159)])
g.add_edges([(331, 160)])
g.add_edges([(360, 160)])
g.add_edges([(406, 160)])
g.add_edges([(415, 160)])
g.add_edges([(450, 160)])
g.add_edges([(597, 160)])
g.add_edges([(679, 160)])
g.add_edges([(745, 160)])
g.add_edges([(752, 160)])
g.add_edges([(753, 160)])
g.add_edges([(755, 160)])
g.add_edges([(761, 160)])
g.add_edges([(762, 160)])
g.add_edges([(766, 160)])
g.add_edges([(768, 160)])
g.add_edges([(769, 160)])
g.add_edges([(772, 160)])
g.add_edges([(774, 160)])
g.add_edges([(776, 160)])
g.add_edges([(781, 160)])
g.add_edges([(783, 160)])
g.add_edges([(784, 160)])
g.add_edges([(787, 160)])
g.add_edges([(789, 160)])
g.add_edges([(793, 160)])
g.add_edges([(794, 160)])
g.add_edges([(795, 160)])
g.add_edges([(797, 160)])
g.add_edges([(798, 160)])
g.add_edges([(982, 160)])
g.add_edges([(1003, 160)])
g.add_edges([(1025, 160)])
g.add_edges([(1163, 160)])
g.add_edges([(1166, 160)])
g.add_edges([(1255, 160)])
g.add_edges([(1274, 160)])
g.add_edges([(1333, 160)])
g.add_edges([(1335, 160)])
g.add_edges([(1362, 160)])
g.add_edges([(1466, 160)])
g.add_edges([(1528, 160)])
g.add_edges([(1646, 160)])
g.add_edges([(1647, 160)])
g.add_edges([(1648, 160)])
g.add_edges([(1649, 160)])
g.add_edges([(1652, 160)])
g.add_edges([(1793, 160)])
g.add_edges([(1967, 160)])
g.add_edges([(1999, 160)])
g.add_edges([(2022, 160)])
g.add_edges([(2100, 160)])
g.add_edges([(2101, 160)])
g.add_edges([(2108, 160)])
g.add_edges([(2171, 160)])
g.add_edges([(144, 161)])
g.add_edges([(145, 161)])
g.add_edges([(147, 161)])
g.add_edges([(253, 161)])
g.add_edges([(419, 161)])
g.add_edges([(445, 161)])
g.add_edges([(481, 161)])
g.add_edges([(486, 161)])
g.add_edges([(627, 161)])
g.add_edges([(704, 161)])
g.add_edges([(706, 161)])
g.add_edges([(773, 161)])
g.add_edges([(878, 161)])
g.add_edges([(880, 161)])
g.add_edges([(898, 161)])
g.add_edges([(953, 161)])
g.add_edges([(1449, 161)])
g.add_edges([(1451, 161)])
g.add_edges([(1473, 161)])
g.add_edges([(1494, 161)])
g.add_edges([(1519, 161)])
g.add_edges([(1542, 161)])
g.add_edges([(1604, 161)])
g.add_edges([(1638, 161)])
g.add_edges([(1718, 161)])
g.add_edges([(2090, 161)])
g.add_edges([(2109, 161)])
g.add_edges([(597, 162)])
g.add_edges([(917, 162)])
g.add_edges([(2154, 163)])
g.add_edges([(112, 164)])
g.add_edges([(360, 165)])
g.add_edges([(681, 165)])
g.add_edges([(808, 165)])
g.add_edges([(1333, 165)])
g.add_edges([(1346, 165)])
g.add_edges([(1449, 165)])
g.add_edges([(1458, 165)])
g.add_edges([(1460, 165)])
g.add_edges([(1461, 165)])
g.add_edges([(1462, 165)])
g.add_edges([(1463, 165)])
g.add_edges([(1464, 165)])
g.add_edges([(1465, 165)])
g.add_edges([(1468, 165)])
g.add_edges([(1469, 165)])
g.add_edges([(1472, 165)])
g.add_edges([(1593, 165)])
g.add_edges([(1865, 165)])
g.add_edges([(1873, 165)])
g.add_edges([(749, 167)])
g.add_edges([(7, 168)])
g.add_edges([(211, 168)])
g.add_edges([(213, 168)])
g.add_edges([(214, 168)])
g.add_edges([(216, 168)])
g.add_edges([(221, 168)])
g.add_edges([(387, 168)])
g.add_edges([(405, 168)])
g.add_edges([(561, 168)])
g.add_edges([(740, 168)])
g.add_edges([(749, 168)])
g.add_edges([(767, 168)])
g.add_edges([(1332, 168)])
g.add_edges([(1364, 168)])
g.add_edges([(1572, 168)])
g.add_edges([(1722, 168)])
g.add_edges([(1809, 168)])
g.add_edges([(1928, 168)])
g.add_edges([(1938, 168)])
g.add_edges([(2022, 168)])
g.add_edges([(2112, 168)])
g.add_edges([(115, 169)])
g.add_edges([(360, 169)])
g.add_edges([(904, 169)])
g.add_edges([(1333, 169)])
g.add_edges([(158, 170)])
g.add_edges([(681, 170)])
g.add_edges([(1202, 170)])
g.add_edges([(1430, 170)])
g.add_edges([(1475, 170)])
g.add_edges([(1371, 171)])
g.add_edges([(2090, 173)])
g.add_edges([(2082, 174)])
g.add_edges([(1458, 175)])
g.add_edges([(1460, 175)])
g.add_edges([(1461, 175)])
g.add_edges([(1462, 175)])
g.add_edges([(1463, 175)])
g.add_edges([(1464, 175)])
g.add_edges([(1465, 175)])
g.add_edges([(1467, 175)])
g.add_edges([(1468, 175)])
g.add_edges([(1469, 175)])
g.add_edges([(2088, 176)])
g.add_edges([(85, 177)])
g.add_edges([(692, 178)])
g.add_edges([(166, 179)])
g.add_edges([(115, 180)])
g.add_edges([(782, 180)])
g.add_edges([(932, 181)])
g.add_edges([(1370, 182)])
g.add_edges([(1493, 182)])
g.add_edges([(1530, 183)])
g.add_edges([(1531, 183)])
g.add_edges([(1532, 183)])
g.add_edges([(383, 184)])
g.add_edges([(386, 184)])
g.add_edges([(824, 184)])
g.add_edges([(869, 184)])
g.add_edges([(1332, 184)])
g.add_edges([(1365, 184)])
g.add_edges([(1484, 184)])
g.add_edges([(2088, 184)])
g.add_edges([(216, 185)])
g.add_edges([(383, 185)])
g.add_edges([(869, 185)])
g.add_edges([(1362, 186)])
g.add_edges([(211, 187)])
g.add_edges([(212, 187)])
g.add_edges([(213, 187)])
g.add_edges([(214, 187)])
g.add_edges([(215, 187)])
g.add_edges([(216, 187)])
g.add_edges([(218, 187)])
g.add_edges([(219, 187)])
g.add_edges([(220, 187)])
g.add_edges([(1928, 187)])
g.add_edges([(217, 188)])
g.add_edges([(387, 188)])
g.add_edges([(1289, 188)])
g.add_edges([(1291, 188)])
g.add_edges([(1484, 188)])
g.add_edges([(1537, 188)])
g.add_edges([(1873, 188)])
g.add_edges([(1875, 188)])
g.add_edges([(1876, 188)])
g.add_edges([(1877, 188)])
g.add_edges([(1878, 188)])
g.add_edges([(1880, 188)])
g.add_edges([(1881, 188)])
g.add_edges([(1882, 188)])
g.add_edges([(1883, 188)])
g.add_edges([(1885, 188)])
g.add_edges([(1886, 188)])
g.add_edges([(1887, 188)])
g.add_edges([(2077, 188)])
g.add_edges([(2088, 189)])
g.add_edges([(2088, 190)])
g.add_edges([(2088, 191)])
g.add_edges([(2237, 192)])
g.add_edges([(2022, 193)])
g.add_edges([(203, 194)])
g.add_edges([(2154, 195)])
g.add_edges([(311, 197)])
g.add_edges([(1314, 197)])
g.add_edges([(1315, 197)])
g.add_edges([(1316, 197)])
g.add_edges([(1317, 197)])
g.add_edges([(1318, 197)])
g.add_edges([(1319, 197)])
g.add_edges([(1320, 197)])
g.add_edges([(1321, 197)])
g.add_edges([(1322, 197)])
g.add_edges([(1324, 197)])
g.add_edges([(1325, 197)])
g.add_edges([(1326, 197)])
g.add_edges([(1328, 197)])
g.add_edges([(2076, 197)])
g.add_edges([(196, 198)])
g.add_edges([(199, 198)])
g.add_edges([(393, 198)])
g.add_edges([(394, 198)])
g.add_edges([(395, 198)])
g.add_edges([(397, 198)])
g.add_edges([(399, 198)])
g.add_edges([(400, 198)])
g.add_edges([(402, 198)])
g.add_edges([(403, 198)])
g.add_edges([(404, 198)])
g.add_edges([(406, 198)])
g.add_edges([(407, 198)])
g.add_edges([(408, 198)])
g.add_edges([(444, 198)])
g.add_edges([(451, 198)])
g.add_edges([(837, 198)])
g.add_edges([(927, 198)])
g.add_edges([(928, 198)])
g.add_edges([(929, 198)])
g.add_edges([(982, 198)])
g.add_edges([(1098, 198)])
g.add_edges([(1274, 198)])
g.add_edges([(1517, 198)])
g.add_edges([(1586, 198)])
g.add_edges([(1605, 198)])
g.add_edges([(1627, 198)])
g.add_edges([(1700, 198)])
g.add_edges([(1866, 198)])
g.add_edges([(1999, 198)])
g.add_edges([(2003, 198)])
g.add_edges([(2164, 198)])
g.add_edges([(2165, 198)])
g.add_edges([(2171, 198)])
g.add_edges([(117, 200)])
g.add_edges([(205, 200)])
g.add_edges([(942, 200)])
g.add_edges([(976, 200)])
g.add_edges([(1475, 200)])
g.add_edges([(1704, 200)])
g.add_edges([(1726, 200)])
g.add_edges([(2117, 200)])
g.add_edges([(2153, 200)])
g.add_edges([(2082, 201)])
g.add_edges([(2082, 202)])
g.add_edges([(387, 204)])
g.add_edges([(396, 206)])
g.add_edges([(932, 206)])
g.add_edges([(2175, 206)])
g.add_edges([(118, 207)])
g.add_edges([(112, 208)])
g.add_edges([(880, 208)])
g.add_edges([(610, 209)])
g.add_edges([(1342, 209)])
g.add_edges([(1555, 209)])
g.add_edges([(1629, 209)])
g.add_edges([(1874, 209)])
g.add_edges([(1988, 209)])
g.add_edges([(1991, 209)])
g.add_edges([(2133, 209)])
g.add_edges([(2154, 209)])
g.add_edges([(387, 221)])
g.add_edges([(2071, 222)])
g.add_edges([(1006, 223)])
g.add_edges([(225, 224)])
g.add_edges([(199, 226)])
g.add_edges([(837, 226)])
g.add_edges([(1517, 226)])
g.add_edges([(2164, 226)])
g.add_edges([(7, 227)])
g.add_edges([(216, 227)])
g.add_edges([(221, 227)])
g.add_edges([(878, 227)])
g.add_edges([(954, 227)])
g.add_edges([(1087, 227)])
g.add_edges([(1226, 227)])
g.add_edges([(1232, 227)])
g.add_edges([(1370, 227)])
g.add_edges([(1451, 227)])
g.add_edges([(1484, 227)])
g.add_edges([(1493, 227)])
g.add_edges([(1499, 227)])
g.add_edges([(1547, 227)])
g.add_edges([(1928, 227)])
g.add_edges([(445, 228)])
g.add_edges([(147, 229)])
g.add_edges([(445, 229)])
g.add_edges([(538, 229)])
g.add_edges([(898, 229)])
g.add_edges([(1494, 229)])
g.add_edges([(115, 230)])
g.add_edges([(782, 230)])
g.add_edges([(1568, 230)])
g.add_edges([(1873, 230)])
g.add_edges([(341, 231)])
g.add_edges([(2154, 231)])
g.add_edges([(1814, 232)])
g.add_edges([(2082, 233)])
g.add_edges([(0, 234)])
g.add_edges([(7, 234)])
g.add_edges([(85, 234)])
g.add_edges([(115, 234)])
g.add_edges([(116, 234)])
g.add_edges([(117, 234)])
g.add_edges([(118, 234)])
g.add_edges([(140, 234)])
g.add_edges([(141, 234)])
g.add_edges([(144, 234)])
g.add_edges([(145, 234)])
g.add_edges([(147, 234)])
g.add_edges([(151, 234)])
g.add_edges([(152, 234)])
g.add_edges([(166, 234)])
g.add_edges([(172, 234)])
g.add_edges([(196, 234)])
g.add_edges([(205, 234)])
g.add_edges([(211, 234)])
g.add_edges([(212, 234)])
g.add_edges([(213, 234)])
g.add_edges([(214, 234)])
g.add_edges([(215, 234)])
g.add_edges([(216, 234)])
g.add_edges([(217, 234)])
g.add_edges([(218, 234)])
g.add_edges([(219, 234)])
g.add_edges([(220, 234)])
g.add_edges([(239, 234)])
g.add_edges([(253, 234)])
g.add_edges([(254, 234)])
g.add_edges([(256, 234)])
g.add_edges([(257, 234)])
g.add_edges([(314, 234)])
g.add_edges([(315, 234)])
g.add_edges([(316, 234)])
g.add_edges([(328, 234)])
g.add_edges([(332, 234)])
g.add_edges([(350, 234)])
g.add_edges([(357, 234)])
g.add_edges([(360, 234)])
g.add_edges([(377, 234)])
g.add_edges([(383, 234)])
g.add_edges([(386, 234)])
g.add_edges([(387, 234)])
g.add_edges([(392, 234)])
g.add_edges([(395, 234)])
g.add_edges([(397, 234)])
g.add_edges([(403, 234)])
g.add_edges([(405, 234)])
g.add_edges([(408, 234)])
g.add_edges([(411, 234)])
g.add_edges([(415, 234)])
g.add_edges([(418, 234)])
g.add_edges([(419, 234)])
g.add_edges([(427, 234)])
g.add_edges([(429, 234)])
g.add_edges([(430, 234)])
g.add_edges([(432, 234)])
g.add_edges([(444, 234)])
g.add_edges([(445, 234)])
g.add_edges([(451, 234)])
g.add_edges([(475, 234)])
g.add_edges([(476, 234)])
g.add_edges([(478, 234)])
g.add_edges([(480, 234)])
g.add_edges([(481, 234)])
g.add_edges([(486, 234)])
g.add_edges([(536, 234)])
g.add_edges([(537, 234)])
g.add_edges([(543, 234)])
g.add_edges([(560, 234)])
g.add_edges([(575, 234)])
g.add_edges([(598, 234)])
g.add_edges([(627, 234)])
g.add_edges([(634, 234)])
g.add_edges([(643, 234)])
g.add_edges([(691, 234)])
g.add_edges([(692, 234)])
g.add_edges([(694, 234)])
g.add_edges([(697, 234)])
g.add_edges([(702, 234)])
g.add_edges([(704, 234)])
g.add_edges([(706, 234)])
g.add_edges([(745, 234)])
g.add_edges([(748, 234)])
g.add_edges([(752, 234)])
g.add_edges([(753, 234)])
g.add_edges([(755, 234)])
g.add_edges([(761, 234)])
g.add_edges([(767, 234)])
g.add_edges([(768, 234)])
g.add_edges([(769, 234)])
g.add_edges([(771, 234)])
g.add_edges([(772, 234)])
g.add_edges([(773, 234)])
g.add_edges([(774, 234)])
g.add_edges([(776, 234)])
g.add_edges([(777, 234)])
g.add_edges([(781, 234)])
g.add_edges([(782, 234)])
g.add_edges([(783, 234)])
g.add_edges([(784, 234)])
g.add_edges([(785, 234)])
g.add_edges([(786, 234)])
g.add_edges([(788, 234)])
g.add_edges([(789, 234)])
g.add_edges([(793, 234)])
g.add_edges([(794, 234)])
g.add_edges([(795, 234)])
g.add_edges([(797, 234)])
g.add_edges([(809, 234)])
g.add_edges([(810, 234)])
g.add_edges([(824, 234)])
g.add_edges([(827, 234)])
g.add_edges([(831, 234)])
g.add_edges([(832, 234)])
g.add_edges([(869, 234)])
g.add_edges([(873, 234)])
g.add_edges([(878, 234)])
g.add_edges([(892, 234)])
g.add_edges([(898, 234)])
g.add_edges([(899, 234)])
g.add_edges([(909, 234)])
g.add_edges([(927, 234)])
g.add_edges([(928, 234)])
g.add_edges([(929, 234)])
g.add_edges([(930, 234)])
g.add_edges([(935, 234)])
g.add_edges([(938, 234)])
g.add_edges([(942, 234)])
g.add_edges([(943, 234)])
g.add_edges([(944, 234)])
g.add_edges([(953, 234)])
g.add_edges([(954, 234)])
g.add_edges([(958, 234)])
g.add_edges([(972, 234)])
g.add_edges([(976, 234)])
g.add_edges([(982, 234)])
g.add_edges([(991, 234)])
g.add_edges([(1026, 234)])
g.add_edges([(1087, 234)])
g.add_edges([(1098, 234)])
g.add_edges([(1163, 234)])
g.add_edges([(1208, 234)])
g.add_edges([(1226, 234)])
g.add_edges([(1232, 234)])
g.add_edges([(1255, 234)])
g.add_edges([(1274, 234)])
g.add_edges([(1289, 234)])
g.add_edges([(1291, 234)])
g.add_edges([(1304, 234)])
g.add_edges([(1325, 234)])
g.add_edges([(1332, 234)])
g.add_edges([(1333, 234)])
g.add_edges([(1353, 234)])
g.add_edges([(1359, 234)])
g.add_edges([(1365, 234)])
g.add_edges([(1370, 234)])
g.add_edges([(1383, 234)])
g.add_edges([(1386, 234)])
g.add_edges([(1396, 234)])
g.add_edges([(1401, 234)])
g.add_edges([(1404, 234)])
g.add_edges([(1407, 234)])
g.add_edges([(1414, 234)])
g.add_edges([(1423, 234)])
g.add_edges([(1425, 234)])
g.add_edges([(1446, 234)])
g.add_edges([(1449, 234)])
g.add_edges([(1450, 234)])
g.add_edges([(1451, 234)])
g.add_edges([(1452, 234)])
g.add_edges([(1456, 234)])
g.add_edges([(1457, 234)])
g.add_edges([(1460, 234)])
g.add_edges([(1471, 234)])
g.add_edges([(1472, 234)])
g.add_edges([(1473, 234)])
g.add_edges([(1475, 234)])
g.add_edges([(1484, 234)])
g.add_edges([(1492, 234)])
g.add_edges([(1493, 234)])
g.add_edges([(1494, 234)])
g.add_edges([(1496, 234)])
g.add_edges([(1497, 234)])
g.add_edges([(1499, 234)])
g.add_edges([(1506, 234)])
g.add_edges([(1509, 234)])
g.add_edges([(1519, 234)])
g.add_edges([(1520, 234)])
g.add_edges([(1522, 234)])
g.add_edges([(1523, 234)])
g.add_edges([(1541, 234)])
g.add_edges([(1547, 234)])
g.add_edges([(1548, 234)])
g.add_edges([(1568, 234)])
g.add_edges([(1572, 234)])
g.add_edges([(1578, 234)])
g.add_edges([(1584, 234)])
g.add_edges([(1604, 234)])
g.add_edges([(1605, 234)])
g.add_edges([(1627, 234)])
g.add_edges([(1638, 234)])
g.add_edges([(1640, 234)])
g.add_edges([(1641, 234)])
g.add_edges([(1642, 234)])
g.add_edges([(1643, 234)])
g.add_edges([(1644, 234)])
g.add_edges([(1645, 234)])
g.add_edges([(1646, 234)])
g.add_edges([(1647, 234)])
g.add_edges([(1648, 234)])
g.add_edges([(1649, 234)])
g.add_edges([(1650, 234)])
g.add_edges([(1651, 234)])
g.add_edges([(1652, 234)])
g.add_edges([(1653, 234)])
g.add_edges([(1658, 234)])
g.add_edges([(1671, 234)])
g.add_edges([(1700, 234)])
g.add_edges([(1714, 234)])
g.add_edges([(1718, 234)])
g.add_edges([(1720, 234)])
g.add_edges([(1724, 234)])
g.add_edges([(1731, 234)])
g.add_edges([(1758, 234)])
g.add_edges([(1789, 234)])
g.add_edges([(1803, 234)])
g.add_edges([(1866, 234)])
g.add_edges([(1873, 234)])
g.add_edges([(1875, 234)])
g.add_edges([(1876, 234)])
g.add_edges([(1877, 234)])
g.add_edges([(1878, 234)])
g.add_edges([(1880, 234)])
g.add_edges([(1881, 234)])
g.add_edges([(1882, 234)])
g.add_edges([(1883, 234)])
g.add_edges([(1885, 234)])
g.add_edges([(1886, 234)])
g.add_edges([(1887, 234)])
g.add_edges([(1903, 234)])
g.add_edges([(1905, 234)])
g.add_edges([(1913, 234)])
g.add_edges([(1928, 234)])
g.add_edges([(1940, 234)])
g.add_edges([(1963, 234)])
g.add_edges([(1999, 234)])
g.add_edges([(2003, 234)])
g.add_edges([(2023, 234)])
g.add_edges([(2031, 234)])
g.add_edges([(2032, 234)])
g.add_edges([(2058, 234)])
g.add_edges([(2077, 234)])
g.add_edges([(2081, 234)])
g.add_edges([(2085, 234)])
g.add_edges([(2088, 234)])
g.add_edges([(2090, 234)])
g.add_edges([(2108, 234)])
g.add_edges([(2109, 234)])
g.add_edges([(2112, 234)])
g.add_edges([(2113, 234)])
g.add_edges([(2117, 234)])
g.add_edges([(2124, 234)])
g.add_edges([(2127, 234)])
g.add_edges([(2134, 234)])
g.add_edges([(2145, 234)])
g.add_edges([(2149, 234)])
g.add_edges([(2165, 234)])
g.add_edges([(2171, 234)])
g.add_edges([(2173, 234)])
g.add_edges([(2174, 234)])
g.add_edges([(2175, 234)])
g.add_edges([(2188, 234)])
g.add_edges([(2222, 234)])
g.add_edges([(2082, 235)])
g.add_edges([(778, 236)])
g.add_edges([(1674, 238)])
g.add_edges([(1004, 240)])
g.add_edges([(1005, 240)])
g.add_edges([(1006, 240)])
g.add_edges([(681, 241)])
g.add_edges([(116, 242)])
g.add_edges([(1006, 243)])
g.add_edges([(631, 244)])
g.add_edges([(1475, 245)])
g.add_edges([(211, 246)])
g.add_edges([(213, 246)])
g.add_edges([(789, 246)])
g.add_edges([(1386, 246)])
g.add_edges([(643, 247)])
g.add_edges([(1006, 247)])
g.add_edges([(1312, 247)])
g.add_edges([(2082, 247)])
g.add_edges([(2129, 247)])
g.add_edges([(2145, 247)])
g.add_edges([(643, 248)])
g.add_edges([(1006, 249)])
g.add_edges([(2145, 249)])
g.add_edges([(643, 250)])
g.add_edges([(1312, 251)])
g.add_edges([(2082, 252)])
g.add_edges([(704, 253)])
g.add_edges([(954, 253)])
g.add_edges([(1578, 253)])
g.add_edges([(1731, 253)])
g.add_edges([(1467, 255)])
g.add_edges([(1371, 258)])
g.add_edges([(199, 259)])
g.add_edges([(837, 259)])
g.add_edges([(2164, 259)])
g.add_edges([(416, 260)])
g.add_edges([(823, 260)])
g.add_edges([(925, 260)])
g.add_edges([(1623, 260)])
g.add_edges([(1812, 260)])
g.add_edges([(1927, 260)])
g.add_edges([(1976, 260)])
g.add_edges([(2007, 260)])
g.add_edges([(2008, 260)])
g.add_edges([(2181, 260)])
g.add_edges([(770, 261)])
g.add_edges([(771, 261)])
g.add_edges([(838, 261)])
g.add_edges([(1290, 261)])
g.add_edges([(2175, 261)])
g.add_edges([(416, 262)])
g.add_edges([(823, 262)])
g.add_edges([(925, 262)])
g.add_edges([(1623, 262)])
g.add_edges([(1812, 262)])
g.add_edges([(1827, 262)])
g.add_edges([(1927, 262)])
g.add_edges([(1976, 262)])
g.add_edges([(2007, 262)])
g.add_edges([(2008, 262)])
g.add_edges([(2099, 262)])
g.add_edges([(2181, 262)])
g.add_edges([(0, 263)])
g.add_edges([(7, 263)])
g.add_edges([(85, 263)])
g.add_edges([(112, 263)])
g.add_edges([(115, 263)])
g.add_edges([(116, 263)])
g.add_edges([(117, 263)])
g.add_edges([(118, 263)])
g.add_edges([(140, 263)])
g.add_edges([(141, 263)])
g.add_edges([(144, 263)])
g.add_edges([(145, 263)])
g.add_edges([(147, 263)])
g.add_edges([(151, 263)])
g.add_edges([(152, 263)])
g.add_edges([(166, 263)])
g.add_edges([(172, 263)])
g.add_edges([(196, 263)])
g.add_edges([(204, 263)])
g.add_edges([(205, 263)])
g.add_edges([(211, 263)])
g.add_edges([(212, 263)])
g.add_edges([(213, 263)])
g.add_edges([(214, 263)])
g.add_edges([(215, 263)])
g.add_edges([(216, 263)])
g.add_edges([(217, 263)])
g.add_edges([(218, 263)])
g.add_edges([(219, 263)])
g.add_edges([(220, 263)])
g.add_edges([(221, 263)])
g.add_edges([(239, 263)])
g.add_edges([(253, 263)])
g.add_edges([(254, 263)])
g.add_edges([(256, 263)])
g.add_edges([(257, 263)])
g.add_edges([(311, 263)])
g.add_edges([(314, 263)])
g.add_edges([(315, 263)])
g.add_edges([(316, 263)])
g.add_edges([(328, 263)])
g.add_edges([(332, 263)])
g.add_edges([(350, 263)])
g.add_edges([(357, 263)])
g.add_edges([(360, 263)])
g.add_edges([(377, 263)])
g.add_edges([(383, 263)])
g.add_edges([(386, 263)])
g.add_edges([(387, 263)])
g.add_edges([(392, 263)])
g.add_edges([(393, 263)])
g.add_edges([(394, 263)])
g.add_edges([(395, 263)])
g.add_edges([(397, 263)])
g.add_edges([(399, 263)])
g.add_edges([(400, 263)])
g.add_edges([(401, 263)])
g.add_edges([(402, 263)])
g.add_edges([(403, 263)])
g.add_edges([(404, 263)])
g.add_edges([(405, 263)])
g.add_edges([(406, 263)])
g.add_edges([(407, 263)])
g.add_edges([(408, 263)])
g.add_edges([(411, 263)])
g.add_edges([(415, 263)])
g.add_edges([(418, 263)])
g.add_edges([(419, 263)])
g.add_edges([(427, 263)])
g.add_edges([(429, 263)])
g.add_edges([(430, 263)])
g.add_edges([(432, 263)])
g.add_edges([(435, 263)])
g.add_edges([(444, 263)])
g.add_edges([(445, 263)])
g.add_edges([(448, 263)])
g.add_edges([(449, 263)])
g.add_edges([(451, 263)])
g.add_edges([(475, 263)])
g.add_edges([(476, 263)])
g.add_edges([(478, 263)])
g.add_edges([(480, 263)])
g.add_edges([(481, 263)])
g.add_edges([(483, 263)])
g.add_edges([(486, 263)])
g.add_edges([(487, 263)])
g.add_edges([(494, 263)])
g.add_edges([(518, 263)])
g.add_edges([(531, 263)])
g.add_edges([(536, 263)])
g.add_edges([(537, 263)])
g.add_edges([(538, 263)])
g.add_edges([(543, 263)])
g.add_edges([(560, 263)])
g.add_edges([(561, 263)])
g.add_edges([(575, 263)])
g.add_edges([(597, 263)])
g.add_edges([(598, 263)])
g.add_edges([(627, 263)])
g.add_edges([(634, 263)])
g.add_edges([(643, 263)])
g.add_edges([(651, 263)])
g.add_edges([(663, 263)])
g.add_edges([(679, 263)])
g.add_edges([(692, 263)])
g.add_edges([(694, 263)])
g.add_edges([(697, 263)])
g.add_edges([(702, 263)])
g.add_edges([(704, 263)])
g.add_edges([(706, 263)])
g.add_edges([(744, 263)])
g.add_edges([(745, 263)])
g.add_edges([(748, 263)])
g.add_edges([(749, 263)])
g.add_edges([(752, 263)])
g.add_edges([(753, 263)])
g.add_edges([(755, 263)])
g.add_edges([(761, 263)])
g.add_edges([(767, 263)])
g.add_edges([(768, 263)])
g.add_edges([(769, 263)])
g.add_edges([(771, 263)])
g.add_edges([(772, 263)])
g.add_edges([(773, 263)])
g.add_edges([(774, 263)])
g.add_edges([(776, 263)])
g.add_edges([(777, 263)])
g.add_edges([(781, 263)])
g.add_edges([(782, 263)])
g.add_edges([(783, 263)])
g.add_edges([(784, 263)])
g.add_edges([(785, 263)])
g.add_edges([(786, 263)])
g.add_edges([(788, 263)])
g.add_edges([(789, 263)])
g.add_edges([(793, 263)])
g.add_edges([(794, 263)])
g.add_edges([(795, 263)])
g.add_edges([(797, 263)])
g.add_edges([(809, 263)])
g.add_edges([(810, 263)])
g.add_edges([(824, 263)])
g.add_edges([(827, 263)])
g.add_edges([(831, 263)])
g.add_edges([(832, 263)])
g.add_edges([(839, 263)])
g.add_edges([(858, 263)])
g.add_edges([(869, 263)])
g.add_edges([(873, 263)])
g.add_edges([(878, 263)])
g.add_edges([(884, 263)])
g.add_edges([(887, 263)])
g.add_edges([(892, 263)])
g.add_edges([(898, 263)])
g.add_edges([(899, 263)])
g.add_edges([(909, 263)])
g.add_edges([(926, 263)])
g.add_edges([(927, 263)])
g.add_edges([(928, 263)])
g.add_edges([(929, 263)])
g.add_edges([(930, 263)])
g.add_edges([(932, 263)])
g.add_edges([(935, 263)])
g.add_edges([(938, 263)])
g.add_edges([(942, 263)])
g.add_edges([(943, 263)])
g.add_edges([(944, 263)])
g.add_edges([(947, 263)])
g.add_edges([(953, 263)])
g.add_edges([(954, 263)])
g.add_edges([(955, 263)])
g.add_edges([(958, 263)])
g.add_edges([(961, 263)])
g.add_edges([(972, 263)])
g.add_edges([(973, 263)])
g.add_edges([(976, 263)])
g.add_edges([(982, 263)])
g.add_edges([(988, 263)])
g.add_edges([(991, 263)])
g.add_edges([(1003, 263)])
g.add_edges([(1004, 263)])
g.add_edges([(1005, 263)])
g.add_edges([(1006, 263)])
g.add_edges([(1026, 263)])
g.add_edges([(1036, 263)])
g.add_edges([(1064, 263)])
g.add_edges([(1067, 263)])
g.add_edges([(1087, 263)])
g.add_edges([(1098, 263)])
g.add_edges([(1163, 263)])
g.add_edges([(1182, 263)])
g.add_edges([(1202, 263)])
g.add_edges([(1208, 263)])
g.add_edges([(1226, 263)])
g.add_edges([(1232, 263)])
g.add_edges([(1255, 263)])
g.add_edges([(1274, 263)])
g.add_edges([(1289, 263)])
g.add_edges([(1291, 263)])
g.add_edges([(1304, 263)])
g.add_edges([(1312, 263)])
g.add_edges([(1325, 263)])
g.add_edges([(1332, 263)])
g.add_edges([(1333, 263)])
g.add_edges([(1337, 263)])
g.add_edges([(1345, 263)])
g.add_edges([(1353, 263)])
g.add_edges([(1359, 263)])
g.add_edges([(1362, 263)])
g.add_edges([(1363, 263)])
g.add_edges([(1364, 263)])
g.add_edges([(1365, 263)])
g.add_edges([(1366, 263)])
g.add_edges([(1370, 263)])
g.add_edges([(1383, 263)])
g.add_edges([(1386, 263)])
g.add_edges([(1396, 263)])
g.add_edges([(1401, 263)])
g.add_edges([(1404, 263)])
g.add_edges([(1407, 263)])
g.add_edges([(1414, 263)])
g.add_edges([(1418, 263)])
g.add_edges([(1423, 263)])
g.add_edges([(1425, 263)])
g.add_edges([(1426, 263)])
g.add_edges([(1430, 263)])
g.add_edges([(1446, 263)])
g.add_edges([(1449, 263)])
g.add_edges([(1450, 263)])
g.add_edges([(1451, 263)])
g.add_edges([(1452, 263)])
g.add_edges([(1454, 263)])
g.add_edges([(1456, 263)])
g.add_edges([(1457, 263)])
g.add_edges([(1459, 263)])
g.add_edges([(1460, 263)])
g.add_edges([(1461, 263)])
g.add_edges([(1462, 263)])
g.add_edges([(1463, 263)])
g.add_edges([(1464, 263)])
g.add_edges([(1465, 263)])
g.add_edges([(1468, 263)])
g.add_edges([(1469, 263)])
g.add_edges([(1471, 263)])
g.add_edges([(1472, 263)])
g.add_edges([(1473, 263)])
g.add_edges([(1475, 263)])
g.add_edges([(1481, 263)])
g.add_edges([(1484, 263)])
g.add_edges([(1492, 263)])
g.add_edges([(1493, 263)])
g.add_edges([(1494, 263)])
g.add_edges([(1495, 263)])
g.add_edges([(1496, 263)])
g.add_edges([(1497, 263)])
g.add_edges([(1499, 263)])
g.add_edges([(1506, 263)])
g.add_edges([(1508, 263)])
g.add_edges([(1509, 263)])
g.add_edges([(1510, 263)])
g.add_edges([(1518, 263)])
g.add_edges([(1519, 263)])
g.add_edges([(1520, 263)])
g.add_edges([(1522, 263)])
g.add_edges([(1523, 263)])
g.add_edges([(1528, 263)])
g.add_edges([(1529, 263)])
g.add_edges([(1530, 263)])
g.add_edges([(1531, 263)])
g.add_edges([(1532, 263)])
g.add_edges([(1533, 263)])
g.add_edges([(1535, 263)])
g.add_edges([(1537, 263)])
g.add_edges([(1539, 263)])
g.add_edges([(1540, 263)])
g.add_edges([(1541, 263)])
g.add_edges([(1542, 263)])
g.add_edges([(1547, 263)])
g.add_edges([(1548, 263)])
g.add_edges([(1551, 263)])
g.add_edges([(1568, 263)])
g.add_edges([(1572, 263)])
g.add_edges([(1578, 263)])
g.add_edges([(1584, 263)])
g.add_edges([(1599, 263)])
g.add_edges([(1604, 263)])
g.add_edges([(1605, 263)])
g.add_edges([(1606, 263)])
g.add_edges([(1627, 263)])
g.add_edges([(1638, 263)])
g.add_edges([(1640, 263)])
g.add_edges([(1641, 263)])
g.add_edges([(1642, 263)])
g.add_edges([(1643, 263)])
g.add_edges([(1644, 263)])
g.add_edges([(1645, 263)])
g.add_edges([(1646, 263)])
g.add_edges([(1647, 263)])
g.add_edges([(1648, 263)])
g.add_edges([(1649, 263)])
g.add_edges([(1650, 263)])
g.add_edges([(1651, 263)])
g.add_edges([(1652, 263)])
g.add_edges([(1653, 263)])
g.add_edges([(1658, 263)])
g.add_edges([(1659, 263)])
g.add_edges([(1661, 263)])
g.add_edges([(1671, 263)])
g.add_edges([(1677, 263)])
g.add_edges([(1686, 263)])
g.add_edges([(1687, 263)])
g.add_edges([(1700, 263)])
g.add_edges([(1709, 263)])
g.add_edges([(1714, 263)])
g.add_edges([(1718, 263)])
g.add_edges([(1720, 263)])
g.add_edges([(1722, 263)])
g.add_edges([(1724, 263)])
g.add_edges([(1729, 263)])
g.add_edges([(1731, 263)])
g.add_edges([(1758, 263)])
g.add_edges([(1768, 263)])
g.add_edges([(1789, 263)])
g.add_edges([(1803, 263)])
g.add_edges([(1804, 263)])
g.add_edges([(1805, 263)])
g.add_edges([(1809, 263)])
g.add_edges([(1814, 263)])
g.add_edges([(1866, 263)])
g.add_edges([(1873, 263)])
g.add_edges([(1875, 263)])
g.add_edges([(1876, 263)])
g.add_edges([(1877, 263)])
g.add_edges([(1878, 263)])
g.add_edges([(1880, 263)])
g.add_edges([(1881, 263)])
g.add_edges([(1882, 263)])
g.add_edges([(1883, 263)])
g.add_edges([(1885, 263)])
g.add_edges([(1886, 263)])
g.add_edges([(1887, 263)])
g.add_edges([(1903, 263)])
g.add_edges([(1905, 263)])
g.add_edges([(1913, 263)])
g.add_edges([(1928, 263)])
g.add_edges([(1940, 263)])
g.add_edges([(1963, 263)])
g.add_edges([(1999, 263)])
g.add_edges([(2003, 263)])
g.add_edges([(2022, 263)])
g.add_edges([(2023, 263)])
g.add_edges([(2031, 263)])
g.add_edges([(2032, 263)])
g.add_edges([(2058, 263)])
g.add_edges([(2077, 263)])
g.add_edges([(2081, 263)])
g.add_edges([(2085, 263)])
g.add_edges([(2088, 263)])
g.add_edges([(2090, 263)])
g.add_edges([(2096, 263)])
g.add_edges([(2108, 263)])
g.add_edges([(2109, 263)])
g.add_edges([(2112, 263)])
g.add_edges([(2113, 263)])
g.add_edges([(2117, 263)])
g.add_edges([(2124, 263)])
g.add_edges([(2127, 263)])
g.add_edges([(2129, 263)])
g.add_edges([(2131, 263)])
g.add_edges([(2134, 263)])
g.add_edges([(2143, 263)])
g.add_edges([(2145, 263)])
g.add_edges([(2149, 263)])
g.add_edges([(2153, 263)])
g.add_edges([(2163, 263)])
g.add_edges([(2165, 263)])
g.add_edges([(2171, 263)])
g.add_edges([(2173, 263)])
g.add_edges([(2174, 263)])
g.add_edges([(2182, 263)])
g.add_edges([(2188, 263)])
g.add_edges([(2222, 263)])
g.add_edges([(2237, 263)])
g.add_edges([(416, 264)])
g.add_edges([(2153, 265)])
g.add_edges([(2153, 266)])
g.add_edges([(734, 267)])
g.add_edges([(2181, 268)])
g.add_edges([(2270, 269)])
g.add_edges([(2268, 270)])
g.add_edges([(2268, 271)])
g.add_edges([(2268, 272)])
g.add_edges([(2268, 273)])
g.add_edges([(2268, 274)])
g.add_edges([(2268, 275)])
g.add_edges([(2268, 276)])
g.add_edges([(2268, 277)])
g.add_edges([(2268, 278)])
g.add_edges([(2268, 279)])
g.add_edges([(2270, 279)])
g.add_edges([(2268, 280)])
g.add_edges([(2268, 281)])
g.add_edges([(2268, 282)])
g.add_edges([(914, 283)])
g.add_edges([(2078, 283)])
g.add_edges([(2268, 283)])
g.add_edges([(2270, 283)])
g.add_edges([(2269, 284)])
g.add_edges([(2269, 285)])
g.add_edges([(510, 286)])
g.add_edges([(610, 286)])
g.add_edges([(689, 286)])
g.add_edges([(734, 286)])
g.add_edges([(1025, 286)])
g.add_edges([(1342, 286)])
g.add_edges([(1681, 286)])
g.add_edges([(1725, 286)])
g.add_edges([(1726, 286)])
g.add_edges([(1793, 286)])
g.add_edges([(1874, 286)])
g.add_edges([(1969, 286)])
g.add_edges([(2174, 286)])
g.add_edges([(2175, 286)])
g.add_edges([(916, 287)])
g.add_edges([(778, 288)])
g.add_edges([(982, 289)])
g.add_edges([(1274, 290)])
g.add_edges([(2164, 290)])
g.add_edges([(982, 291)])
g.add_edges([(982, 292)])
g.add_edges([(778, 293)])
g.add_edges([(1897, 293)])
g.add_edges([(412, 294)])
g.add_edges([(413, 294)])
g.add_edges([(669, 294)])
g.add_edges([(415, 295)])
g.add_edges([(451, 296)])
g.add_edges([(451, 297)])
g.add_edges([(778, 298)])
g.add_edges([(778, 299)])
g.add_edges([(916, 300)])
g.add_edges([(1706, 301)])
g.add_edges([(2015, 302)])
g.add_edges([(597, 303)])
g.add_edges([(116, 304)])
g.add_edges([(778, 305)])
g.add_edges([(778, 306)])
g.add_edges([(1961, 307)])
g.add_edges([(1334, 308)])
g.add_edges([(1961, 309)])
g.add_edges([(1373, 310)])
g.add_edges([(1993, 312)])
g.add_edges([(988, 313)])
g.add_edges([(1578, 315)])
g.add_edges([(211, 316)])
g.add_edges([(2082, 317)])
g.add_edges([(1446, 318)])
g.add_edges([(113, 319)])
g.add_edges([(748, 319)])
g.add_edges([(113, 320)])
g.add_edges([(748, 320)])
g.add_edges([(113, 321)])
g.add_edges([(748, 321)])
g.add_edges([(1475, 322)])
g.add_edges([(116, 323)])
g.add_edges([(643, 324)])
g.add_edges([(1711, 325)])
g.add_edges([(1711, 326)])
g.add_edges([(2154, 327)])
g.add_edges([(1312, 329)])
g.add_edges([(916, 330)])
g.add_edges([(2154, 333)])
g.add_edges([(1312, 334)])
g.add_edges([(2154, 335)])
g.add_edges([(2154, 336)])
g.add_edges([(199, 337)])
g.add_edges([(1312, 338)])
g.add_edges([(1312, 340)])
g.add_edges([(1312, 342)])
g.add_edges([(643, 343)])
g.add_edges([(1312, 344)])
g.add_edges([(954, 345)])
g.add_edges([(1520, 346)])
g.add_edges([(2145, 347)])
g.add_edges([(1711, 349)])
g.add_edges([(643, 351)])
g.add_edges([(2082, 352)])
g.add_edges([(1499, 353)])
g.add_edges([(403, 354)])
g.add_edges([(932, 355)])
g.add_edges([(144, 356)])
g.add_edges([(944, 359)])
g.add_edges([(1729, 361)])
g.add_edges([(1938, 362)])
g.add_edges([(1473, 366)])
g.add_edges([(430, 368)])
g.add_edges([(211, 369)])
g.add_edges([(1323, 370)])
g.add_edges([(1448, 372)])
g.add_edges([(430, 373)])
g.add_edges([(141, 374)])
g.add_edges([(141, 375)])
g.add_edges([(1323, 376)])
g.add_edges([(2154, 378)])
g.add_edges([(778, 379)])
g.add_edges([(1897, 379)])
g.add_edges([(1519, 382)])
g.add_edges([(1323, 384)])
g.add_edges([(681, 388)])
g.add_edges([(253, 389)])
g.add_edges([(2015, 390)])
g.add_edges([(1524, 391)])
g.add_edges([(407, 400)])
g.add_edges([(387, 405)])
g.add_edges([(1768, 409)])
g.add_edges([(988, 410)])
g.add_edges([(411, 414)])
g.add_edges([(973, 417)])
g.add_edges([(419, 418)])
g.add_edges([(392, 419)])
g.add_edges([(1312, 420)])
g.add_edges([(1312, 421)])
g.add_edges([(615, 422)])
g.add_edges([(1932, 422)])
g.add_edges([(751, 423)])
g.add_edges([(751, 424)])
g.add_edges([(751, 425)])
g.add_edges([(808, 426)])
g.add_edges([(387, 427)])
g.add_edges([(1711, 428)])
g.add_edges([(387, 431)])
g.add_edges([(1323, 433)])
g.add_edges([(415, 434)])
g.add_edges([(430, 437)])
g.add_edges([(924, 439)])
g.add_edges([(924, 440)])
g.add_edges([(385, 441)])
g.add_edges([(385, 442)])
g.add_edges([(706, 443)])
g.add_edges([(543, 445)])
g.add_edges([(1581, 446)])
g.add_edges([(1373, 447)])
g.add_edges([(954, 452)])
g.add_edges([(954, 453)])
g.add_edges([(1467, 454)])
g.add_edges([(954, 455)])
g.add_edges([(199, 456)])
g.add_edges([(954, 457)])
g.add_edges([(954, 458)])
g.add_edges([(954, 459)])
g.add_edges([(954, 460)])
g.add_edges([(954, 461)])
g.add_edges([(954, 462)])
g.add_edges([(954, 463)])
g.add_edges([(954, 464)])
g.add_edges([(954, 465)])
g.add_edges([(954, 466)])
g.add_edges([(643, 467)])
g.add_edges([(954, 468)])
g.add_edges([(954, 469)])
g.add_edges([(954, 470)])
g.add_edges([(2164, 471)])
g.add_edges([(954, 472)])
g.add_edges([(1467, 473)])
g.add_edges([(411, 477)])
g.add_edges([(430, 477)])
g.add_edges([(513, 477)])
g.add_edges([(778, 477)])
g.add_edges([(904, 477)])
g.add_edges([(1658, 477)])
g.add_edges([(2088, 479)])
g.add_edges([(1499, 482)])
g.add_edges([(7, 484)])
g.add_edges([(397, 485)])
g.add_edges([(387, 486)])
g.add_edges([(487, 488)])
g.add_edges([(476, 489)])
g.add_edges([(141, 490)])
g.add_edges([(1087, 491)])
g.add_edges([(1866, 492)])
g.add_edges([(451, 493)])
g.add_edges([(926, 495)])
g.add_edges([(926, 496)])
g.add_edges([(2163, 496)])
g.add_edges([(1627, 497)])
g.add_edges([(2022, 498)])
g.add_edges([(694, 499)])
g.add_edges([(1359, 500)])
g.add_edges([(2166, 501)])
g.add_edges([(430, 502)])
g.add_edges([(681, 503)])
g.add_edges([(1499, 504)])
g.add_edges([(1606, 505)])
g.add_edges([(1606, 506)])
g.add_edges([(487, 507)])
g.add_edges([(638, 508)])
g.add_edges([(444, 509)])
g.add_edges([(929, 509)])
g.add_edges([(926, 511)])
g.add_edges([(1677, 512)])
g.add_edges([(1967, 514)])
g.add_edges([(430, 515)])
g.add_edges([(371, 516)])
g.add_edges([(144, 517)])
g.add_edges([(1473, 519)])
g.add_edges([(1449, 520)])
g.add_edges([(1568, 522)])
g.add_edges([(413, 523)])
g.add_edges([(403, 524)])
g.add_edges([(1984, 525)])
g.add_edges([(614, 526)])
g.add_edges([(926, 527)])
g.add_edges([(704, 528)])
g.add_edges([(2088, 529)])
g.add_edges([(1337, 530)])
g.add_edges([(445, 532)])
g.add_edges([(1484, 533)])
g.add_edges([(1499, 534)])
g.add_edges([(1499, 535)])
g.add_edges([(445, 536)])
g.add_edges([(537, 536)])
g.add_edges([(1578, 536)])
g.add_edges([(387, 537)])
g.add_edges([(1722, 539)])
g.add_edges([(536, 541)])
g.add_edges([(445, 542)])
g.add_edges([(807, 544)])
g.add_edges([(954, 545)])
g.add_edges([(140, 547)])
g.add_edges([(2181, 548)])
g.add_edges([(838, 549)])
g.add_edges([(1290, 549)])
g.add_edges([(988, 550)])
g.add_edges([(1312, 551)])
g.add_edges([(927, 552)])
g.add_edges([(928, 552)])
g.add_edges([(445, 553)])
g.add_edges([(445, 554)])
g.add_edges([(1449, 555)])
g.add_edges([(778, 556)])
g.add_edges([(1981, 557)])
g.add_edges([(779, 558)])
g.add_edges([(1981, 559)])
g.add_edges([(387, 560)])
g.add_edges([(1938, 562)])
g.add_edges([(415, 563)])
g.add_edges([(766, 564)])
g.add_edges([(706, 565)])
g.add_edges([(702, 566)])
g.add_edges([(1627, 567)])
g.add_edges([(2174, 568)])
g.add_edges([(809, 569)])
g.add_edges([(809, 570)])
g.add_edges([(810, 571)])
g.add_edges([(2120, 572)])
g.add_edges([(1722, 573)])
g.add_edges([(435, 574)])
g.add_edges([(1408, 576)])
g.add_edges([(1658, 576)])
g.add_edges([(1312, 578)])
g.add_edges([(1312, 579)])
g.add_edges([(1312, 580)])
g.add_edges([(778, 581)])
g.add_edges([(1312, 582)])
g.add_edges([(778, 583)])
g.add_edges([(1897, 583)])
g.add_edges([(1006, 584)])
g.add_edges([(2129, 584)])
g.add_edges([(1312, 585)])
g.add_edges([(1312, 586)])
g.add_edges([(1312, 587)])
g.add_edges([(1312, 588)])
g.add_edges([(1312, 589)])
g.add_edges([(1312, 590)])
g.add_edges([(1312, 591)])
g.add_edges([(1312, 592)])
g.add_edges([(778, 593)])
g.add_edges([(1897, 593)])
g.add_edges([(1006, 594)])
g.add_edges([(2129, 594)])
g.add_edges([(2129, 595)])
g.add_edges([(1312, 596)])
g.add_edges([(1004, 599)])
g.add_edges([(1005, 599)])
g.add_edges([(1006, 599)])
g.add_edges([(141, 600)])
g.add_edges([(2082, 601)])
g.add_edges([(915, 602)])
g.add_edges([(614, 604)])
g.add_edges([(620, 604)])
g.add_edges([(821, 604)])
g.add_edges([(1865, 604)])
g.add_edges([(704, 606)])
g.add_edges([(643, 607)])
g.add_edges([(1359, 608)])
g.add_edges([(615, 611)])
g.add_edges([(821, 611)])
g.add_edges([(615, 612)])
g.add_edges([(615, 613)])
g.add_edges([(617, 616)])
g.add_edges([(615, 618)])
g.add_edges([(821, 618)])
g.add_edges([(615, 619)])
g.add_edges([(560, 621)])
g.add_edges([(954, 621)])
g.add_edges([(778, 622)])
g.add_edges([(435, 623)])
g.add_edges([(689, 624)])
g.add_edges([(1373, 625)])
g.add_edges([(1312, 626)])
g.add_edges([(7, 628)])
g.add_edges([(418, 628)])
g.add_edges([(419, 628)])
g.add_edges([(1332, 628)])
g.add_edges([(1312, 629)])
g.add_edges([(2082, 629)])
g.add_edges([(1312, 630)])
g.add_edges([(774, 632)])
g.add_edges([(638, 633)])
g.add_edges([(311, 635)])
g.add_edges([(869, 636)])
g.add_edges([(199, 639)])
g.add_edges([(916, 640)])
g.add_edges([(1887, 641)])
g.add_edges([(2174, 644)])
g.add_edges([(1449, 645)])
g.add_edges([(1449, 646)])
g.add_edges([(1449, 647)])
g.add_edges([(1449, 648)])
g.add_edges([(1449, 649)])
g.add_edges([(1449, 650)])
g.add_edges([(1449, 652)])
g.add_edges([(1449, 653)])
g.add_edges([(1449, 654)])
g.add_edges([(1449, 655)])
g.add_edges([(1449, 656)])
g.add_edges([(1449, 657)])
g.add_edges([(1449, 658)])
g.add_edges([(651, 660)])
g.add_edges([(1449, 661)])
g.add_edges([(1613, 664)])
g.add_edges([(430, 665)])
g.add_edges([(704, 666)])
g.add_edges([(706, 666)])
g.add_edges([(486, 667)])
g.add_edges([(1519, 668)])
g.add_edges([(2181, 670)])
g.add_edges([(2149, 671)])
g.add_edges([(1711, 672)])
g.add_edges([(1670, 673)])
g.add_edges([(401, 674)])
g.add_edges([(1711, 675)])
g.add_edges([(449, 676)])
g.add_edges([(694, 676)])
g.add_edges([(839, 676)])
g.add_edges([(926, 676)])
g.add_edges([(2163, 676)])
g.add_edges([(828, 677)])
g.add_edges([(1568, 678)])
g.add_edges([(1578, 680)])
g.add_edges([(1599, 682)])
g.add_edges([(810, 683)])
g.add_edges([(828, 684)])
g.add_edges([(681, 685)])
g.add_edges([(627, 686)])
g.add_edges([(808, 687)])
g.add_edges([(2129, 688)])
g.add_edges([(1473, 690)])
g.add_edges([(692, 693)])
g.add_edges([(778, 695)])
g.add_edges([(778, 696)])
g.add_edges([(387, 697)])
g.add_edges([(1475, 698)])
g.add_edges([(1475, 699)])
g.add_edges([(1627, 700)])
g.add_edges([(1312, 701)])
g.add_edges([(445, 704)])
g.add_edges([(1711, 705)])
g.add_edges([(387, 706)])
g.add_edges([(1939, 707)])
g.add_edges([(774, 708)])
g.add_edges([(778, 708)])
g.add_edges([(1897, 708)])
g.add_edges([(1729, 709)])
g.add_edges([(1729, 710)])
g.add_edges([(1729, 711)])
g.add_edges([(1984, 712)])
g.add_edges([(778, 713)])
g.add_edges([(1897, 713)])
g.add_edges([(1404, 714)])
g.add_edges([(869, 715)])
g.add_edges([(1400, 715)])
g.add_edges([(1581, 716)])
g.add_edges([(1524, 717)])
g.add_edges([(2174, 718)])
g.add_edges([(1627, 720)])
g.add_edges([(1492, 721)])
g.add_edges([(1897, 722)])
g.add_edges([(2082, 723)])
g.add_edges([(118, 724)])
g.add_edges([(828, 725)])
g.add_edges([(2117, 726)])
g.add_edges([(681, 727)])
g.add_edges([(450, 728)])
g.add_edges([(706, 728)])
g.add_edges([(821, 728)])
g.add_edges([(944, 729)])
g.add_edges([(536, 730)])
g.add_edges([(211, 731)])
g.add_edges([(387, 732)])
g.add_edges([(1928, 733)])
g.add_edges([(430, 735)])
g.add_edges([(952, 736)])
g.add_edges([(1495, 736)])
g.add_edges([(1524, 737)])
g.add_edges([(778, 738)])
g.add_edges([(411, 739)])
g.add_edges([(113, 741)])
g.add_edges([(748, 741)])
g.add_edges([(782, 742)])
g.add_edges([(115, 743)])
g.add_edges([(782, 743)])
g.add_edges([(199, 746)])
g.add_edges([(2164, 746)])
g.add_edges([(1362, 756)])
g.add_edges([(7, 757)])
g.add_edges([(560, 757)])
g.add_edges([(1323, 758)])
g.add_edges([(766, 759)])
g.add_edges([(766, 760)])
g.add_edges([(765, 763)])
g.add_edges([(765, 764)])
g.add_edges([(257, 767)])
g.add_edges([(405, 767)])
g.add_edges([(427, 767)])
g.add_edges([(780, 775)])
g.add_edges([(1353, 782)])
g.add_edges([(791, 790)])
g.add_edges([(1578, 792)])
g.add_edges([(341, 796)])
g.add_edges([(2181, 799)])
g.add_edges([(810, 801)])
g.add_edges([(1578, 801)])
g.add_edges([(1448, 802)])
g.add_edges([(2175, 804)])
g.add_edges([(1475, 805)])
g.add_edges([(808, 811)])
g.add_edges([(643, 813)])
g.add_edges([(2088, 814)])
g.add_edges([(1638, 815)])
g.add_edges([(2109, 816)])
g.add_edges([(643, 817)])
g.add_edges([(1312, 817)])
g.add_edges([(2082, 817)])
g.add_edges([(560, 819)])
g.add_edges([(821, 820)])
g.add_edges([(1004, 822)])
g.add_edges([(1005, 822)])
g.add_edges([(1006, 822)])
g.add_edges([(536, 825)])
g.add_edges([(474, 826)])
g.add_edges([(1993, 829)])
g.add_edges([(2114, 831)])
g.add_edges([(387, 832)])
g.add_edges([(1993, 833)])
g.add_edges([(1938, 834)])
g.add_edges([(415, 835)])
g.add_edges([(115, 836)])
g.add_edges([(116, 840)])
g.add_edges([(1460, 841)])
g.add_edges([(1980, 842)])
g.add_edges([(1363, 843)])
g.add_edges([(116, 844)])
g.add_edges([(116, 845)])
g.add_edges([(1363, 846)])
g.add_edges([(116, 847)])
g.add_edges([(116, 848)])
g.add_edges([(1430, 849)])
g.add_edges([(115, 850)])
g.add_edges([(1499, 851)])
g.add_edges([(2090, 851)])
g.add_edges([(116, 852)])
g.add_edges([(116, 853)])
g.add_edges([(1363, 854)])
g.add_edges([(1363, 855)])
g.add_edges([(1551, 856)])
g.add_edges([(116, 857)])
g.add_edges([(116, 859)])
g.add_edges([(116, 860)])
g.add_edges([(116, 861)])
g.add_edges([(116, 862)])
g.add_edges([(778, 863)])
g.add_edges([(916, 864)])
g.add_edges([(869, 865)])
g.add_edges([(415, 866)])
g.add_edges([(766, 866)])
g.add_edges([(221, 867)])
g.add_edges([(704, 868)])
g.add_edges([(451, 870)])
g.add_edges([(954, 871)])
g.add_edges([(880, 872)])
g.add_edges([(1638, 872)])
g.add_edges([(2003, 874)])
g.add_edges([(887, 875)])
g.add_edges([(397, 876)])
g.add_edges([(2003, 876)])
g.add_edges([(869, 877)])
g.add_edges([(627, 879)])
g.add_edges([(694, 881)])
g.add_edges([(2003, 883)])
g.add_edges([(2003, 885)])
g.add_edges([(887, 886)])
g.add_edges([(408, 888)])
g.add_edges([(2003, 889)])
g.add_edges([(1528, 891)])
g.add_edges([(1370, 893)])
g.add_edges([(199, 895)])
g.add_edges([(766, 902)])
g.add_edges([(1674, 903)])
g.add_edges([(363, 905)])
g.add_edges([(363, 906)])
g.add_edges([(2088, 910)])
g.add_edges([(912, 911)])
g.add_edges([(1803, 913)])
g.add_edges([(147, 918)])
g.add_edges([(1866, 919)])
g.add_edges([(824, 920)])
g.add_edges([(916, 921)])
g.add_edges([(2129, 922)])
g.add_edges([(916, 923)])
g.add_edges([(2129, 931)])
g.add_edges([(1939, 933)])
g.add_edges([(935, 934)])
g.add_edges([(938, 936)])
g.add_edges([(938, 937)])
g.add_edges([(942, 939)])
g.add_edges([(942, 940)])
g.add_edges([(115, 941)])
g.add_edges([(387, 942)])
g.add_edges([(942, 945)])
g.add_edges([(1551, 946)])
g.add_edges([(387, 947)])
g.add_edges([(1449, 947)])
g.add_edges([(942, 948)])
g.add_edges([(1323, 949)])
g.add_edges([(118, 956)])
g.add_edges([(113, 957)])
g.add_edges([(748, 957)])
g.add_edges([(916, 959)])
g.add_edges([(1313, 960)])
g.add_edges([(2237, 960)])
g.add_edges([(1006, 962)])
g.add_edges([(1006, 963)])
g.add_edges([(988, 964)])
g.add_edges([(1659, 964)])
g.add_edges([(973, 965)])
g.add_edges([(1006, 966)])
g.add_edges([(973, 967)])
g.add_edges([(1334, 968)])
g.add_edges([(211, 969)])
g.add_edges([(663, 971)])
g.add_edges([(869, 974)])
g.add_edges([(869, 975)])
g.add_edges([(1345, 977)])
g.add_edges([(2096, 977)])
g.add_edges([(1873, 978)])
g.add_edges([(383, 979)])
g.add_edges([(1814, 980)])
g.add_edges([(383, 981)])
g.add_edges([(211, 983)])
g.add_edges([(1627, 984)])
g.add_edges([(1532, 985)])
g.add_edges([(1475, 986)])
g.add_edges([(1334, 987)])
g.add_edges([(1484, 989)])
g.add_edges([(1484, 990)])
g.add_edges([(216, 991)])
g.add_edges([(972, 992)])
g.add_edges([(663, 993)])
g.add_edges([(663, 994)])
g.add_edges([(1448, 995)])
g.add_edges([(1334, 996)])
g.add_edges([(1373, 996)])
g.add_edges([(2015, 996)])
g.add_edges([(753, 997)])
g.add_edges([(810, 998)])
g.add_edges([(916, 999)])
g.add_edges([(2022, 1000)])
g.add_edges([(774, 1001)])
g.add_edges([(809, 1002)])
g.add_edges([(1005, 1004)])
g.add_edges([(774, 1007)])
g.add_edges([(1648, 1008)])
g.add_edges([(218, 1009)])
g.add_edges([(954, 1010)])
g.add_edges([(380, 1011)])
g.add_edges([(2137, 1012)])
g.add_edges([(808, 1013)])
g.add_edges([(2088, 1014)])
g.add_edges([(1333, 1015)])
g.add_edges([(116, 1016)])
g.add_edges([(1981, 1017)])
g.add_edges([(1873, 1018)])
g.add_edges([(643, 1019)])
g.add_edges([(869, 1019)])
g.add_edges([(1497, 1019)])
g.add_edges([(869, 1020)])
g.add_edges([(430, 1021)])
g.add_edges([(643, 1022)])
g.add_edges([(415, 1023)])
g.add_edges([(1026, 1024)])
g.add_edges([(869, 1027)])
g.add_edges([(1464, 1028)])
g.add_edges([(1928, 1029)])
g.add_edges([(1876, 1030)])
g.add_edges([(1877, 1030)])
g.add_edges([(1878, 1030)])
g.add_edges([(1883, 1030)])
g.add_edges([(1359, 1031)])
g.add_edges([(487, 1032)])
g.add_edges([(1648, 1033)])
g.add_edges([(1226, 1034)])
g.add_edges([(1547, 1034)])
g.add_edges([(1548, 1034)])
g.add_edges([(1497, 1035)])
g.add_edges([(1226, 1037)])
g.add_edges([(1006, 1038)])
g.add_edges([(1289, 1039)])
g.add_edges([(1025, 1040)])
g.add_edges([(1793, 1040)])
g.add_edges([(2124, 1040)])
g.add_edges([(1003, 1041)])
g.add_edges([(560, 1042)])
g.add_edges([(211, 1043)])
g.add_edges([(1464, 1044)])
g.add_edges([(1768, 1045)])
g.add_edges([(869, 1046)])
g.add_edges([(917, 1047)])
g.add_edges([(211, 1048)])
g.add_edges([(1984, 1049)])
g.add_edges([(774, 1050)])
g.add_edges([(706, 1051)])
g.add_edges([(117, 1052)])
g.add_edges([(1492, 1053)])
g.add_edges([(643, 1054)])
g.add_edges([(1495, 1054)])
g.add_edges([(1641, 1054)])
g.add_edges([(1642, 1054)])
g.add_edges([(789, 1055)])
g.add_edges([(199, 1056)])
g.add_edges([(1517, 1056)])
g.add_edges([(2164, 1056)])
g.add_edges([(116, 1057)])
g.add_edges([(2174, 1058)])
g.add_edges([(614, 1059)])
g.add_edges([(809, 1060)])
g.add_edges([(1484, 1061)])
g.add_edges([(1226, 1062)])
g.add_edges([(1484, 1062)])
g.add_edges([(643, 1063)])
g.add_edges([(2222, 1063)])
g.add_edges([(115, 1065)])
g.add_edges([(1519, 1065)])
g.add_edges([(1099, 1066)])
g.add_edges([(1198, 1066)])
g.add_edges([(1224, 1066)])
g.add_edges([(387, 1067)])
g.add_edges([(988, 1068)])
g.add_edges([(869, 1069)])
g.add_edges([(926, 1070)])
g.add_edges([(1729, 1071)])
g.add_edges([(1475, 1072)])
g.add_edges([(869, 1073)])
g.add_edges([(869, 1074)])
g.add_edges([(381, 1075)])
g.add_edges([(1652, 1076)])
g.add_edges([(1817, 1077)])
g.add_edges([(779, 1078)])
g.add_edges([(2088, 1079)])
g.add_edges([(216, 1080)])
g.add_edges([(1484, 1081)])
g.add_edges([(766, 1082)])
g.add_edges([(1492, 1083)])
g.add_edges([(331, 1084)])
g.add_edges([(2131, 1085)])
g.add_edges([(1484, 1086)])
g.add_edges([(1087, 1089)])
g.add_edges([(869, 1090)])
g.add_edges([(1866, 1091)])
g.add_edges([(961, 1092)])
g.add_edges([(1450, 1093)])
g.add_edges([(869, 1094)])
g.add_edges([(116, 1095)])
g.add_edges([(1495, 1096)])
g.add_edges([(807, 1097)])
g.add_edges([(917, 1097)])
g.add_edges([(1484, 1097)])
g.add_edges([(924, 1100)])
g.add_edges([(116, 1101)])
g.add_edges([(1670, 1102)])
g.add_edges([(1484, 1103)])
g.add_edges([(924, 1104)])
g.add_edges([(1768, 1105)])
g.add_edges([(1499, 1106)])
g.add_edges([(869, 1107)])
g.add_edges([(1497, 1107)])
g.add_edges([(218, 1108)])
g.add_edges([(950, 1109)])
g.add_edges([(1312, 1110)])
g.add_edges([(917, 1111)])
g.add_edges([(2088, 1112)])
g.add_edges([(766, 1113)])
g.add_edges([(1670, 1114)])
g.add_edges([(204, 1115)])
g.add_edges([(638, 1116)])
g.add_edges([(116, 1117)])
g.add_edges([(151, 1118)])
g.add_edges([(869, 1119)])
g.add_edges([(2132, 1120)])
g.add_edges([(869, 1121)])
g.add_edges([(869, 1122)])
g.add_edges([(869, 1123)])
g.add_edges([(869, 1124)])
g.add_edges([(1401, 1125)])
g.add_edges([(1383, 1126)])
g.add_edges([(2137, 1127)])
g.add_edges([(218, 1128)])
g.add_edges([(808, 1129)])
g.add_edges([(1711, 1130)])
g.add_edges([(1484, 1131)])
g.add_edges([(1462, 1132)])
g.add_edges([(494, 1133)])
g.add_edges([(531, 1133)])
g.add_edges([(1768, 1133)])
g.add_edges([(2174, 1134)])
g.add_edges([(381, 1135)])
g.add_edges([(1644, 1136)])
g.add_edges([(858, 1137)])
g.add_edges([(786, 1138)])
g.add_edges([(869, 1139)])
g.add_edges([(869, 1140)])
g.add_edges([(386, 1141)])
g.add_edges([(818, 1142)])
g.add_edges([(2137, 1144)])
g.add_edges([(950, 1145)])
g.add_edges([(1484, 1146)])
g.add_edges([(1913, 1147)])
g.add_edges([(869, 1148)])
g.add_edges([(869, 1149)])
g.add_edges([(430, 1150)])
g.add_edges([(1653, 1151)])
g.add_edges([(116, 1152)])
g.add_edges([(869, 1153)])
g.add_edges([(116, 1154)])
g.add_edges([(2173, 1155)])
g.add_edges([(1026, 1156)])
g.add_edges([(2096, 1157)])
g.add_edges([(1551, 1158)])
g.add_edges([(869, 1160)])
g.add_edges([(869, 1161)])
g.add_edges([(1411, 1162)])
g.add_edges([(943, 1164)])
g.add_edges([(943, 1165)])
g.add_edges([(1647, 1167)])
g.add_edges([(808, 1168)])
g.add_edges([(1627, 1169)])
g.add_edges([(360, 1170)])
g.add_edges([(1460, 1171)])
g.add_edges([(1464, 1171)])
g.add_edges([(1627, 1172)])
g.add_edges([(1465, 1173)])
g.add_edges([(1469, 1173)])
g.add_edges([(1468, 1174)])
g.add_edges([(681, 1175)])
g.add_edges([(774, 1176)])
g.add_edges([(204, 1177)])
g.add_edges([(786, 1179)])
g.add_edges([(643, 1180)])
g.add_edges([(210, 1181)])
g.add_edges([(1466, 1183)])
g.add_edges([(2108, 1183)])
g.add_edges([(786, 1184)])
g.add_edges([(869, 1185)])
g.add_edges([(486, 1186)])
g.add_edges([(954, 1187)])
g.add_edges([(2137, 1188)])
g.add_edges([(487, 1189)])
g.add_edges([(332, 1190)])
g.add_edges([(1497, 1190)])
g.add_edges([(1645, 1190)])
g.add_edges([(643, 1191)])
g.add_edges([(1497, 1192)])
g.add_edges([(869, 1193)])
g.add_edges([(869, 1194)])
g.add_edges([(332, 1195)])
g.add_edges([(1645, 1195)])
g.add_edges([(663, 1196)])
g.add_edges([(116, 1197)])
g.add_edges([(1645, 1199)])
g.add_edges([(869, 1200)])
g.add_edges([(869, 1201)])
g.add_edges([(1484, 1203)])
g.add_edges([(2088, 1204)])
g.add_edges([(2174, 1205)])
g.add_edges([(1484, 1206)])
g.add_edges([(2173, 1207)])
g.add_edges([(1026, 1209)])
g.add_edges([(808, 1210)])
g.add_edges([(1649, 1211)])
g.add_edges([(221, 1212)])
g.add_edges([(869, 1213)])
g.add_edges([(610, 1214)])
g.add_edges([(610, 1215)])
g.add_edges([(2137, 1216)])
g.add_edges([(204, 1217)])
g.add_edges([(1004, 1218)])
g.add_edges([(1005, 1218)])
g.add_edges([(1006, 1218)])
g.add_edges([(2137, 1219)])
g.add_edges([(1670, 1220)])
g.add_edges([(2137, 1221)])
g.add_edges([(2137, 1222)])
g.add_edges([(1484, 1223)])
g.add_edges([(438, 1225)])
g.add_edges([(1547, 1226)])
g.add_edges([(218, 1227)])
g.add_edges([(869, 1228)])
g.add_edges([(869, 1229)])
g.add_edges([(1711, 1230)])
g.add_edges([(1640, 1231)])
g.add_edges([(869, 1233)])
g.add_edges([(808, 1234)])
g.add_edges([(116, 1235)])
g.add_edges([(218, 1236)])
g.add_edges([(210, 1237)])
g.add_edges([(1475, 1238)])
g.add_edges([(218, 1239)])
g.add_edges([(917, 1240)])
g.add_edges([(614, 1241)])
g.add_edges([(1803, 1242)])
g.add_edges([(2165, 1242)])
g.add_edges([(487, 1243)])
g.add_edges([(1606, 1243)])
g.add_edges([(917, 1244)])
g.add_edges([(218, 1245)])
g.add_edges([(2082, 1246)])
g.add_edges([(694, 1247)])
g.add_edges([(218, 1248)])
g.add_edges([(976, 1249)])
g.add_edges([(1423, 1249)])
g.add_edges([(1425, 1249)])
g.add_edges([(1540, 1249)])
g.add_edges([(807, 1250)])
g.add_edges([(1768, 1251)])
g.add_edges([(642, 1252)])
g.add_edges([(807, 1253)])
g.add_edges([(218, 1254)])
g.add_edges([(869, 1256)])
g.add_edges([(869, 1257)])
g.add_edges([(869, 1258)])
g.add_edges([(869, 1259)])
g.add_edges([(869, 1260)])
g.add_edges([(869, 1261)])
g.add_edges([(1497, 1262)])
g.add_edges([(1198, 1263)])
g.add_edges([(869, 1264)])
g.add_edges([(869, 1265)])
g.add_edges([(869, 1266)])
g.add_edges([(869, 1267)])
g.add_edges([(869, 1268)])
g.add_edges([(869, 1269)])
g.add_edges([(869, 1270)])
g.add_edges([(869, 1271)])
g.add_edges([(1866, 1272)])
g.add_edges([(2174, 1273)])
g.add_edges([(1492, 1275)])
g.add_edges([(869, 1276)])
g.add_edges([(1464, 1277)])
g.add_edges([(151, 1278)])
g.add_edges([(1768, 1279)])
g.add_edges([(2085, 1279)])
g.add_edges([(1497, 1280)])
g.add_edges([(1497, 1281)])
g.add_edges([(2085, 1281)])
g.add_edges([(1497, 1282)])
g.add_edges([(1729, 1283)])
g.add_edges([(768, 1284)])
g.add_edges([(769, 1284)])
g.add_edges([(2181, 1285)])
g.add_edges([(538, 1286)])
g.add_edges([(958, 1287)])
g.add_edges([(944, 1292)])
g.add_edges([(916, 1293)])
g.add_edges([(766, 1294)])
g.add_edges([(916, 1295)])
g.add_edges([(916, 1296)])
g.add_edges([(387, 1297)])
g.add_edges([(1312, 1298)])
g.add_edges([(1312, 1299)])
g.add_edges([(1312, 1300)])
g.add_edges([(643, 1301)])
g.add_edges([(1312, 1301)])
g.add_edges([(1461, 1302)])
g.add_edges([(1793, 1303)])
g.add_edges([(1497, 1305)])
g.add_edges([(2085, 1305)])
g.add_edges([(1373, 1306)])
g.add_edges([(1674, 1307)])
g.add_edges([(203, 1309)])
g.add_edges([(744, 1309)])
g.add_edges([(788, 1309)])
g.add_edges([(1087, 1309)])
g.add_edges([(395, 1310)])
g.add_edges([(397, 1310)])
g.add_edges([(408, 1310)])
g.add_edges([(1700, 1310)])
g.add_edges([(1866, 1310)])
g.add_edges([(706, 1311)])
g.add_edges([(916, 1327)])
g.add_edges([(916, 1329)])
g.add_edges([(1312, 1330)])
g.add_edges([(1312, 1331)])
g.add_edges([(2082, 1336)])
g.add_edges([(828, 1338)])
g.add_edges([(950, 1339)])
g.add_edges([(2017, 1341)])
g.add_edges([(1334, 1343)])
g.add_edges([(2015, 1343)])
g.add_edges([(2078, 1343)])
g.add_edges([(1700, 1344)])
g.add_edges([(643, 1348)])
g.add_edges([(1814, 1348)])
g.add_edges([(1932, 1349)])
g.add_edges([(1711, 1350)])
g.add_edges([(1599, 1351)])
g.add_edges([(1289, 1352)])
g.add_edges([(387, 1353)])
g.add_edges([(954, 1354)])
g.add_edges([(2181, 1355)])
g.add_edges([(1581, 1356)])
g.add_edges([(2181, 1357)])
g.add_edges([(2181, 1358)])
g.add_edges([(387, 1359)])
g.add_edges([(1814, 1360)])
g.add_edges([(643, 1361)])
g.add_edges([(1364, 1362)])
g.add_edges([(387, 1364)])
g.add_edges([(199, 1367)])
g.add_edges([(2164, 1367)])
g.add_edges([(1345, 1368)])
g.add_edges([(778, 1369)])
g.add_edges([(1897, 1369)])
g.add_edges([(113, 1372)])
g.add_edges([(748, 1372)])
g.add_edges([(1373, 1374)])
g.add_edges([(1026, 1375)])
g.add_edges([(395, 1376)])
g.add_edges([(199, 1377)])
g.add_edges([(397, 1377)])
g.add_edges([(399, 1377)])
g.add_edges([(1700, 1378)])
g.add_edges([(1866, 1380)])
g.add_edges([(408, 1381)])
g.add_edges([(1579, 1381)])
g.add_edges([(2164, 1381)])
g.add_edges([(1866, 1382)])
g.add_edges([(387, 1383)])
g.add_edges([(2164, 1384)])
g.add_edges([(1731, 1385)])
g.add_edges([(2133, 1387)])
g.add_edges([(1334, 1388)])
g.add_edges([(1524, 1389)])
g.add_edges([(1524, 1390)])
g.add_edges([(2088, 1391)])
g.add_edges([(2088, 1392)])
g.add_edges([(1524, 1393)])
g.add_edges([(1404, 1395)])
g.add_edges([(1572, 1395)])
g.add_edges([(2088, 1397)])
g.add_edges([(2181, 1399)])
g.add_edges([(2175, 1402)])
g.add_edges([(2145, 1403)])
g.add_edges([(1578, 1405)])
g.add_edges([(115, 1406)])
g.add_edges([(147, 1406)])
g.add_edges([(399, 1406)])
g.add_edges([(400, 1406)])
g.add_edges([(401, 1406)])
g.add_edges([(404, 1406)])
g.add_edges([(407, 1406)])
g.add_edges([(387, 1407)])
g.add_edges([(147, 1409)])
g.add_edges([(932, 1410)])
g.add_edges([(2088, 1412)])
g.add_edges([(199, 1413)])
g.add_edges([(2175, 1415)])
g.add_edges([(1711, 1416)])
g.add_edges([(2175, 1417)])
g.add_edges([(1370, 1419)])
g.add_edges([(1494, 1420)])
g.add_edges([(2175, 1421)])
g.add_edges([(2175, 1427)])
g.add_edges([(1599, 1428)])
g.add_edges([(1670, 1428)])
g.add_edges([(1711, 1429)])
g.add_edges([(1325, 1431)])
g.add_edges([(1578, 1431)])
g.add_edges([(2145, 1432)])
g.add_edges([(748, 1433)])
g.add_edges([(221, 1434)])
g.add_edges([(1323, 1435)])
g.add_edges([(887, 1436)])
g.add_edges([(778, 1437)])
g.add_edges([(1897, 1437)])
g.add_edges([(1067, 1438)])
g.add_edges([(1202, 1438)])
g.add_edges([(1981, 1439)])
g.add_edges([(1541, 1441)])
g.add_edges([(1312, 1442)])
g.add_edges([(1473, 1443)])
g.add_edges([(199, 1444)])
g.add_edges([(681, 1444)])
g.add_edges([(837, 1444)])
g.add_edges([(2164, 1444)])
g.add_edges([(536, 1445)])
g.add_edges([(1313, 1447)])
g.add_edges([(2237, 1447)])
g.add_edges([(387, 1453)])
g.add_edges([(387, 1454)])
g.add_edges([(663, 1455)])
g.add_edges([(1572, 1456)])
g.add_edges([(1475, 1470)])
g.add_edges([(2166, 1474)])
g.add_edges([(643, 1476)])
g.add_edges([(954, 1477)])
g.add_edges([(954, 1478)])
g.add_edges([(116, 1480)])
g.add_edges([(839, 1482)])
g.add_edges([(858, 1482)])
g.add_edges([(1448, 1483)])
g.add_edges([(839, 1485)])
g.add_edges([(858, 1485)])
g.add_edges([(387, 1486)])
g.add_edges([(211, 1487)])
g.add_edges([(2149, 1488)])
g.add_edges([(1604, 1489)])
g.add_edges([(1312, 1490)])
g.add_edges([(809, 1491)])
g.add_edges([(2181, 1491)])
g.add_edges([(387, 1494)])
g.add_edges([(1449, 1498)])
g.add_edges([(839, 1500)])
g.add_edges([(858, 1500)])
g.add_edges([(1814, 1501)])
g.add_edges([(839, 1502)])
g.add_edges([(858, 1502)])
g.add_edges([(839, 1503)])
g.add_edges([(858, 1503)])
g.add_edges([(1499, 1504)])
g.add_edges([(1604, 1505)])
g.add_edges([(387, 1506)])
g.add_edges([(1364, 1510)])
g.add_edges([(387, 1511)])
g.add_edges([(771, 1512)])
g.add_edges([(807, 1513)])
g.add_edges([(807, 1514)])
g.add_edges([(1475, 1515)])
g.add_edges([(1507, 1516)])
g.add_edges([(387, 1519)])
g.add_edges([(954, 1523)])
g.add_edges([(2082, 1525)])
g.add_edges([(1323, 1526)])
g.add_edges([(1674, 1526)])
g.add_edges([(1528, 1527)])
g.add_edges([(387, 1534)])
g.add_edges([(387, 1536)])
g.add_edges([(387, 1537)])
g.add_edges([(387, 1538)])
g.add_edges([(1497, 1543)])
g.add_edges([(1547, 1544)])
g.add_edges([(1547, 1545)])
g.add_edges([(1411, 1546)])
g.add_edges([(1548, 1549)])
g.add_edges([(1541, 1550)])
g.add_edges([(916, 1552)])
g.add_edges([(204, 1553)])
g.add_edges([(204, 1554)])
g.add_edges([(916, 1557)])
g.add_edges([(828, 1558)])
g.add_edges([(1814, 1559)])
g.add_edges([(1650, 1560)])
g.add_edges([(1789, 1560)])
g.add_edges([(786, 1561)])
g.add_edges([(1365, 1562)])
g.add_edges([(1499, 1563)])
g.add_edges([(991, 1564)])
g.add_edges([(1088, 1565)])
g.add_edges([(430, 1566)])
g.add_edges([(430, 1567)])
g.add_edges([(211, 1569)])
g.add_edges([(1495, 1569)])
g.add_edges([(211, 1570)])
g.add_edges([(1289, 1570)])
g.add_edges([(1495, 1570)])
g.add_edges([(2164, 1571)])
g.add_edges([(397, 1574)])
g.add_edges([(400, 1574)])
g.add_edges([(199, 1575)])
g.add_edges([(1866, 1575)])
g.add_edges([(438, 1576)])
g.add_edges([(2088, 1577)])
g.add_edges([(1710, 1580)])
g.add_edges([(1613, 1582)])
g.add_edges([(778, 1583)])
g.add_edges([(411, 1585)])
g.add_edges([(1687, 1588)])
g.add_edges([(916, 1589)])
g.add_edges([(703, 1591)])
g.add_edges([(1866, 1592)])
g.add_edges([(1373, 1594)])
g.add_edges([(774, 1595)])
g.add_edges([(1706, 1595)])
g.add_edges([(821, 1596)])
g.add_edges([(395, 1597)])
g.add_edges([(199, 1598)])
g.add_edges([(397, 1598)])
g.add_edges([(1866, 1598)])
g.add_edges([(1700, 1600)])
g.add_edges([(1866, 1601)])
g.add_edges([(407, 1602)])
g.add_edges([(408, 1602)])
g.add_edges([(2164, 1602)])
g.add_edges([(1866, 1603)])
g.add_edges([(1497, 1607)])
g.add_edges([(2004, 1608)])
g.add_edges([(1606, 1609)])
g.add_edges([(1606, 1610)])
g.add_edges([(147, 1611)])
g.add_edges([(773, 1612)])
g.add_edges([(777, 1612)])
g.add_edges([(430, 1614)])
g.add_edges([(2082, 1615)])
g.add_edges([(387, 1616)])
g.add_edges([(538, 1617)])
g.add_edges([(445, 1618)])
g.add_edges([(1006, 1619)])
g.add_edges([(2129, 1619)])
g.add_edges([(1440, 1620)])
g.add_edges([(1467, 1621)])
g.add_edges([(2129, 1622)])
g.add_edges([(2015, 1624)])
g.add_edges([(778, 1625)])
g.add_edges([(438, 1626)])
g.add_edges([(1814, 1628)])
g.add_edges([(430, 1630)])
g.add_edges([(430, 1631)])
g.add_edges([(1026, 1632)])
g.add_edges([(430, 1633)])
g.add_edges([(2182, 1634)])
g.add_edges([(115, 1635)])
g.add_edges([(869, 1636)])
g.add_edges([(1400, 1636)])
g.add_edges([(1401, 1636)])
g.add_edges([(1446, 1637)])
g.add_edges([(144, 1639)])
g.add_edges([(415, 1654)])
g.add_edges([(766, 1654)])
g.add_edges([(1519, 1655)])
g.add_edges([(2153, 1656)])
g.add_edges([(2153, 1657)])
g.add_edges([(1407, 1662)])
g.add_edges([(1407, 1663)])
g.add_edges([(932, 1664)])
g.add_edges([(917, 1665)])
g.add_edges([(917, 1666)])
g.add_edges([(1497, 1667)])
g.add_edges([(828, 1668)])
g.add_edges([(1407, 1669)])
g.add_edges([(617, 1672)])
g.add_edges([(1497, 1672)])
g.add_edges([(371, 1673)])
g.add_edges([(2002, 1673)])
g.add_edges([(1407, 1675)])
g.add_edges([(2174, 1676)])
g.add_edges([(1407, 1678)])
g.add_edges([(1692, 1679)])
g.add_edges([(116, 1680)])
g.add_edges([(1407, 1682)])
g.add_edges([(1407, 1683)])
g.add_edges([(943, 1684)])
g.add_edges([(1426, 1685)])
g.add_edges([(2127, 1685)])
g.add_edges([(779, 1688)])
g.add_edges([(779, 1689)])
g.add_edges([(973, 1690)])
g.add_edges([(1407, 1691)])
g.add_edges([(917, 1693)])
g.add_edges([(887, 1694)])
g.add_edges([(681, 1695)])
g.add_edges([(2174, 1696)])
g.add_edges([(1473, 1697)])
g.add_edges([(697, 1698)])
g.add_edges([(614, 1699)])
g.add_edges([(778, 1701)])
g.add_edges([(786, 1702)])
g.add_edges([(1473, 1703)])
g.add_edges([(196, 1707)])
g.add_edges([(403, 1707)])
g.add_edges([(1312, 1708)])
g.add_edges([(1312, 1712)])
g.add_edges([(828, 1713)])
g.add_edges([(1497, 1715)])
g.add_edges([(954, 1716)])
g.add_edges([(954, 1717)])
g.add_edges([(387, 1718)])
g.add_edges([(387, 1719)])
g.add_edges([(681, 1721)])
g.add_edges([(141, 1723)])
g.add_edges([(412, 1727)])
g.add_edges([(413, 1728)])
g.add_edges([(413, 1730)])
g.add_edges([(2164, 1732)])
g.add_edges([(1459, 1733)])
g.add_edges([(1459, 1734)])
g.add_edges([(1459, 1735)])
g.add_edges([(360, 1736)])
g.add_edges([(887, 1736)])
g.add_edges([(597, 1737)])
g.add_edges([(774, 1738)])
g.add_edges([(807, 1739)])
g.add_edges([(808, 1740)])
g.add_edges([(753, 1741)])
g.add_edges([(1551, 1742)])
g.add_edges([(916, 1743)])
g.add_edges([(1326, 1744)])
g.add_edges([(2076, 1744)])
g.add_edges([(2164, 1744)])
g.add_edges([(199, 1745)])
g.add_edges([(2164, 1745)])
g.add_edges([(1460, 1746)])
g.add_edges([(1373, 1747)])
g.add_edges([(81, 1748)])
g.add_edges([(1318, 1749)])
g.add_edges([(1322, 1749)])
g.add_edges([(1326, 1749)])
g.add_edges([(2076, 1749)])
g.add_edges([(774, 1750)])
g.add_edges([(536, 1751)])
g.add_edges([(199, 1752)])
g.add_edges([(2164, 1752)])
g.add_edges([(358, 1753)])
g.add_edges([(762, 1753)])
g.add_edges([(1208, 1753)])
g.add_edges([(1660, 1754)])
g.add_edges([(627, 1755)])
g.add_edges([(887, 1756)])
g.add_edges([(778, 1757)])
g.add_edges([(1461, 1757)])
g.add_edges([(1469, 1757)])
g.add_edges([(1897, 1757)])
g.add_edges([(1938, 1757)])
g.add_edges([(387, 1758)])
g.add_edges([(926, 1759)])
g.add_edges([(2163, 1759)])
g.add_edges([(1497, 1760)])
g.add_edges([(448, 1761)])
g.add_edges([(1226, 1762)])
g.add_edges([(1497, 1763)])
g.add_edges([(2073, 1764)])
g.add_edges([(1581, 1765)])
g.add_edges([(1711, 1766)])
g.add_edges([(1461, 1767)])
g.add_edges([(926, 1770)])
g.add_edges([(116, 1771)])
g.add_edges([(253, 1772)])
g.add_edges([(1334, 1772)])
g.add_edges([(1335, 1772)])
g.add_edges([(1499, 1772)])
g.add_edges([(476, 1773)])
g.add_edges([(1605, 1773)])
g.add_edges([(2031, 1773)])
g.add_edges([(2032, 1773)])
g.add_edges([(926, 1774)])
g.add_edges([(1866, 1775)])
g.add_edges([(694, 1776)])
g.add_edges([(1493, 1777)])
g.add_edges([(1469, 1778)])
g.add_edges([(435, 1779)])
g.add_edges([(2117, 1780)])
g.add_edges([(926, 1781)])
g.add_edges([(1706, 1782)])
g.add_edges([(926, 1783)])
g.add_edges([(430, 1784)])
g.add_edges([(448, 1785)])
g.add_edges([(926, 1786)])
g.add_edges([(924, 1787)])
g.add_edges([(924, 1788)])
g.add_edges([(926, 1790)])
g.add_edges([(1866, 1791)])
g.add_edges([(2117, 1792)])
g.add_edges([(448, 1794)])
g.add_edges([(1461, 1795)])
g.add_edges([(2117, 1796)])
g.add_edges([(2117, 1797)])
g.add_edges([(1866, 1798)])
g.add_edges([(435, 1799)])
g.add_edges([(2117, 1800)])
g.add_edges([(1312, 1801)])
g.add_edges([(924, 1802)])
g.add_edges([(147, 1806)])
g.add_edges([(663, 1807)])
g.add_edges([(536, 1808)])
g.add_edges([(597, 1810)])
g.add_edges([(1370, 1811)])
g.add_edges([(786, 1813)])
g.add_edges([(2088, 1815)])
g.add_edges([(2088, 1816)])
g.add_edges([(869, 1818)])
g.add_edges([(1400, 1818)])
g.add_edges([(199, 1819)])
g.add_edges([(2164, 1819)])
g.add_edges([(218, 1820)])
g.add_edges([(221, 1821)])
g.add_edges([(221, 1822)])
g.add_edges([(1722, 1823)])
g.add_edges([(643, 1824)])
g.add_edges([(536, 1825)])
g.add_edges([(643, 1826)])
g.add_edges([(1401, 1828)])
g.add_edges([(697, 1829)])
g.add_edges([(697, 1830)])
g.add_edges([(357, 1831)])
g.add_edges([(116, 1832)])
g.add_edges([(1929, 1833)])
g.add_edges([(383, 1834)])
g.add_edges([(560, 1834)])
g.add_edges([(869, 1834)])
g.add_edges([(1226, 1834)])
g.add_edges([(1359, 1835)])
g.add_edges([(1226, 1836)])
g.add_edges([(487, 1837)])
g.add_edges([(1400, 1838)])
g.add_edges([(371, 1839)])
g.add_edges([(1414, 1840)])
g.add_edges([(1572, 1840)])
g.add_edges([(1458, 1841)])
g.add_edges([(1006, 1842)])
g.add_edges([(383, 1843)])
g.add_edges([(869, 1843)])
g.add_edges([(838, 1844)])
g.add_edges([(830, 1845)])
g.add_edges([(2059, 1845)])
g.add_edges([(383, 1846)])
g.add_edges([(869, 1846)])
g.add_edges([(1929, 1847)])
g.add_edges([(1088, 1848)])
g.add_edges([(627, 1849)])
g.add_edges([(887, 1849)])
g.add_edges([(1365, 1850)])
g.add_edges([(430, 1851)])
g.add_edges([(1458, 1852)])
g.add_edges([(385, 1853)])
g.add_edges([(1458, 1854)])
g.add_edges([(1873, 1854)])
g.add_edges([(614, 1855)])
g.add_edges([(791, 1856)])
g.add_edges([(1519, 1857)])
g.add_edges([(954, 1858)])
g.add_edges([(1889, 1859)])
g.add_edges([(2137, 1860)])
g.add_edges([(1928, 1861)])
g.add_edges([(1629, 1862)])
g.add_edges([(1991, 1862)])
g.add_edges([(1460, 1863)])
g.add_edges([(1928, 1864)])
g.add_edges([(1465, 1867)])
g.add_edges([(1465, 1868)])
g.add_edges([(1465, 1869)])
g.add_edges([(787, 1870)])
g.add_edges([(917, 1870)])
g.add_edges([(954, 1870)])
g.add_edges([(141, 1871)])
g.add_edges([(1473, 1872)])
g.add_edges([(387, 1876)])
g.add_edges([(387, 1877)])
g.add_edges([(1887, 1879)])
g.add_edges([(387, 1880)])
g.add_edges([(387, 1881)])
g.add_edges([(387, 1882)])
g.add_edges([(387, 1884)])
g.add_edges([(387, 1885)])
g.add_edges([(1768, 1888)])
g.add_edges([(1426, 1890)])
g.add_edges([(2127, 1890)])
g.add_edges([(397, 1891)])
g.add_edges([(1866, 1892)])
g.add_edges([(1578, 1893)])
g.add_edges([(1578, 1894)])
g.add_edges([(1627, 1895)])
g.add_edges([(2090, 1896)])
g.add_edges([(199, 1898)])
g.add_edges([(1026, 1899)])
g.add_edges([(1473, 1900)])
g.add_edges([(415, 1901)])
g.add_edges([(1473, 1902)])
g.add_edges([(144, 1903)])
g.add_edges([(1578, 1905)])
g.add_edges([(411, 1908)])
g.add_edges([(681, 1909)])
g.add_edges([(953, 1910)])
g.add_edges([(952, 1911)])
g.add_edges([(2082, 1912)])
g.add_edges([(211, 1914)])
g.add_edges([(395, 1915)])
g.add_edges([(397, 1916)])
g.add_edges([(1866, 1916)])
g.add_edges([(1866, 1917)])
g.add_edges([(408, 1918)])
g.add_edges([(1866, 1919)])
g.add_edges([(112, 1920)])
g.add_edges([(357, 1921)])
g.add_edges([(2004, 1921)])
g.add_edges([(898, 1922)])
g.add_edges([(766, 1923)])
g.add_edges([(1312, 1924)])
g.add_edges([(774, 1925)])
g.add_edges([(794, 1926)])
g.add_edges([(2004, 1930)])
g.add_edges([(778, 1931)])
g.add_edges([(808, 1931)])
g.add_edges([(1006, 1931)])
g.add_edges([(1334, 1931)])
g.add_edges([(1373, 1931)])
g.add_edges([(1897, 1931)])
g.add_edges([(2015, 1931)])
g.add_edges([(2181, 1931)])
g.add_edges([(1718, 1933)])
g.add_edges([(392, 1934)])
g.add_edges([(2174, 1935)])
g.add_edges([(1932, 1936)])
g.add_edges([(445, 1937)])
g.add_edges([(387, 1940)])
g.add_edges([(1932, 1941)])
g.add_edges([(141, 1942)])
g.add_edges([(1323, 1943)])
g.add_edges([(1932, 1943)])
g.add_edges([(808, 1944)])
g.add_edges([(1519, 1945)])
g.add_edges([(2181, 1946)])
g.add_edges([(1323, 1947)])
g.add_edges([(1932, 1947)])
g.add_edges([(1718, 1948)])
g.add_edges([(1718, 1949)])
g.add_edges([(1718, 1950)])
g.add_edges([(610, 1951)])
g.add_edges([(1460, 1952)])
g.add_edges([(1460, 1953)])
g.add_edges([(211, 1954)])
g.add_edges([(1627, 1954)])
g.add_edges([(2088, 1955)])
g.add_edges([(1006, 1956)])
g.add_edges([(2129, 1956)])
g.add_edges([(1475, 1957)])
g.add_edges([(2129, 1958)])
g.add_edges([(1492, 1959)])
g.add_edges([(610, 1960)])
g.add_edges([(1981, 1962)])
g.add_edges([(415, 1964)])
g.add_edges([(1359, 1966)])
g.add_edges([(199, 1968)])
g.add_edges([(2164, 1968)])
g.add_edges([(476, 1970)])
g.add_edges([(254, 1971)])
g.add_edges([(415, 1972)])
g.add_edges([(1905, 1973)])
g.add_edges([(536, 1974)])
g.add_edges([(357, 1975)])
g.add_edges([(774, 1977)])
g.add_edges([(1967, 1978)])
g.add_edges([(486, 1979)])
g.add_edges([(2181, 1982)])
g.add_edges([(1670, 1983)])
g.add_edges([(1984, 1985)])
g.add_edges([(681, 1986)])
g.add_edges([(810, 1987)])
g.add_edges([(2164, 1989)])
g.add_edges([(2181, 1990)])
g.add_edges([(2175, 1992)])
g.add_edges([(954, 1994)])
g.add_edges([(954, 1995)])
g.add_edges([(1454, 1996)])
g.add_edges([(1998, 1997)])
g.add_edges([(2129, 2000)])
g.add_edges([(1984, 2001)])
g.add_edges([(438, 2005)])
g.add_edges([(536, 2006)])
g.add_edges([(2100, 2009)])
g.add_edges([(2101, 2009)])
g.add_edges([(1873, 2010)])
g.add_edges([(1359, 2011)])
g.add_edges([(916, 2012)])
g.add_edges([(880, 2013)])
g.add_edges([(1638, 2013)])
g.add_edges([(954, 2014)])
g.add_edges([(887, 2016)])
g.add_edges([(1692, 2018)])
g.add_edges([(2015, 2019)])
g.add_edges([(748, 2020)])
g.add_edges([(2267, 2021)])
g.add_edges([(869, 2024)])
g.add_edges([(1578, 2025)])
g.add_edges([(396, 2027)])
g.add_edges([(199, 2028)])
g.add_edges([(397, 2028)])
g.add_edges([(404, 2028)])
g.add_edges([(1866, 2028)])
g.add_edges([(392, 2030)])
g.add_edges([(341, 2033)])
g.add_edges([(778, 2033)])
g.add_edges([(2181, 2034)])
g.add_edges([(116, 2035)])
g.add_edges([(767, 2036)])
g.add_edges([(2154, 2037)])
g.add_edges([(219, 2038)])
g.add_edges([(643, 2039)])
g.add_edges([(1706, 2040)])
g.add_edges([(767, 2041)])
g.add_edges([(486, 2043)])
g.add_edges([(487, 2044)])
g.add_edges([(2042, 2045)])
g.add_edges([(1627, 2046)])
g.add_edges([(1289, 2047)])
g.add_edges([(1670, 2048)])
g.add_edges([(1981, 2049)])
g.add_edges([(1980, 2050)])
g.add_edges([(1373, 2051)])
g.add_edges([(118, 2052)])
g.add_edges([(2082, 2053)])
g.add_edges([(766, 2054)])
g.add_edges([(218, 2055)])
g.add_edges([(1312, 2056)])
g.add_edges([(397, 2057)])
g.add_edges([(1866, 2057)])
g.add_edges([(1814, 2061)])
g.add_edges([(1814, 2062)])
g.add_edges([(1814, 2063)])
g.add_edges([(1814, 2064)])
g.add_edges([(778, 2065)])
g.add_edges([(1897, 2065)])
g.add_edges([(1613, 2066)])
g.add_edges([(1494, 2067)])
g.add_edges([(953, 2068)])
g.add_edges([(435, 2069)])
g.add_edges([(413, 2070)])
g.add_edges([(536, 2074)])
g.add_edges([(926, 2075)])
g.add_edges([(1578, 2079)])
g.add_edges([(1400, 2080)])
g.add_edges([(435, 2083)])
g.add_edges([(1312, 2084)])
g.add_edges([(1905, 2086)])
g.add_edges([(821, 2087)])
g.add_edges([(944, 2089)])
g.add_edges([(7, 2090)])
g.add_edges([(2092, 2091)])
g.add_edges([(1345, 2093)])
g.add_edges([(2096, 2093)])
g.add_edges([(1345, 2094)])
g.add_edges([(1345, 2095)])
g.add_edges([(1497, 2098)])
g.add_edges([(2129, 2102)])
g.add_edges([(2129, 2103)])
g.add_edges([(916, 2104)])
g.add_edges([(1866, 2105)])
g.add_edges([(1866, 2106)])
g.add_edges([(916, 2107)])
g.add_edges([(1731, 2109)])
g.add_edges([(2109, 2110)])
g.add_edges([(147, 2111)])
g.add_edges([(1006, 2111)])
g.add_edges([(387, 2112)])
g.add_edges([(405, 2112)])
g.add_edges([(430, 2112)])
g.add_edges([(810, 2115)])
g.add_edges([(2174, 2115)])
g.add_edges([(809, 2116)])
g.add_edges([(2174, 2118)])
g.add_edges([(1578, 2119)])
g.add_edges([(205, 2121)])
g.add_edges([(2174, 2122)])
g.add_edges([(2120, 2123)])
g.add_edges([(1866, 2125)])
g.add_edges([(2131, 2126)])
g.add_edges([(397, 2128)])
g.add_edges([(1866, 2128)])
g.add_edges([(1627, 2135)])
g.add_edges([(2137, 2136)])
g.add_edges([(2175, 2138)])
g.add_edges([(1627, 2140)])
g.add_edges([(1627, 2141)])
g.add_edges([(1700, 2142)])
g.add_edges([(2174, 2144)])
g.add_edges([(1866, 2146)])
g.add_edges([(408, 2147)])
g.add_edges([(1866, 2148)])
g.add_edges([(1006, 2150)])
g.add_edges([(2129, 2150)])
g.add_edges([(2129, 2151)])
g.add_edges([(1323, 2152)])
g.add_edges([(1323, 2155)])
g.add_edges([(1323, 2156)])
g.add_edges([(942, 2157)])
g.add_edges([(954, 2158)])
g.add_edges([(954, 2159)])
g.add_edges([(2164, 2160)])
g.add_edges([(681, 2161)])
g.add_edges([(1499, 2162)])
g.add_edges([(2145, 2167)])
g.add_edges([(2145, 2168)])
g.add_edges([(419, 2169)])
g.add_edges([(0, 2170)])
g.add_edges([(2082, 2172)])
g.add_edges([(774, 2176)])
g.add_edges([(689, 2177)])
g.add_edges([(689, 2178)])
g.add_edges([(689, 2180)])
g.add_edges([(211, 2183)])
g.add_edges([(1805, 2184)])
g.add_edges([(1464, 2185)])
g.add_edges([(1464, 2186)])
g.add_edges([(1464, 2187)])
g.add_edges([(2112, 2189)])
g.add_edges([(2112, 2190)])
g.add_edges([(2096, 2191)])
g.add_edges([(1345, 2192)])
g.add_edges([(2096, 2192)])
g.add_edges([(1873, 2193)])
g.add_edges([(2112, 2194)])
g.add_edges([(211, 2195)])
g.add_edges([(1804, 2196)])
g.add_edges([(1519, 2197)])
g.add_edges([(418, 2198)])
g.add_edges([(779, 2198)])
g.add_edges([(1006, 2198)])
g.add_edges([(1687, 2198)])
g.add_edges([(418, 2199)])
g.add_edges([(1729, 2200)])
g.add_edges([(954, 2201)])
g.add_edges([(1729, 2202)])
g.add_edges([(418, 2203)])
g.add_edges([(1648, 2204)])
g.add_edges([(218, 2205)])
g.add_edges([(1519, 2206)])
g.add_edges([(2112, 2207)])
g.add_edges([(2112, 2208)])
g.add_edges([(2112, 2209)])
g.add_edges([(2112, 2210)])
g.add_edges([(1873, 2211)])
g.add_edges([(2112, 2212)])
g.add_edges([(2112, 2213)])
g.add_edges([(2112, 2214)])
g.add_edges([(2112, 2215)])
g.add_edges([(1648, 2216)])
g.add_edges([(954, 2217)])
g.add_edges([(2112, 2218)])
g.add_edges([(2112, 2219)])
g.add_edges([(2112, 2220)])
g.add_edges([(1991, 2221)])
g.add_edges([(1484, 2223)])
g.add_edges([(1651, 2223)])
g.add_edges([(1519, 2224)])
g.add_edges([(917, 2225)])
g.add_edges([(1519, 2226)])
g.add_edges([(1484, 2227)])
g.add_edges([(216, 2228)])
g.add_edges([(371, 2229)])
g.add_edges([(1519, 2230)])
g.add_edges([(1866, 2231)])
g.add_edges([(2112, 2232)])
g.add_edges([(786, 2233)])
g.add_edges([(942, 2234)])
g.add_edges([(172, 2235)])
g.add_edges([(1644, 2235)])
g.add_edges([(371, 2236)])
g.add_edges([(211, 2238)])
g.add_edges([(808, 2239)])
g.add_edges([(1289, 2240)])
g.add_edges([(1653, 2241)])
g.add_edges([(1345, 2242)])
g.add_edges([(2096, 2242)])
g.add_edges([(1627, 2243)])
g.add_edges([(386, 2244)])
g.add_edges([(211, 2245)])
g.add_edges([(786, 2246)])
g.add_edges([(1345, 2247)])
g.add_edges([(2112, 2248)])
g.add_edges([(1373, 2249)])
g.add_edges([(2112, 2250)])
g.add_edges([(2112, 2251)])
g.add_edges([(917, 2252)])
g.add_edges([(1506, 2253)])
g.add_edges([(1519, 2253)])
g.add_edges([(1289, 2254)])
g.add_edges([(218, 2255)])
g.add_edges([(1345, 2255)])
g.add_edges([(1805, 2255)])
g.add_edges([(2096, 2255)])
g.add_edges([(1913, 2256)])
g.add_edges([(2222, 2257)])
g.add_edges([(807, 2258)])
g.add_edges([(1497, 2259)])
g.add_edges([(2112, 2260)])
g.add_edges([(2112, 2261)])
g.add_edges([(2112, 2262)])
g.add_edges([(1519, 2263)])
g.add_edges([(1928, 2264)])
g.add_edges([(774, 2265)])
g.add_edges([(2078, 2268)])
g.add_edges([(560, 2271)])









g.vs["type"]="Notset"


g.vs[0]["type"]="script"
g.vs[1]["type"]="mod"
g.vs[2]["type"]="mod"
g.vs[3]["type"]="mod"
g.vs[4]["type"]="mod"
g.vs[5]["type"]="sub"
g.vs[6]["type"]="script"
g.vs[7]["type"]="script"
g.vs[8]["type"]="sub"
g.vs[9]["type"]="mod"
g.vs[10]["type"]="mod"
g.vs[11]["type"]="mod"
g.vs[12]["type"]="mod"
g.vs[13]["type"]="mod"
g.vs[14]["type"]="mod"
g.vs[15]["type"]="mod"
g.vs[16]["type"]="mod"
g.vs[17]["type"]="mod"
g.vs[18]["type"]="mod"
g.vs[19]["type"]="mod"
g.vs[20]["type"]="mod"
g.vs[21]["type"]="mod"
g.vs[22]["type"]="mod"
g.vs[23]["type"]="mod"
g.vs[24]["type"]="mod"
g.vs[25]["type"]="mod"
g.vs[26]["type"]="mod"
g.vs[27]["type"]="mod"
g.vs[28]["type"]="mod"
g.vs[29]["type"]="mod"
g.vs[30]["type"]="mod"
g.vs[31]["type"]="mod"
g.vs[32]["type"]="mod"
g.vs[33]["type"]="mod"
g.vs[34]["type"]="mod"
g.vs[35]["type"]="mod"
g.vs[36]["type"]="mod"
g.vs[37]["type"]="mod"
g.vs[38]["type"]="mod"
g.vs[39]["type"]="mod"
g.vs[40]["type"]="mod"
g.vs[41]["type"]="mod"
g.vs[42]["type"]="mod"
g.vs[43]["type"]="mod"
g.vs[44]["type"]="mod"
g.vs[45]["type"]="mod"
g.vs[46]["type"]="mod"
g.vs[47]["type"]="mod"
g.vs[48]["type"]="mod"
g.vs[49]["type"]="mod"
g.vs[50]["type"]="mod"
g.vs[51]["type"]="mod"
g.vs[52]["type"]="mod"
g.vs[53]["type"]="mod"
g.vs[54]["type"]="mod"
g.vs[55]["type"]="mod"
g.vs[56]["type"]="mod"
g.vs[57]["type"]="mod"
g.vs[58]["type"]="mod"
g.vs[59]["type"]="mod"
g.vs[60]["type"]="mod"
g.vs[61]["type"]="mod"
g.vs[62]["type"]="mod"
g.vs[63]["type"]="mod"
g.vs[64]["type"]="mod"
g.vs[65]["type"]="mod"
g.vs[66]["type"]="mod"
g.vs[67]["type"]="mod"
g.vs[68]["type"]="mod"
g.vs[69]["type"]="mod"
g.vs[70]["type"]="mod"
g.vs[71]["type"]="mod"
g.vs[72]["type"]="mod"
g.vs[73]["type"]="mod"
g.vs[74]["type"]="mod"
g.vs[75]["type"]="mod"
g.vs[76]["type"]="mod"
g.vs[77]["type"]="mod"
g.vs[78]["type"]="mod"
g.vs[79]["type"]="mod"
g.vs[80]["type"]="sub"
g.vs[81]["type"]="script"
g.vs[82]["type"]="sub"
g.vs[83]["type"]="mod"
g.vs[84]["type"]="mod"
g.vs[85]["type"]="script"
g.vs[86]["type"]="sub"
g.vs[87]["type"]="sub"
g.vs[88]["type"]="sub"
g.vs[89]["type"]="sub"
g.vs[90]["type"]="mod"
g.vs[91]["type"]="sub"
g.vs[92]["type"]="sub"
g.vs[93]["type"]="mod"
g.vs[94]["type"]="mod"
g.vs[95]["type"]="mod"
g.vs[96]["type"]="mod"
g.vs[97]["type"]="mod"
g.vs[98]["type"]="sub"
g.vs[99]["type"]="script"
g.vs[100]["type"]="mod"
g.vs[101]["type"]="sub"
g.vs[102]["type"]="mod"
g.vs[103]["type"]="mod"
g.vs[104]["type"]="mod"
g.vs[105]["type"]="sub"
g.vs[106]["type"]="sub"
g.vs[107]["type"]="sub"
g.vs[108]["type"]="mod"
g.vs[109]["type"]="mod"
g.vs[110]["type"]="mod"
g.vs[111]["type"]="sub"
g.vs[112]["type"]="script"
g.vs[113]["type"]="script"
g.vs[114]["type"]="mod"
g.vs[115]["type"]="script"
g.vs[116]["type"]="script"
g.vs[117]["type"]="script"
g.vs[118]["type"]="script"
g.vs[119]["type"]="script"
g.vs[120]["type"]="script"
g.vs[121]["type"]="mod"
g.vs[123]["type"]="script"
g.vs[124]["type"]="mod"
g.vs[125]["type"]="sub"
g.vs[126]["type"]="mod"
g.vs[127]["type"]="mod"
g.vs[128]["type"]="mod"
g.vs[129]["type"]="sub"
g.vs[130]["type"]="mod"
g.vs[131]["type"]="mod"
g.vs[132]["type"]="mod"
g.vs[133]["type"]="mod"
g.vs[134]["type"]="mod"
g.vs[135]["type"]="mod"
g.vs[136]["type"]="mod"
g.vs[137]["type"]="sub"
g.vs[138]["type"]="sub"
g.vs[139]["type"]="sub"
g.vs[140]["type"]="script"
g.vs[141]["type"]="script"
g.vs[142]["type"]="sub"
g.vs[143]["type"]="sub"
g.vs[144]["type"]="script"
g.vs[145]["type"]="script"
g.vs[146]["type"]="mod"
g.vs[147]["type"]="script"
g.vs[148]["type"]="mod"
g.vs[149]["type"]="mod"
g.vs[150]["type"]="mod"
g.vs[151]["type"]="script"
g.vs[152]["type"]="script"
g.vs[153]["type"]="sub"
g.vs[154]["type"]="mod"
g.vs[155]["type"]="mod"
g.vs[156]["type"]="mod"
g.vs[157]["type"]="mod"
g.vs[158]["type"]="script"
g.vs[159]["type"]="mod"
g.vs[160]["type"]="mod"
g.vs[161]["type"]="mod"
g.vs[162]["type"]="mod"
g.vs[163]["type"]="mod"
g.vs[164]["type"]="mod"
g.vs[165]["type"]="mod"
g.vs[166]["type"]="script"
g.vs[167]["type"]="mod"
g.vs[168]["type"]="mod"
g.vs[169]["type"]="mod"
g.vs[170]["type"]="mod"
g.vs[171]["type"]="mod"
g.vs[172]["type"]="script"
g.vs[173]["type"]="sub"
g.vs[174]["type"]="sub"
g.vs[175]["type"]="mod"
g.vs[176]["type"]="mod"
g.vs[177]["type"]="mod"
g.vs[178]["type"]="mod"
g.vs[179]["type"]="mod"
g.vs[180]["type"]="mod"
g.vs[181]["type"]="mod"
g.vs[182]["type"]="mod"
g.vs[183]["type"]="mod"
g.vs[184]["type"]="mod"
g.vs[185]["type"]="mod"
g.vs[186]["type"]="mod"
g.vs[187]["type"]="mod"
g.vs[188]["type"]="mod"
g.vs[189]["type"]="mod"
g.vs[190]["type"]="mod"
g.vs[191]["type"]="mod"
g.vs[192]["type"]="mod"
g.vs[193]["type"]="mod"
g.vs[194]["type"]="mod"
g.vs[195]["type"]="mod"
g.vs[196]["type"]="script"
g.vs[197]["type"]="mod"
g.vs[198]["type"]="mod"
g.vs[199]["type"]="script"
g.vs[200]["type"]="mod"
g.vs[201]["type"]="sub"
g.vs[202]["type"]="sub"
g.vs[203]["type"]="script"
g.vs[204]["type"]="script"
g.vs[205]["type"]="script"
g.vs[206]["type"]="mod"
g.vs[207]["type"]="sub"
g.vs[208]["type"]="sub"
g.vs[209]["type"]="mod"
g.vs[210]["type"]="script"
g.vs[211]["type"]="script"
g.vs[212]["type"]="script"
g.vs[213]["type"]="script"
g.vs[214]["type"]="script"
g.vs[215]["type"]="script"
g.vs[216]["type"]="script"
g.vs[217]["type"]="script"
g.vs[218]["type"]="script"
g.vs[219]["type"]="script"
g.vs[220]["type"]="script"
g.vs[221]["type"]="script"
g.vs[222]["type"]="mod"
g.vs[223]["type"]="sub"
g.vs[224]["type"]="sub"
g.vs[225]["type"]="script"
g.vs[226]["type"]="mod"
g.vs[227]["type"]="mod"
g.vs[228]["type"]="sub"
g.vs[229]["type"]="mod"
g.vs[230]["type"]="mod"
g.vs[231]["type"]="mod"
g.vs[232]["type"]="mod"
g.vs[233]["type"]="sub"
g.vs[234]["type"]="mod"
g.vs[235]["type"]="sub"
g.vs[236]["type"]="mod"
g.vs[238]["type"]="sub"
g.vs[239]["type"]="script"
g.vs[240]["type"]="mod"
g.vs[241]["type"]="mod"
g.vs[242]["type"]="mod"
g.vs[243]["type"]="mod"
g.vs[244]["type"]="mod"
g.vs[245]["type"]="mod"
g.vs[246]["type"]="mod"
g.vs[247]["type"]="mod"
g.vs[248]["type"]="mod"
g.vs[249]["type"]="mod"
g.vs[250]["type"]="mod"
g.vs[251]["type"]="mod"
g.vs[252]["type"]="sub"
g.vs[253]["type"]="script"
g.vs[254]["type"]="script"
g.vs[255]["type"]="mod"
g.vs[256]["type"]="script"
g.vs[257]["type"]="script"
g.vs[258]["type"]="mod"
g.vs[259]["type"]="mod"
g.vs[260]["type"]="mod"
g.vs[261]["type"]="mod"
g.vs[262]["type"]="mod"
g.vs[263]["type"]="mod"
g.vs[264]["type"]="mod"
g.vs[265]["type"]="mod"
g.vs[266]["type"]="mod"
g.vs[267]["type"]="mod"
g.vs[268]["type"]="sub"
g.vs[269]["type"]="mod"
g.vs[270]["type"]="mod"
g.vs[271]["type"]="mod"
g.vs[272]["type"]="mod"
g.vs[273]["type"]="mod"
g.vs[274]["type"]="mod"
g.vs[275]["type"]="mod"
g.vs[276]["type"]="mod"
g.vs[277]["type"]="mod"
g.vs[278]["type"]="mod"
g.vs[279]["type"]="mod"
g.vs[280]["type"]="mod"
g.vs[281]["type"]="mod"
g.vs[282]["type"]="mod"
g.vs[283]["type"]="mod"
g.vs[284]["type"]="mod"
g.vs[285]["type"]="mod"
g.vs[286]["type"]="mod"
g.vs[287]["type"]="sub"
g.vs[288]["type"]="sub"
g.vs[289]["type"]="sub"
g.vs[290]["type"]="sub"
g.vs[291]["type"]="sub"
g.vs[292]["type"]="sub"
g.vs[293]["type"]="sub"
g.vs[294]["type"]="sub"
g.vs[295]["type"]="sub"
g.vs[296]["type"]="sub"
g.vs[297]["type"]="sub"
g.vs[298]["type"]="sub"
g.vs[299]["type"]="sub"
g.vs[300]["type"]="sub"
g.vs[301]["type"]="sub"
g.vs[302]["type"]="sub"
g.vs[303]["type"]="sub"
g.vs[304]["type"]="sub"
g.vs[305]["type"]="sub"
g.vs[306]["type"]="sub"
g.vs[307]["type"]="sub"
g.vs[308]["type"]="sub"
g.vs[309]["type"]="sub"
g.vs[310]["type"]="sub"
g.vs[311]["type"]="script"
g.vs[312]["type"]="sub"
g.vs[313]["type"]="sub"
g.vs[314]["type"]="script"
g.vs[315]["type"]="script"
g.vs[316]["type"]="script"
g.vs[317]["type"]="sub"
g.vs[318]["type"]="sub"
g.vs[319]["type"]="sub"
g.vs[320]["type"]="sub"
g.vs[321]["type"]="sub"
g.vs[322]["type"]="sub"
g.vs[323]["type"]="sub"
g.vs[324]["type"]="sub"
g.vs[325]["type"]="sub"
g.vs[326]["type"]="sub"
g.vs[327]["type"]="sub"
g.vs[328]["type"]="script"
g.vs[329]["type"]="sub"
g.vs[330]["type"]="sub"
g.vs[331]["type"]="script"
g.vs[332]["type"]="script"
g.vs[333]["type"]="sub"
g.vs[334]["type"]="sub"
g.vs[335]["type"]="sub"
g.vs[336]["type"]="sub"
g.vs[337]["type"]="sub"
g.vs[338]["type"]="sub"
g.vs[339]["type"]="script"
g.vs[340]["type"]="sub"
g.vs[341]["type"]="script"
g.vs[342]["type"]="sub"
g.vs[343]["type"]="sub"
g.vs[344]["type"]="sub"
g.vs[345]["type"]="sub"
g.vs[346]["type"]="sub"
g.vs[347]["type"]="sub"
g.vs[348]["type"]="script"
g.vs[349]["type"]="sub"
g.vs[350]["type"]="script"
g.vs[351]["type"]="sub"
g.vs[352]["type"]="sub"
g.vs[353]["type"]="sub"
g.vs[354]["type"]="sub"
g.vs[355]["type"]="sub"
g.vs[356]["type"]="sub"
g.vs[357]["type"]="script"
g.vs[358]["type"]="script"
g.vs[359]["type"]="sub"
g.vs[360]["type"]="script"
g.vs[361]["type"]="sub"
g.vs[362]["type"]="sub"
g.vs[363]["type"]="script"
g.vs[364]["type"]="script"
g.vs[365]["type"]="script"
g.vs[366]["type"]="sub"
g.vs[367]["type"]="script"
g.vs[368]["type"]="sub"
g.vs[369]["type"]="sub"
g.vs[370]["type"]="sub"
g.vs[371]["type"]="script"
g.vs[372]["type"]="sub"
g.vs[373]["type"]="sub"
g.vs[374]["type"]="sub"
g.vs[375]["type"]="sub"
g.vs[376]["type"]="sub"
g.vs[377]["type"]="script"
g.vs[378]["type"]="sub"
g.vs[379]["type"]="sub"
g.vs[380]["type"]="script"
g.vs[381]["type"]="script"
g.vs[382]["type"]="sub"
g.vs[383]["type"]="script"
g.vs[384]["type"]="sub"
g.vs[385]["type"]="script"
g.vs[386]["type"]="script"
g.vs[387]["type"]="script"
g.vs[388]["type"]="mod"
g.vs[389]["type"]="sub"
g.vs[390]["type"]="sub"
g.vs[391]["type"]="sub"
g.vs[392]["type"]="script"
g.vs[393]["type"]="script"
g.vs[394]["type"]="script"
g.vs[395]["type"]="script"
g.vs[396]["type"]="script"
g.vs[397]["type"]="script"
g.vs[398]["type"]="script"
g.vs[399]["type"]="script"
g.vs[400]["type"]="script"
g.vs[401]["type"]="script"
g.vs[402]["type"]="script"
g.vs[403]["type"]="script"
g.vs[404]["type"]="script"
g.vs[405]["type"]="script"
g.vs[406]["type"]="script"
g.vs[407]["type"]="script"
g.vs[408]["type"]="script"
g.vs[409]["type"]="sub"
g.vs[410]["type"]="sub"
g.vs[411]["type"]="script"
g.vs[412]["type"]="script"
g.vs[413]["type"]="script"
g.vs[414]["type"]="sub"
g.vs[415]["type"]="script"
g.vs[416]["type"]="script"
g.vs[417]["type"]="sub"
g.vs[418]["type"]="script"
g.vs[419]["type"]="script"
g.vs[420]["type"]="sub"
g.vs[421]["type"]="sub"
g.vs[422]["type"]="sub"
g.vs[423]["type"]="sub"
g.vs[424]["type"]="sub"
g.vs[425]["type"]="sub"
g.vs[426]["type"]="sub"
g.vs[427]["type"]="script"
g.vs[428]["type"]="sub"
g.vs[429]["type"]="script"
g.vs[430]["type"]="script"
g.vs[431]["type"]="sub"
g.vs[432]["type"]="script"
g.vs[433]["type"]="sub"
g.vs[434]["type"]="sub"
g.vs[435]["type"]="script"
g.vs[436]["type"]="sub"
g.vs[437]["type"]="sub"
g.vs[438]["type"]="script"
g.vs[439]["type"]="sub"
g.vs[440]["type"]="sub"
g.vs[441]["type"]="sub"
g.vs[442]["type"]="sub"
g.vs[443]["type"]="sub"
g.vs[444]["type"]="script"
g.vs[445]["type"]="script"
g.vs[446]["type"]="sub"
g.vs[447]["type"]="sub"
g.vs[448]["type"]="script"
g.vs[449]["type"]="script"
g.vs[450]["type"]="script"
g.vs[451]["type"]="script"
g.vs[452]["type"]="sub"
g.vs[453]["type"]="sub"
g.vs[454]["type"]="sub"
g.vs[455]["type"]="sub"
g.vs[456]["type"]="sub"
g.vs[457]["type"]="sub"
g.vs[458]["type"]="sub"
g.vs[459]["type"]="sub"
g.vs[460]["type"]="sub"
g.vs[461]["type"]="sub"
g.vs[462]["type"]="sub"
g.vs[463]["type"]="sub"
g.vs[464]["type"]="sub"
g.vs[465]["type"]="sub"
g.vs[466]["type"]="sub"
g.vs[467]["type"]="sub"
g.vs[468]["type"]="sub"
g.vs[469]["type"]="sub"
g.vs[470]["type"]="sub"
g.vs[471]["type"]="sub"
g.vs[472]["type"]="sub"
g.vs[473]["type"]="sub"
g.vs[474]["type"]="script"
g.vs[475]["type"]="script"
g.vs[476]["type"]="script"
g.vs[477]["type"]="sub"
g.vs[478]["type"]="script"
g.vs[479]["type"]="sub"
g.vs[480]["type"]="script"
g.vs[481]["type"]="script"
g.vs[482]["type"]="sub"
g.vs[483]["type"]="script"
g.vs[484]["type"]="sub"
g.vs[485]["type"]="sub"
g.vs[486]["type"]="script"
g.vs[487]["type"]="script"
g.vs[488]["type"]="sub"
g.vs[489]["type"]="sub"
g.vs[490]["type"]="sub"
g.vs[491]["type"]="sub"
g.vs[492]["type"]="sub"
g.vs[493]["type"]="sub"
g.vs[494]["type"]="script"
g.vs[495]["type"]="sub"
g.vs[496]["type"]="sub"
g.vs[497]["type"]="sub"
g.vs[498]["type"]="sub"
g.vs[499]["type"]="sub"
g.vs[500]["type"]="sub"
g.vs[501]["type"]="sub"
g.vs[502]["type"]="sub"
g.vs[503]["type"]="sub"
g.vs[504]["type"]="sub"
g.vs[505]["type"]="sub"
g.vs[506]["type"]="sub"
g.vs[507]["type"]="sub"
g.vs[508]["type"]="sub"
g.vs[509]["type"]="sub"
g.vs[510]["type"]="script"
g.vs[511]["type"]="sub"
g.vs[512]["type"]="sub"
g.vs[513]["type"]="script"
g.vs[514]["type"]="sub"
g.vs[515]["type"]="sub"
g.vs[516]["type"]="sub"
g.vs[517]["type"]="sub"
g.vs[518]["type"]="script"
g.vs[519]["type"]="sub"
g.vs[520]["type"]="sub"
g.vs[521]["type"]="script"
g.vs[522]["type"]="sub"
g.vs[523]["type"]="sub"
g.vs[524]["type"]="sub"
g.vs[525]["type"]="sub"
g.vs[526]["type"]="sub"
g.vs[527]["type"]="sub"
g.vs[528]["type"]="sub"
g.vs[529]["type"]="sub"
g.vs[530]["type"]="sub"
g.vs[531]["type"]="script"
g.vs[532]["type"]="sub"
g.vs[533]["type"]="sub"
g.vs[534]["type"]="sub"
g.vs[535]["type"]="sub"
g.vs[536]["type"]="script"
g.vs[537]["type"]="script"
g.vs[538]["type"]="script"
g.vs[539]["type"]="sub"
g.vs[540]["type"]="script"
g.vs[541]["type"]="sub"
g.vs[542]["type"]="sub"
g.vs[543]["type"]="script"
g.vs[544]["type"]="sub"
g.vs[545]["type"]="sub"
g.vs[546]["type"]="script"
g.vs[547]["type"]="sub"
g.vs[548]["type"]="sub"
g.vs[549]["type"]="sub"
g.vs[550]["type"]="sub"
g.vs[551]["type"]="sub"
g.vs[552]["type"]="sub"
g.vs[553]["type"]="sub"
g.vs[554]["type"]="sub"
g.vs[555]["type"]="sub"
g.vs[556]["type"]="sub"
g.vs[557]["type"]="sub"
g.vs[558]["type"]="sub"
g.vs[559]["type"]="sub"
g.vs[560]["type"]="script"
g.vs[561]["type"]="script"
g.vs[562]["type"]="sub"
g.vs[563]["type"]="sub"
g.vs[564]["type"]="sub"
g.vs[565]["type"]="sub"
g.vs[566]["type"]="sub"
g.vs[567]["type"]="sub"
g.vs[568]["type"]="sub"
g.vs[569]["type"]="sub"
g.vs[570]["type"]="sub"
g.vs[571]["type"]="sub"
g.vs[572]["type"]="sub"
g.vs[573]["type"]="sub"
g.vs[574]["type"]="sub"
g.vs[575]["type"]="script"
g.vs[576]["type"]="sub"
g.vs[577]["type"]="script"
g.vs[578]["type"]="sub"
g.vs[579]["type"]="sub"
g.vs[580]["type"]="sub"
g.vs[581]["type"]="sub"
g.vs[582]["type"]="sub"
g.vs[583]["type"]="sub"
g.vs[584]["type"]="sub"
g.vs[585]["type"]="sub"
g.vs[586]["type"]="sub"
g.vs[587]["type"]="sub"
g.vs[588]["type"]="sub"
g.vs[589]["type"]="sub"
g.vs[590]["type"]="sub"
g.vs[591]["type"]="sub"
g.vs[592]["type"]="sub"
g.vs[593]["type"]="sub"
g.vs[594]["type"]="sub"
g.vs[595]["type"]="sub"
g.vs[596]["type"]="sub"
g.vs[597]["type"]="script"
g.vs[598]["type"]="script"
g.vs[599]["type"]="sub"
g.vs[600]["type"]="sub"
g.vs[601]["type"]="sub"
g.vs[602]["type"]="sub"
g.vs[603]["type"]="script"
g.vs[604]["type"]="sub"
g.vs[605]["type"]="script"
g.vs[606]["type"]="sub"
g.vs[607]["type"]="sub"
g.vs[608]["type"]="sub"
g.vs[609]["type"]="script"
g.vs[610]["type"]="script"
g.vs[611]["type"]="sub"
g.vs[612]["type"]="sub"
g.vs[613]["type"]="sub"
g.vs[614]["type"]="script"
g.vs[615]["type"]="script"
g.vs[616]["type"]="sub"
g.vs[617]["type"]="script"
g.vs[618]["type"]="sub"
g.vs[619]["type"]="sub"
g.vs[620]["type"]="script"
g.vs[621]["type"]="sub"
g.vs[622]["type"]="sub"
g.vs[623]["type"]="sub"
g.vs[624]["type"]="sub"
g.vs[625]["type"]="sub"
g.vs[626]["type"]="sub"
g.vs[627]["type"]="script"
g.vs[628]["type"]="sub"
g.vs[629]["type"]="sub"
g.vs[630]["type"]="sub"
g.vs[631]["type"]="script"
g.vs[632]["type"]="sub"
g.vs[633]["type"]="sub"
g.vs[634]["type"]="script"
g.vs[635]["type"]="sub"
g.vs[636]["type"]="sub"
g.vs[637]["type"]="script"
g.vs[638]["type"]="script"
g.vs[639]["type"]="sub"
g.vs[640]["type"]="sub"
g.vs[641]["type"]="sub"
g.vs[642]["type"]="script"
g.vs[643]["type"]="script"
g.vs[644]["type"]="sub"
g.vs[645]["type"]="sub"
g.vs[646]["type"]="sub"
g.vs[647]["type"]="sub"
g.vs[648]["type"]="sub"
g.vs[649]["type"]="sub"
g.vs[650]["type"]="sub"
g.vs[651]["type"]="script"
g.vs[652]["type"]="sub"
g.vs[653]["type"]="sub"
g.vs[654]["type"]="sub"
g.vs[655]["type"]="sub"
g.vs[656]["type"]="sub"
g.vs[657]["type"]="sub"
g.vs[658]["type"]="sub"
g.vs[659]["type"]="script"
g.vs[660]["type"]="sub"
g.vs[661]["type"]="sub"
g.vs[662]["type"]="script"
g.vs[663]["type"]="script"
g.vs[664]["type"]="sub"
g.vs[665]["type"]="sub"
g.vs[666]["type"]="sub"
g.vs[667]["type"]="sub"
g.vs[668]["type"]="sub"
g.vs[669]["type"]="script"
g.vs[670]["type"]="sub"
g.vs[671]["type"]="sub"
g.vs[672]["type"]="sub"
g.vs[673]["type"]="sub"
g.vs[674]["type"]="sub"
g.vs[675]["type"]="sub"
g.vs[676]["type"]="sub"
g.vs[677]["type"]="sub"
g.vs[678]["type"]="sub"
g.vs[679]["type"]="script"
g.vs[680]["type"]="sub"
g.vs[681]["type"]="script"
g.vs[682]["type"]="sub"
g.vs[683]["type"]="sub"
g.vs[684]["type"]="sub"
g.vs[685]["type"]="sub"
g.vs[686]["type"]="sub"
g.vs[687]["type"]="sub"
g.vs[688]["type"]="sub"
g.vs[689]["type"]="script"
g.vs[690]["type"]="sub"
g.vs[691]["type"]="script"
g.vs[692]["type"]="script"
g.vs[693]["type"]="sub"
g.vs[694]["type"]="script"
g.vs[695]["type"]="sub"
g.vs[696]["type"]="sub"
g.vs[697]["type"]="script"
g.vs[698]["type"]="sub"
g.vs[699]["type"]="sub"
g.vs[700]["type"]="sub"
g.vs[701]["type"]="sub"
g.vs[702]["type"]="script"
g.vs[703]["type"]="script"
g.vs[704]["type"]="script"
g.vs[705]["type"]="sub"
g.vs[706]["type"]="script"
g.vs[707]["type"]="script"
g.vs[708]["type"]="sub"
g.vs[709]["type"]="sub"
g.vs[710]["type"]="sub"
g.vs[711]["type"]="sub"
g.vs[712]["type"]="sub"
g.vs[713]["type"]="sub"
g.vs[714]["type"]="sub"
g.vs[715]["type"]="sub"
g.vs[716]["type"]="sub"
g.vs[717]["type"]="sub"
g.vs[718]["type"]="sub"
g.vs[719]["type"]="script"
g.vs[720]["type"]="sub"
g.vs[721]["type"]="sub"
g.vs[722]["type"]="sub"
g.vs[723]["type"]="sub"
g.vs[724]["type"]="sub"
g.vs[725]["type"]="sub"
g.vs[726]["type"]="sub"
g.vs[727]["type"]="mod"
g.vs[728]["type"]="sub"
g.vs[729]["type"]="sub"
g.vs[730]["type"]="sub"
g.vs[731]["type"]="sub"
g.vs[732]["type"]="sub"
g.vs[733]["type"]="sub"
g.vs[734]["type"]="script"
g.vs[735]["type"]="sub"
g.vs[736]["type"]="sub"
g.vs[737]["type"]="sub"
g.vs[738]["type"]="sub"
g.vs[739]["type"]="sub"
g.vs[740]["type"]="script"
g.vs[741]["type"]="sub"
g.vs[742]["type"]="sub"
g.vs[743]["type"]="sub"
g.vs[744]["type"]="script"
g.vs[745]["type"]="script"
g.vs[746]["type"]="sub"
g.vs[747]["type"]="script"
g.vs[748]["type"]="script"
g.vs[749]["type"]="script"
g.vs[750]["type"]="script"
g.vs[751]["type"]="script"
g.vs[752]["type"]="script"
g.vs[753]["type"]="script"
g.vs[754]["type"]="script"
g.vs[755]["type"]="script"
g.vs[756]["type"]="sub"
g.vs[757]["type"]="sub"
g.vs[758]["type"]="sub"
g.vs[759]["type"]="sub"
g.vs[760]["type"]="sub"
g.vs[761]["type"]="script"
g.vs[762]["type"]="script"
g.vs[763]["type"]="sub"
g.vs[764]["type"]="sub"
g.vs[765]["type"]="script"
g.vs[766]["type"]="script"
g.vs[767]["type"]="script"
g.vs[768]["type"]="script"
g.vs[769]["type"]="script"
g.vs[770]["type"]="script"
g.vs[771]["type"]="script"
g.vs[772]["type"]="script"
g.vs[773]["type"]="script"
g.vs[774]["type"]="script"
g.vs[775]["type"]="sub"
g.vs[776]["type"]="script"
g.vs[777]["type"]="script"
g.vs[778]["type"]="script"
g.vs[779]["type"]="script"
g.vs[780]["type"]="script"
g.vs[781]["type"]="script"
g.vs[782]["type"]="script"
g.vs[783]["type"]="script"
g.vs[784]["type"]="script"
g.vs[785]["type"]="script"
g.vs[786]["type"]="script"
g.vs[787]["type"]="script"
g.vs[788]["type"]="script"
g.vs[789]["type"]="script"
g.vs[790]["type"]="sub"
g.vs[791]["type"]="script"
g.vs[792]["type"]="sub"
g.vs[793]["type"]="script"
g.vs[794]["type"]="script"
g.vs[795]["type"]="script"
g.vs[796]["type"]="sub"
g.vs[797]["type"]="script"
g.vs[798]["type"]="script"
g.vs[799]["type"]="sub"
g.vs[800]["type"]="script"
g.vs[801]["type"]="sub"
g.vs[802]["type"]="sub"
g.vs[803]["type"]="script"
g.vs[804]["type"]="sub"
g.vs[805]["type"]="sub"
g.vs[806]["type"]="script"
g.vs[807]["type"]="script"
g.vs[808]["type"]="script"
g.vs[809]["type"]="script"
g.vs[810]["type"]="script"
g.vs[811]["type"]="sub"
g.vs[812]["type"]="script"
g.vs[813]["type"]="sub"
g.vs[814]["type"]="sub"
g.vs[815]["type"]="sub"
g.vs[816]["type"]="sub"
g.vs[817]["type"]="sub"
g.vs[818]["type"]="script"
g.vs[819]["type"]="sub"
g.vs[820]["type"]="sub"
g.vs[821]["type"]="script"
g.vs[822]["type"]="sub"
g.vs[823]["type"]="script"
g.vs[824]["type"]="script"
g.vs[825]["type"]="sub"
g.vs[826]["type"]="sub"
g.vs[827]["type"]="script"
g.vs[828]["type"]="script"
g.vs[829]["type"]="sub"
g.vs[830]["type"]="script"
g.vs[831]["type"]="script"
g.vs[832]["type"]="script"
g.vs[833]["type"]="sub"
g.vs[834]["type"]="sub"
g.vs[835]["type"]="sub"
g.vs[836]["type"]="sub"
g.vs[837]["type"]="script"
g.vs[838]["type"]="script"
g.vs[839]["type"]="script"
g.vs[840]["type"]="sub"
g.vs[841]["type"]="sub"
g.vs[842]["type"]="sub"
g.vs[843]["type"]="sub"
g.vs[844]["type"]="sub"
g.vs[845]["type"]="sub"
g.vs[846]["type"]="sub"
g.vs[847]["type"]="sub"
g.vs[848]["type"]="sub"
g.vs[849]["type"]="sub"
g.vs[850]["type"]="sub"
g.vs[851]["type"]="sub"
g.vs[852]["type"]="sub"
g.vs[853]["type"]="sub"
g.vs[854]["type"]="sub"
g.vs[855]["type"]="sub"
g.vs[856]["type"]="sub"
g.vs[857]["type"]="sub"
g.vs[858]["type"]="script"
g.vs[859]["type"]="sub"
g.vs[860]["type"]="sub"
g.vs[861]["type"]="sub"
g.vs[862]["type"]="sub"
g.vs[863]["type"]="sub"
g.vs[864]["type"]="sub"
g.vs[865]["type"]="sub"
g.vs[866]["type"]="sub"
g.vs[867]["type"]="sub"
g.vs[868]["type"]="sub"
g.vs[869]["type"]="script"
g.vs[870]["type"]="sub"
g.vs[871]["type"]="sub"
g.vs[872]["type"]="sub"
g.vs[873]["type"]="script"
g.vs[874]["type"]="sub"
g.vs[875]["type"]="sub"
g.vs[876]["type"]="sub"
g.vs[877]["type"]="sub"
g.vs[878]["type"]="script"
g.vs[879]["type"]="sub"
g.vs[880]["type"]="script"
g.vs[881]["type"]="sub"
g.vs[882]["type"]="script"
g.vs[883]["type"]="sub"
g.vs[884]["type"]="script"
g.vs[885]["type"]="sub"
g.vs[886]["type"]="sub"
g.vs[887]["type"]="script"
g.vs[888]["type"]="sub"
g.vs[889]["type"]="sub"
g.vs[890]["type"]="script"
g.vs[891]["type"]="sub"
g.vs[892]["type"]="script"
g.vs[893]["type"]="sub"
g.vs[894]["type"]="script"
g.vs[895]["type"]="sub"
g.vs[896]["type"]="script"
g.vs[897]["type"]="script"
g.vs[898]["type"]="script"
g.vs[899]["type"]="script"
g.vs[900]["type"]="script"
g.vs[901]["type"]="script"
g.vs[902]["type"]="sub"
g.vs[903]["type"]="sub"
g.vs[904]["type"]="script"
g.vs[905]["type"]="sub"
g.vs[906]["type"]="sub"
g.vs[907]["type"]="script"
g.vs[908]["type"]="script"
g.vs[909]["type"]="script"
g.vs[910]["type"]="sub"
g.vs[911]["type"]="sub"
g.vs[912]["type"]="script"
g.vs[913]["type"]="sub"
g.vs[914]["type"]="script"
g.vs[915]["type"]="script"
g.vs[916]["type"]="script"
g.vs[917]["type"]="script"
g.vs[918]["type"]="sub"
g.vs[919]["type"]="sub"
g.vs[920]["type"]="sub"
g.vs[921]["type"]="sub"
g.vs[922]["type"]="sub"
g.vs[923]["type"]="sub"
g.vs[924]["type"]="script"
g.vs[925]["type"]="script"
g.vs[926]["type"]="script"
g.vs[927]["type"]="script"
g.vs[928]["type"]="script"
g.vs[929]["type"]="script"
g.vs[930]["type"]="script"
g.vs[931]["type"]="sub"
g.vs[932]["type"]="script"
g.vs[933]["type"]="script"
g.vs[934]["type"]="sub"
g.vs[935]["type"]="script"
g.vs[936]["type"]="sub"
g.vs[937]["type"]="sub"
g.vs[938]["type"]="script"
g.vs[939]["type"]="sub"
g.vs[940]["type"]="sub"
g.vs[941]["type"]="sub"
g.vs[942]["type"]="script"
g.vs[943]["type"]="script"
g.vs[944]["type"]="script"
g.vs[945]["type"]="sub"
g.vs[946]["type"]="sub"
g.vs[947]["type"]="script"
g.vs[948]["type"]="sub"
g.vs[949]["type"]="sub"
g.vs[950]["type"]="script"
g.vs[951]["type"]="script"
g.vs[952]["type"]="script"
g.vs[953]["type"]="script"
g.vs[954]["type"]="script"
g.vs[955]["type"]="script"
g.vs[956]["type"]="sub"
g.vs[957]["type"]="sub"
g.vs[958]["type"]="script"
g.vs[959]["type"]="sub"
g.vs[960]["type"]="sub"
g.vs[961]["type"]="script"
g.vs[962]["type"]="sub"
g.vs[963]["type"]="sub"
g.vs[964]["type"]="sub"
g.vs[965]["type"]="sub"
g.vs[966]["type"]="sub"
g.vs[967]["type"]="sub"
g.vs[968]["type"]="sub"
g.vs[969]["type"]="sub"
g.vs[970]["type"]="script"
g.vs[971]["type"]="sub"
g.vs[972]["type"]="script"
g.vs[973]["type"]="script"
g.vs[974]["type"]="sub"
g.vs[975]["type"]="sub"
g.vs[976]["type"]="script"
g.vs[977]["type"]="sub"
g.vs[978]["type"]="sub"
g.vs[979]["type"]="sub"
g.vs[980]["type"]="sub"
g.vs[981]["type"]="sub"
g.vs[982]["type"]="script"
g.vs[983]["type"]="sub"
g.vs[984]["type"]="sub"
g.vs[985]["type"]="sub"
g.vs[986]["type"]="sub"
g.vs[987]["type"]="sub"
g.vs[988]["type"]="script"
g.vs[989]["type"]="sub"
g.vs[990]["type"]="sub"
g.vs[991]["type"]="script"
g.vs[992]["type"]="sub"
g.vs[993]["type"]="sub"
g.vs[994]["type"]="sub"
g.vs[995]["type"]="sub"
g.vs[996]["type"]="sub"
g.vs[997]["type"]="sub"
g.vs[998]["type"]="sub"
g.vs[999]["type"]="sub"
g.vs[1000]["type"]="sub"
g.vs[1001]["type"]="sub"
g.vs[1002]["type"]="sub"
g.vs[1003]["type"]="script"
g.vs[1004]["type"]="script"
g.vs[1005]["type"]="script"
g.vs[1006]["type"]="script"
g.vs[1007]["type"]="sub"
g.vs[1008]["type"]="sub"
g.vs[1009]["type"]="sub"
g.vs[1010]["type"]="sub"
g.vs[1011]["type"]="sub"
g.vs[1012]["type"]="sub"
g.vs[1013]["type"]="sub"
g.vs[1014]["type"]="sub"
g.vs[1015]["type"]="sub"
g.vs[1016]["type"]="sub"
g.vs[1017]["type"]="sub"
g.vs[1018]["type"]="sub"
g.vs[1019]["type"]="sub"
g.vs[1020]["type"]="sub"
g.vs[1021]["type"]="sub"
g.vs[1022]["type"]="sub"
g.vs[1023]["type"]="sub"
g.vs[1024]["type"]="sub"
g.vs[1025]["type"]="script"
g.vs[1026]["type"]="script"
g.vs[1027]["type"]="sub"
g.vs[1028]["type"]="sub"
g.vs[1029]["type"]="sub"
g.vs[1030]["type"]="sub"
g.vs[1031]["type"]="sub"
g.vs[1032]["type"]="sub"
g.vs[1033]["type"]="sub"
g.vs[1034]["type"]="sub"
g.vs[1035]["type"]="sub"
g.vs[1036]["type"]="script"
g.vs[1037]["type"]="sub"
g.vs[1038]["type"]="sub"
g.vs[1039]["type"]="sub"
g.vs[1040]["type"]="sub"
g.vs[1041]["type"]="sub"
g.vs[1042]["type"]="sub"
g.vs[1043]["type"]="sub"
g.vs[1044]["type"]="sub"
g.vs[1045]["type"]="sub"
g.vs[1046]["type"]="sub"
g.vs[1047]["type"]="sub"
g.vs[1048]["type"]="sub"
g.vs[1049]["type"]="sub"
g.vs[1050]["type"]="sub"
g.vs[1051]["type"]="sub"
g.vs[1052]["type"]="sub"
g.vs[1053]["type"]="sub"
g.vs[1054]["type"]="sub"
g.vs[1055]["type"]="sub"
g.vs[1056]["type"]="sub"
g.vs[1057]["type"]="sub"
g.vs[1058]["type"]="sub"
g.vs[1059]["type"]="sub"
g.vs[1060]["type"]="sub"
g.vs[1061]["type"]="sub"
g.vs[1062]["type"]="sub"
g.vs[1063]["type"]="sub"
g.vs[1064]["type"]="script"
g.vs[1065]["type"]="sub"
g.vs[1066]["type"]="sub"
g.vs[1067]["type"]="script"
g.vs[1068]["type"]="sub"
g.vs[1069]["type"]="sub"
g.vs[1070]["type"]="sub"
g.vs[1071]["type"]="sub"
g.vs[1072]["type"]="sub"
g.vs[1073]["type"]="sub"
g.vs[1074]["type"]="sub"
g.vs[1075]["type"]="sub"
g.vs[1076]["type"]="sub"
g.vs[1077]["type"]="sub"
g.vs[1078]["type"]="sub"
g.vs[1079]["type"]="sub"
g.vs[1080]["type"]="sub"
g.vs[1081]["type"]="sub"
g.vs[1082]["type"]="sub"
g.vs[1083]["type"]="sub"
g.vs[1084]["type"]="sub"
g.vs[1085]["type"]="sub"
g.vs[1086]["type"]="sub"
g.vs[1087]["type"]="script"
g.vs[1088]["type"]="script"
g.vs[1089]["type"]="sub"
g.vs[1090]["type"]="sub"
g.vs[1091]["type"]="sub"
g.vs[1092]["type"]="sub"
g.vs[1093]["type"]="sub"
g.vs[1094]["type"]="sub"
g.vs[1095]["type"]="sub"
g.vs[1096]["type"]="sub"
g.vs[1097]["type"]="sub"
g.vs[1098]["type"]="script"
g.vs[1099]["type"]="script"
g.vs[1100]["type"]="sub"
g.vs[1101]["type"]="sub"
g.vs[1102]["type"]="sub"
g.vs[1103]["type"]="sub"
g.vs[1104]["type"]="sub"
g.vs[1105]["type"]="sub"
g.vs[1106]["type"]="sub"
g.vs[1107]["type"]="sub"
g.vs[1108]["type"]="sub"
g.vs[1109]["type"]="sub"
g.vs[1110]["type"]="sub"
g.vs[1111]["type"]="sub"
g.vs[1112]["type"]="sub"
g.vs[1113]["type"]="sub"
g.vs[1114]["type"]="sub"
g.vs[1115]["type"]="sub"
g.vs[1116]["type"]="sub"
g.vs[1117]["type"]="sub"
g.vs[1118]["type"]="sub"
g.vs[1119]["type"]="sub"
g.vs[1120]["type"]="sub"
g.vs[1121]["type"]="sub"
g.vs[1122]["type"]="sub"
g.vs[1123]["type"]="sub"
g.vs[1124]["type"]="sub"
g.vs[1125]["type"]="sub"
g.vs[1126]["type"]="sub"
g.vs[1127]["type"]="sub"
g.vs[1128]["type"]="sub"
g.vs[1129]["type"]="sub"
g.vs[1130]["type"]="sub"
g.vs[1131]["type"]="sub"
g.vs[1132]["type"]="sub"
g.vs[1133]["type"]="sub"
g.vs[1134]["type"]="sub"
g.vs[1135]["type"]="sub"
g.vs[1136]["type"]="sub"
g.vs[1137]["type"]="sub"
g.vs[1138]["type"]="sub"
g.vs[1139]["type"]="sub"
g.vs[1140]["type"]="sub"
g.vs[1141]["type"]="sub"
g.vs[1142]["type"]="sub"
g.vs[1143]["type"]="script"
g.vs[1144]["type"]="sub"
g.vs[1145]["type"]="sub"
g.vs[1146]["type"]="sub"
g.vs[1147]["type"]="sub"
g.vs[1148]["type"]="sub"
g.vs[1149]["type"]="sub"
g.vs[1150]["type"]="sub"
g.vs[1151]["type"]="sub"
g.vs[1152]["type"]="sub"
g.vs[1153]["type"]="sub"
g.vs[1154]["type"]="sub"
g.vs[1155]["type"]="sub"
g.vs[1156]["type"]="sub"
g.vs[1157]["type"]="sub"
g.vs[1158]["type"]="sub"
g.vs[1159]["type"]="script"
g.vs[1160]["type"]="sub"
g.vs[1161]["type"]="sub"
g.vs[1162]["type"]="sub"
g.vs[1163]["type"]="script"
g.vs[1164]["type"]="sub"
g.vs[1165]["type"]="sub"
g.vs[1166]["type"]="script"
g.vs[1167]["type"]="sub"
g.vs[1168]["type"]="sub"
g.vs[1169]["type"]="sub"
g.vs[1170]["type"]="sub"
g.vs[1171]["type"]="sub"
g.vs[1172]["type"]="sub"
g.vs[1173]["type"]="sub"
g.vs[1174]["type"]="sub"
g.vs[1175]["type"]="sub"
g.vs[1176]["type"]="sub"
g.vs[1177]["type"]="sub"
g.vs[1178]["type"]="script"
g.vs[1179]["type"]="sub"
g.vs[1180]["type"]="sub"
g.vs[1181]["type"]="sub"
g.vs[1182]["type"]="script"
g.vs[1183]["type"]="sub"
g.vs[1184]["type"]="sub"
g.vs[1185]["type"]="sub"
g.vs[1186]["type"]="sub"
g.vs[1187]["type"]="sub"
g.vs[1188]["type"]="sub"
g.vs[1189]["type"]="sub"
g.vs[1190]["type"]="sub"
g.vs[1191]["type"]="sub"
g.vs[1192]["type"]="sub"
g.vs[1193]["type"]="sub"
g.vs[1194]["type"]="sub"
g.vs[1195]["type"]="sub"
g.vs[1196]["type"]="sub"
g.vs[1197]["type"]="sub"
g.vs[1198]["type"]="script"
g.vs[1199]["type"]="sub"
g.vs[1200]["type"]="sub"
g.vs[1201]["type"]="sub"
g.vs[1202]["type"]="script"
g.vs[1203]["type"]="sub"
g.vs[1204]["type"]="sub"
g.vs[1205]["type"]="sub"
g.vs[1206]["type"]="sub"
g.vs[1207]["type"]="sub"
g.vs[1208]["type"]="script"
g.vs[1209]["type"]="sub"
g.vs[1210]["type"]="sub"
g.vs[1211]["type"]="sub"
g.vs[1212]["type"]="sub"
g.vs[1213]["type"]="sub"
g.vs[1214]["type"]="sub"
g.vs[1215]["type"]="sub"
g.vs[1216]["type"]="sub"
g.vs[1217]["type"]="sub"
g.vs[1218]["type"]="sub"
g.vs[1219]["type"]="sub"
g.vs[1220]["type"]="sub"
g.vs[1221]["type"]="sub"
g.vs[1222]["type"]="sub"
g.vs[1223]["type"]="sub"
g.vs[1224]["type"]="script"
g.vs[1225]["type"]="sub"
g.vs[1226]["type"]="script"
g.vs[1227]["type"]="sub"
g.vs[1228]["type"]="sub"
g.vs[1229]["type"]="sub"
g.vs[1230]["type"]="sub"
g.vs[1231]["type"]="sub"
g.vs[1232]["type"]="script"
g.vs[1233]["type"]="sub"
g.vs[1234]["type"]="sub"
g.vs[1235]["type"]="sub"
g.vs[1236]["type"]="sub"
g.vs[1237]["type"]="sub"
g.vs[1238]["type"]="sub"
g.vs[1239]["type"]="sub"
g.vs[1240]["type"]="sub"
g.vs[1241]["type"]="sub"
g.vs[1242]["type"]="sub"
g.vs[1243]["type"]="sub"
g.vs[1244]["type"]="sub"
g.vs[1245]["type"]="sub"
g.vs[1246]["type"]="sub"
g.vs[1247]["type"]="sub"
g.vs[1248]["type"]="sub"
g.vs[1249]["type"]="sub"
g.vs[1250]["type"]="sub"
g.vs[1251]["type"]="sub"
g.vs[1252]["type"]="sub"
g.vs[1253]["type"]="sub"
g.vs[1254]["type"]="sub"
g.vs[1255]["type"]="script"
g.vs[1256]["type"]="sub"
g.vs[1257]["type"]="sub"
g.vs[1258]["type"]="sub"
g.vs[1259]["type"]="sub"
g.vs[1260]["type"]="sub"
g.vs[1261]["type"]="sub"
g.vs[1262]["type"]="sub"
g.vs[1263]["type"]="sub"
g.vs[1264]["type"]="sub"
g.vs[1265]["type"]="sub"
g.vs[1266]["type"]="sub"
g.vs[1267]["type"]="sub"
g.vs[1268]["type"]="sub"
g.vs[1269]["type"]="sub"
g.vs[1270]["type"]="sub"
g.vs[1271]["type"]="sub"
g.vs[1272]["type"]="sub"
g.vs[1273]["type"]="sub"
g.vs[1274]["type"]="script"
g.vs[1275]["type"]="sub"
g.vs[1276]["type"]="sub"
g.vs[1277]["type"]="sub"
g.vs[1278]["type"]="sub"
g.vs[1279]["type"]="sub"
g.vs[1280]["type"]="sub"
g.vs[1281]["type"]="sub"
g.vs[1282]["type"]="sub"
g.vs[1283]["type"]="sub"
g.vs[1284]["type"]="sub"
g.vs[1285]["type"]="sub"
g.vs[1286]["type"]="sub"
g.vs[1287]["type"]="sub"
g.vs[1288]["type"]="script"
g.vs[1289]["type"]="script"
g.vs[1290]["type"]="script"
g.vs[1291]["type"]="script"
g.vs[1292]["type"]="sub"
g.vs[1293]["type"]="sub"
g.vs[1294]["type"]="sub"
g.vs[1295]["type"]="sub"
g.vs[1296]["type"]="sub"
g.vs[1297]["type"]="sub"
g.vs[1298]["type"]="sub"
g.vs[1299]["type"]="sub"
g.vs[1300]["type"]="sub"
g.vs[1301]["type"]="sub"
g.vs[1302]["type"]="sub"
g.vs[1303]["type"]="sub"
g.vs[1304]["type"]="script"
g.vs[1305]["type"]="sub"
g.vs[1306]["type"]="sub"
g.vs[1307]["type"]="sub"
g.vs[1308]["type"]="script"
g.vs[1309]["type"]="sub"
g.vs[1310]["type"]="sub"
g.vs[1311]["type"]="sub"
g.vs[1312]["type"]="script"
g.vs[1313]["type"]="script"
g.vs[1314]["type"]="script"
g.vs[1315]["type"]="script"
g.vs[1316]["type"]="script"
g.vs[1317]["type"]="script"
g.vs[1318]["type"]="script"
g.vs[1319]["type"]="script"
g.vs[1320]["type"]="script"
g.vs[1321]["type"]="script"
g.vs[1322]["type"]="script"
g.vs[1323]["type"]="script"
g.vs[1324]["type"]="script"
g.vs[1325]["type"]="script"
g.vs[1326]["type"]="script"
g.vs[1327]["type"]="sub"
g.vs[1328]["type"]="script"
g.vs[1329]["type"]="sub"
g.vs[1330]["type"]="sub"
g.vs[1331]["type"]="sub"
g.vs[1332]["type"]="script"
g.vs[1333]["type"]="script"
g.vs[1334]["type"]="script"
g.vs[1335]["type"]="script"
g.vs[1336]["type"]="sub"
g.vs[1337]["type"]="script"
g.vs[1338]["type"]="sub"
g.vs[1339]["type"]="sub"
g.vs[1340]["type"]="script"
g.vs[1341]["type"]="sub"
g.vs[1342]["type"]="script"
g.vs[1343]["type"]="sub"
g.vs[1344]["type"]="sub"
g.vs[1345]["type"]="script"
g.vs[1346]["type"]="script"
g.vs[1347]["type"]="script"
g.vs[1348]["type"]="sub"
g.vs[1349]["type"]="sub"
g.vs[1350]["type"]="sub"
g.vs[1351]["type"]="sub"
g.vs[1352]["type"]="sub"
g.vs[1353]["type"]="script"
g.vs[1354]["type"]="script"
g.vs[1355]["type"]="sub"
g.vs[1356]["type"]="sub"
g.vs[1357]["type"]="sub"
g.vs[1358]["type"]="sub"
g.vs[1359]["type"]="script"
g.vs[1360]["type"]="sub"
g.vs[1361]["type"]="sub"
g.vs[1362]["type"]="script"
g.vs[1363]["type"]="script"
g.vs[1364]["type"]="script"
g.vs[1365]["type"]="script"
g.vs[1366]["type"]="script"
g.vs[1367]["type"]="sub"
g.vs[1368]["type"]="sub"
g.vs[1369]["type"]="sub"
g.vs[1370]["type"]="script"
g.vs[1371]["type"]="script"
g.vs[1372]["type"]="sub"
g.vs[1373]["type"]="script"
g.vs[1374]["type"]="sub"
g.vs[1375]["type"]="sub"
g.vs[1376]["type"]="sub"
g.vs[1377]["type"]="sub"
g.vs[1378]["type"]="sub"
g.vs[1379]["type"]="script"
g.vs[1380]["type"]="sub"
g.vs[1381]["type"]="sub"
g.vs[1382]["type"]="sub"
g.vs[1383]["type"]="script"
g.vs[1384]["type"]="sub"
g.vs[1385]["type"]="sub"
g.vs[1386]["type"]="script"
g.vs[1387]["type"]="sub"
g.vs[1388]["type"]="sub"
g.vs[1389]["type"]="sub"
g.vs[1390]["type"]="sub"
g.vs[1391]["type"]="sub"
g.vs[1392]["type"]="sub"
g.vs[1393]["type"]="sub"
g.vs[1394]["type"]="script"
g.vs[1395]["type"]="sub"
g.vs[1396]["type"]="script"
g.vs[1397]["type"]="sub"
g.vs[1398]["type"]="script"
g.vs[1399]["type"]="script"
g.vs[1400]["type"]="script"
g.vs[1401]["type"]="script"
g.vs[1402]["type"]="sub"
g.vs[1403]["type"]="sub"
g.vs[1404]["type"]="script"
g.vs[1405]["type"]="sub"
g.vs[1406]["type"]="sub"
g.vs[1407]["type"]="script"
g.vs[1408]["type"]="script"
g.vs[1409]["type"]="sub"
g.vs[1410]["type"]="sub"
g.vs[1411]["type"]="script"
g.vs[1412]["type"]="sub"
g.vs[1413]["type"]="sub"
g.vs[1414]["type"]="script"
g.vs[1415]["type"]="sub"
g.vs[1416]["type"]="sub"
g.vs[1417]["type"]="sub"
g.vs[1418]["type"]="script"
g.vs[1419]["type"]="sub"
g.vs[1420]["type"]="sub"
g.vs[1421]["type"]="sub"
g.vs[1422]["type"]="script"
g.vs[1423]["type"]="script"
g.vs[1424]["type"]="script"
g.vs[1425]["type"]="script"
g.vs[1426]["type"]="script"
g.vs[1427]["type"]="sub"
g.vs[1428]["type"]="sub"
g.vs[1429]["type"]="sub"
g.vs[1430]["type"]="script"
g.vs[1431]["type"]="sub"
g.vs[1432]["type"]="sub"
g.vs[1433]["type"]="sub"
g.vs[1434]["type"]="sub"
g.vs[1435]["type"]="sub"
g.vs[1436]["type"]="sub"
g.vs[1437]["type"]="sub"
g.vs[1438]["type"]="sub"
g.vs[1439]["type"]="sub"
g.vs[1440]["type"]="script"
g.vs[1441]["type"]="sub"
g.vs[1442]["type"]="sub"
g.vs[1443]["type"]="sub"
g.vs[1444]["type"]="sub"
g.vs[1445]["type"]="sub"
g.vs[1446]["type"]="script"
g.vs[1447]["type"]="sub"
g.vs[1448]["type"]="script"
g.vs[1449]["type"]="script"
g.vs[1450]["type"]="script"
g.vs[1451]["type"]="script"
g.vs[1452]["type"]="script"
g.vs[1453]["type"]="sub"
g.vs[1454]["type"]="script"
g.vs[1455]["type"]="sub"
g.vs[1456]["type"]="script"
g.vs[1457]["type"]="script"
g.vs[1458]["type"]="script"
g.vs[1459]["type"]="script"
g.vs[1460]["type"]="script"
g.vs[1461]["type"]="script"
g.vs[1462]["type"]="script"
g.vs[1463]["type"]="script"
g.vs[1464]["type"]="script"
g.vs[1465]["type"]="script"
g.vs[1466]["type"]="script"
g.vs[1467]["type"]="script"
g.vs[1468]["type"]="script"
g.vs[1469]["type"]="script"
g.vs[1470]["type"]="sub"
g.vs[1471]["type"]="script"
g.vs[1472]["type"]="script"
g.vs[1473]["type"]="script"
g.vs[1474]["type"]="sub"
g.vs[1475]["type"]="script"
g.vs[1476]["type"]="sub"
g.vs[1477]["type"]="sub"
g.vs[1478]["type"]="sub"
g.vs[1479]["type"]="script"
g.vs[1480]["type"]="sub"
g.vs[1481]["type"]="script"
g.vs[1482]["type"]="sub"
g.vs[1483]["type"]="sub"
g.vs[1484]["type"]="script"
g.vs[1485]["type"]="sub"
g.vs[1486]["type"]="sub"
g.vs[1487]["type"]="sub"
g.vs[1488]["type"]="sub"
g.vs[1489]["type"]="sub"
g.vs[1490]["type"]="sub"
g.vs[1491]["type"]="sub"
g.vs[1492]["type"]="script"
g.vs[1493]["type"]="script"
g.vs[1494]["type"]="script"
g.vs[1495]["type"]="script"
g.vs[1496]["type"]="script"
g.vs[1497]["type"]="script"
g.vs[1498]["type"]="sub"
g.vs[1499]["type"]="script"
g.vs[1500]["type"]="sub"
g.vs[1501]["type"]="sub"
g.vs[1502]["type"]="sub"
g.vs[1503]["type"]="sub"
g.vs[1504]["type"]="sub"
g.vs[1505]["type"]="sub"
g.vs[1506]["type"]="script"
g.vs[1507]["type"]="script"
g.vs[1508]["type"]="script"
g.vs[1509]["type"]="script"
g.vs[1510]["type"]="script"
g.vs[1511]["type"]="sub"
g.vs[1512]["type"]="sub"
g.vs[1513]["type"]="sub"
g.vs[1514]["type"]="sub"
g.vs[1515]["type"]="sub"
g.vs[1516]["type"]="sub"
g.vs[1517]["type"]="script"
g.vs[1518]["type"]="script"
g.vs[1519]["type"]="script"
g.vs[1520]["type"]="script"
g.vs[1521]["type"]="script"
g.vs[1522]["type"]="script"
g.vs[1523]["type"]="script"
g.vs[1524]["type"]="script"
g.vs[1525]["type"]="sub"
g.vs[1526]["type"]="sub"
g.vs[1527]["type"]="mod"
g.vs[1528]["type"]="script"
g.vs[1529]["type"]="script"
g.vs[1530]["type"]="script"
g.vs[1531]["type"]="script"
g.vs[1532]["type"]="script"
g.vs[1533]["type"]="script"
g.vs[1534]["type"]="sub"
g.vs[1535]["type"]="script"
g.vs[1536]["type"]="sub"
g.vs[1537]["type"]="script"
g.vs[1538]["type"]="sub"
g.vs[1539]["type"]="script"
g.vs[1540]["type"]="script"
g.vs[1541]["type"]="script"
g.vs[1542]["type"]="script"
g.vs[1543]["type"]="sub"
g.vs[1544]["type"]="sub"
g.vs[1545]["type"]="sub"
g.vs[1546]["type"]="sub"
g.vs[1547]["type"]="script"
g.vs[1548]["type"]="script"
g.vs[1549]["type"]="sub"
g.vs[1550]["type"]="sub"
g.vs[1551]["type"]="script"
g.vs[1552]["type"]="sub"
g.vs[1553]["type"]="sub"
g.vs[1554]["type"]="sub"
g.vs[1555]["type"]="script"
g.vs[1556]["type"]="script"
g.vs[1557]["type"]="sub"
g.vs[1558]["type"]="sub"
g.vs[1559]["type"]="sub"
g.vs[1560]["type"]="sub"
g.vs[1561]["type"]="sub"
g.vs[1562]["type"]="sub"
g.vs[1563]["type"]="sub"
g.vs[1564]["type"]="sub"
g.vs[1565]["type"]="sub"
g.vs[1566]["type"]="sub"
g.vs[1567]["type"]="sub"
g.vs[1568]["type"]="script"
g.vs[1569]["type"]="sub"
g.vs[1570]["type"]="sub"
g.vs[1571]["type"]="sub"
g.vs[1572]["type"]="script"
g.vs[1573]["type"]="script"
g.vs[1574]["type"]="sub"
g.vs[1575]["type"]="sub"
g.vs[1576]["type"]="sub"
g.vs[1577]["type"]="sub"
g.vs[1578]["type"]="script"
g.vs[1579]["type"]="script"
g.vs[1580]["type"]="sub"
g.vs[1581]["type"]="script"
g.vs[1582]["type"]="sub"
g.vs[1583]["type"]="sub"
g.vs[1584]["type"]="script"
g.vs[1585]["type"]="sub"
g.vs[1586]["type"]="script"
g.vs[1587]["type"]="script"
g.vs[1588]["type"]="sub"
g.vs[1589]["type"]="sub"
g.vs[1590]["type"]="script"
g.vs[1591]["type"]="sub"
g.vs[1592]["type"]="sub"
g.vs[1593]["type"]="script"
g.vs[1594]["type"]="sub"
g.vs[1595]["type"]="sub"
g.vs[1596]["type"]="sub"
g.vs[1597]["type"]="sub"
g.vs[1598]["type"]="sub"
g.vs[1599]["type"]="script"
g.vs[1600]["type"]="sub"
g.vs[1601]["type"]="sub"
g.vs[1602]["type"]="sub"
g.vs[1603]["type"]="sub"
g.vs[1604]["type"]="script"
g.vs[1605]["type"]="script"
g.vs[1606]["type"]="script"
g.vs[1607]["type"]="sub"
g.vs[1608]["type"]="sub"
g.vs[1609]["type"]="sub"
g.vs[1610]["type"]="sub"
g.vs[1611]["type"]="sub"
g.vs[1612]["type"]="sub"
g.vs[1613]["type"]="script"
g.vs[1614]["type"]="sub"
g.vs[1615]["type"]="sub"
g.vs[1616]["type"]="sub"
g.vs[1617]["type"]="sub"
g.vs[1618]["type"]="sub"
g.vs[1619]["type"]="sub"
g.vs[1620]["type"]="sub"
g.vs[1621]["type"]="sub"
g.vs[1622]["type"]="sub"
g.vs[1623]["type"]="script"
g.vs[1624]["type"]="sub"
g.vs[1625]["type"]="sub"
g.vs[1626]["type"]="sub"
g.vs[1627]["type"]="script"
g.vs[1628]["type"]="sub"
g.vs[1629]["type"]="script"
g.vs[1630]["type"]="sub"
g.vs[1631]["type"]="sub"
g.vs[1632]["type"]="sub"
g.vs[1633]["type"]="sub"
g.vs[1634]["type"]="sub"
g.vs[1635]["type"]="sub"
g.vs[1636]["type"]="sub"
g.vs[1637]["type"]="sub"
g.vs[1638]["type"]="script"
g.vs[1639]["type"]="script"
g.vs[1640]["type"]="script"
g.vs[1641]["type"]="script"
g.vs[1642]["type"]="script"
g.vs[1643]["type"]="script"
g.vs[1644]["type"]="script"
g.vs[1645]["type"]="script"
g.vs[1646]["type"]="script"
g.vs[1647]["type"]="script"
g.vs[1648]["type"]="script"
g.vs[1649]["type"]="script"
g.vs[1650]["type"]="script"
g.vs[1651]["type"]="script"
g.vs[1652]["type"]="script"
g.vs[1653]["type"]="script"
g.vs[1654]["type"]="sub"
g.vs[1655]["type"]="sub"
g.vs[1656]["type"]="sub"
g.vs[1657]["type"]="sub"
g.vs[1658]["type"]="script"
g.vs[1659]["type"]="script"
g.vs[1660]["type"]="script"
g.vs[1661]["type"]="script"
g.vs[1662]["type"]="sub"
g.vs[1663]["type"]="sub"
g.vs[1664]["type"]="sub"
g.vs[1665]["type"]="sub"
g.vs[1666]["type"]="sub"
g.vs[1667]["type"]="sub"
g.vs[1668]["type"]="sub"
g.vs[1669]["type"]="sub"
g.vs[1670]["type"]="script"
g.vs[1671]["type"]="script"
g.vs[1672]["type"]="sub"
g.vs[1673]["type"]="sub"
g.vs[1674]["type"]="script"
g.vs[1675]["type"]="sub"
g.vs[1676]["type"]="sub"
g.vs[1677]["type"]="script"
g.vs[1678]["type"]="sub"
g.vs[1679]["type"]="sub"
g.vs[1680]["type"]="sub"
g.vs[1681]["type"]="script"
g.vs[1682]["type"]="sub"
g.vs[1683]["type"]="sub"
g.vs[1684]["type"]="sub"
g.vs[1685]["type"]="sub"
g.vs[1686]["type"]="script"
g.vs[1687]["type"]="script"
g.vs[1688]["type"]="sub"
g.vs[1689]["type"]="sub"
g.vs[1690]["type"]="sub"
g.vs[1691]["type"]="sub"
g.vs[1692]["type"]="script"
g.vs[1693]["type"]="sub"
g.vs[1694]["type"]="sub"
g.vs[1695]["type"]="sub"
g.vs[1696]["type"]="sub"
g.vs[1697]["type"]="sub"
g.vs[1698]["type"]="sub"
g.vs[1699]["type"]="sub"
g.vs[1700]["type"]="script"
g.vs[1701]["type"]="sub"
g.vs[1702]["type"]="sub"
g.vs[1703]["type"]="sub"
g.vs[1704]["type"]="script"
g.vs[1705]["type"]="script"
g.vs[1706]["type"]="script"
g.vs[1707]["type"]="script"
g.vs[1708]["type"]="sub"
g.vs[1709]["type"]="script"
g.vs[1710]["type"]="script"
g.vs[1711]["type"]="script"
g.vs[1712]["type"]="sub"
g.vs[1713]["type"]="sub"
g.vs[1714]["type"]="script"
g.vs[1715]["type"]="sub"
g.vs[1716]["type"]="sub"
g.vs[1717]["type"]="sub"
g.vs[1718]["type"]="script"
g.vs[1719]["type"]="sub"
g.vs[1720]["type"]="script"
g.vs[1721]["type"]="sub"
g.vs[1722]["type"]="script"
g.vs[1723]["type"]="sub"
g.vs[1724]["type"]="script"
g.vs[1725]["type"]="script"
g.vs[1726]["type"]="script"
g.vs[1727]["type"]="sub"
g.vs[1728]["type"]="sub"
g.vs[1729]["type"]="script"
g.vs[1730]["type"]="sub"
g.vs[1731]["type"]="script"
g.vs[1732]["type"]="sub"
g.vs[1733]["type"]="sub"
g.vs[1734]["type"]="sub"
g.vs[1735]["type"]="sub"
g.vs[1736]["type"]="sub"
g.vs[1737]["type"]="sub"
g.vs[1738]["type"]="sub"
g.vs[1739]["type"]="sub"
g.vs[1740]["type"]="sub"
g.vs[1741]["type"]="sub"
g.vs[1742]["type"]="sub"
g.vs[1743]["type"]="sub"
g.vs[1744]["type"]="sub"
g.vs[1745]["type"]="sub"
g.vs[1746]["type"]="sub"
g.vs[1747]["type"]="sub"
g.vs[1748]["type"]="sub"
g.vs[1749]["type"]="sub"
g.vs[1750]["type"]="sub"
g.vs[1751]["type"]="sub"
g.vs[1752]["type"]="sub"
g.vs[1753]["type"]="sub"
g.vs[1754]["type"]="sub"
g.vs[1755]["type"]="sub"
g.vs[1756]["type"]="sub"
g.vs[1757]["type"]="sub"
g.vs[1758]["type"]="script"
g.vs[1759]["type"]="sub"
g.vs[1760]["type"]="sub"
g.vs[1761]["type"]="sub"
g.vs[1762]["type"]="sub"
g.vs[1763]["type"]="sub"
g.vs[1764]["type"]="sub"
g.vs[1765]["type"]="sub"
g.vs[1766]["type"]="sub"
g.vs[1767]["type"]="sub"
g.vs[1768]["type"]="script"
g.vs[1769]["type"]="script"
g.vs[1770]["type"]="sub"
g.vs[1771]["type"]="sub"
g.vs[1772]["type"]="sub"
g.vs[1773]["type"]="sub"
g.vs[1774]["type"]="sub"
g.vs[1775]["type"]="sub"
g.vs[1776]["type"]="sub"
g.vs[1777]["type"]="sub"
g.vs[1778]["type"]="sub"
g.vs[1779]["type"]="sub"
g.vs[1780]["type"]="sub"
g.vs[1781]["type"]="sub"
g.vs[1782]["type"]="sub"
g.vs[1783]["type"]="sub"
g.vs[1784]["type"]="sub"
g.vs[1785]["type"]="sub"
g.vs[1786]["type"]="sub"
g.vs[1787]["type"]="sub"
g.vs[1788]["type"]="sub"
g.vs[1789]["type"]="script"
g.vs[1790]["type"]="sub"
g.vs[1791]["type"]="sub"
g.vs[1792]["type"]="sub"
g.vs[1793]["type"]="script"
g.vs[1794]["type"]="sub"
g.vs[1795]["type"]="sub"
g.vs[1796]["type"]="sub"
g.vs[1797]["type"]="sub"
g.vs[1798]["type"]="sub"
g.vs[1799]["type"]="sub"
g.vs[1800]["type"]="sub"
g.vs[1801]["type"]="sub"
g.vs[1802]["type"]="sub"
g.vs[1803]["type"]="script"
g.vs[1804]["type"]="script"
g.vs[1805]["type"]="script"
g.vs[1806]["type"]="sub"
g.vs[1807]["type"]="sub"
g.vs[1808]["type"]="sub"
g.vs[1809]["type"]="script"
g.vs[1810]["type"]="sub"
g.vs[1811]["type"]="sub"
g.vs[1812]["type"]="script"
g.vs[1813]["type"]="sub"
g.vs[1814]["type"]="script"
g.vs[1815]["type"]="sub"
g.vs[1816]["type"]="sub"
g.vs[1817]["type"]="script"
g.vs[1818]["type"]="sub"
g.vs[1819]["type"]="sub"
g.vs[1820]["type"]="sub"
g.vs[1821]["type"]="sub"
g.vs[1822]["type"]="sub"
g.vs[1823]["type"]="sub"
g.vs[1824]["type"]="sub"
g.vs[1825]["type"]="sub"
g.vs[1826]["type"]="sub"
g.vs[1827]["type"]="script"
g.vs[1828]["type"]="sub"
g.vs[1829]["type"]="sub"
g.vs[1830]["type"]="sub"
g.vs[1831]["type"]="sub"
g.vs[1832]["type"]="sub"
g.vs[1833]["type"]="sub"
g.vs[1834]["type"]="sub"
g.vs[1835]["type"]="sub"
g.vs[1836]["type"]="sub"
g.vs[1837]["type"]="sub"
g.vs[1838]["type"]="sub"
g.vs[1839]["type"]="sub"
g.vs[1840]["type"]="sub"
g.vs[1841]["type"]="sub"
g.vs[1842]["type"]="sub"
g.vs[1843]["type"]="sub"
g.vs[1844]["type"]="sub"
g.vs[1845]["type"]="sub"
g.vs[1846]["type"]="sub"
g.vs[1847]["type"]="sub"
g.vs[1848]["type"]="sub"
g.vs[1849]["type"]="sub"
g.vs[1850]["type"]="sub"
g.vs[1851]["type"]="sub"
g.vs[1852]["type"]="sub"
g.vs[1853]["type"]="sub"
g.vs[1854]["type"]="sub"
g.vs[1855]["type"]="sub"
g.vs[1856]["type"]="sub"
g.vs[1857]["type"]="sub"
g.vs[1858]["type"]="sub"
g.vs[1859]["type"]="sub"
g.vs[1860]["type"]="sub"
g.vs[1861]["type"]="sub"
g.vs[1862]["type"]="sub"
g.vs[1863]["type"]="sub"
g.vs[1864]["type"]="sub"
g.vs[1865]["type"]="script"
g.vs[1866]["type"]="script"
g.vs[1867]["type"]="sub"
g.vs[1868]["type"]="sub"
g.vs[1869]["type"]="sub"
g.vs[1870]["type"]="sub"
g.vs[1871]["type"]="sub"
g.vs[1872]["type"]="sub"
g.vs[1873]["type"]="script"
g.vs[1874]["type"]="script"
g.vs[1875]["type"]="script"
g.vs[1876]["type"]="script"
g.vs[1877]["type"]="script"
g.vs[1878]["type"]="script"
g.vs[1879]["type"]="sub"
g.vs[1880]["type"]="script"
g.vs[1881]["type"]="script"
g.vs[1882]["type"]="script"
g.vs[1883]["type"]="script"
g.vs[1884]["type"]="sub"
g.vs[1885]["type"]="script"
g.vs[1886]["type"]="script"
g.vs[1887]["type"]="script"
g.vs[1888]["type"]="sub"
g.vs[1889]["type"]="script"
g.vs[1890]["type"]="sub"
g.vs[1891]["type"]="sub"
g.vs[1892]["type"]="sub"
g.vs[1893]["type"]="sub"
g.vs[1894]["type"]="sub"
g.vs[1895]["type"]="sub"
g.vs[1896]["type"]="sub"
g.vs[1897]["type"]="script"
g.vs[1898]["type"]="sub"
g.vs[1899]["type"]="sub"
g.vs[1900]["type"]="sub"
g.vs[1901]["type"]="sub"
g.vs[1902]["type"]="sub"
g.vs[1903]["type"]="script"
g.vs[1904]["type"]="script"
g.vs[1905]["type"]="script"
g.vs[1906]["type"]="script"
g.vs[1907]["type"]="script"
g.vs[1908]["type"]="sub"
g.vs[1909]["type"]="sub"
g.vs[1910]["type"]="sub"
g.vs[1911]["type"]="sub"
g.vs[1912]["type"]="sub"
g.vs[1913]["type"]="script"
g.vs[1914]["type"]="sub"
g.vs[1915]["type"]="sub"
g.vs[1916]["type"]="sub"
g.vs[1917]["type"]="sub"
g.vs[1918]["type"]="sub"
g.vs[1919]["type"]="sub"
g.vs[1920]["type"]="sub"
g.vs[1921]["type"]="sub"
g.vs[1922]["type"]="sub"
g.vs[1923]["type"]="sub"
g.vs[1924]["type"]="sub"
g.vs[1925]["type"]="sub"
g.vs[1926]["type"]="sub"
g.vs[1927]["type"]="script"
g.vs[1928]["type"]="script"
g.vs[1929]["type"]="script"
g.vs[1930]["type"]="sub"
g.vs[1931]["type"]="sub"
g.vs[1932]["type"]="script"
g.vs[1933]["type"]="sub"
g.vs[1934]["type"]="sub"
g.vs[1935]["type"]="sub"
g.vs[1936]["type"]="sub"
g.vs[1937]["type"]="sub"
g.vs[1938]["type"]="script"
g.vs[1939]["type"]="script"
g.vs[1940]["type"]="script"
g.vs[1941]["type"]="sub"
g.vs[1942]["type"]="sub"
g.vs[1943]["type"]="sub"
g.vs[1944]["type"]="sub"
g.vs[1945]["type"]="sub"
g.vs[1946]["type"]="sub"
g.vs[1947]["type"]="sub"
g.vs[1948]["type"]="sub"
g.vs[1949]["type"]="sub"
g.vs[1950]["type"]="sub"
g.vs[1951]["type"]="sub"
g.vs[1952]["type"]="sub"
g.vs[1953]["type"]="sub"
g.vs[1954]["type"]="sub"
g.vs[1955]["type"]="sub"
g.vs[1956]["type"]="sub"
g.vs[1957]["type"]="sub"
g.vs[1958]["type"]="sub"
g.vs[1959]["type"]="sub"
g.vs[1960]["type"]="sub"
g.vs[1961]["type"]="script"
g.vs[1962]["type"]="sub"
g.vs[1963]["type"]="script"
g.vs[1964]["type"]="sub"
g.vs[1965]["type"]="script"
g.vs[1966]["type"]="sub"
g.vs[1967]["type"]="script"
g.vs[1968]["type"]="sub"
g.vs[1969]["type"]="script"
g.vs[1970]["type"]="sub"
g.vs[1971]["type"]="sub"
g.vs[1972]["type"]="sub"
g.vs[1973]["type"]="sub"
g.vs[1974]["type"]="sub"
g.vs[1975]["type"]="sub"
g.vs[1976]["type"]="script"
g.vs[1977]["type"]="sub"
g.vs[1978]["type"]="script"
g.vs[1979]["type"]="sub"
g.vs[1980]["type"]="script"
g.vs[1981]["type"]="script"
g.vs[1982]["type"]="sub"
g.vs[1983]["type"]="sub"
g.vs[1984]["type"]="script"
g.vs[1985]["type"]="sub"
g.vs[1986]["type"]="sub"
g.vs[1987]["type"]="sub"
g.vs[1988]["type"]="script"
g.vs[1989]["type"]="sub"
g.vs[1990]["type"]="script"
g.vs[1991]["type"]="script"
g.vs[1992]["type"]="sub"
g.vs[1993]["type"]="script"
g.vs[1994]["type"]="sub"
g.vs[1995]["type"]="sub"
g.vs[1996]["type"]="sub"
g.vs[1997]["type"]="script"
g.vs[1998]["type"]="script"
g.vs[1999]["type"]="script"
g.vs[2000]["type"]="sub"
g.vs[2001]["type"]="sub"
g.vs[2002]["type"]="script"
g.vs[2003]["type"]="script"
g.vs[2004]["type"]="script"
g.vs[2005]["type"]="sub"
g.vs[2006]["type"]="sub"
g.vs[2007]["type"]="script"
g.vs[2008]["type"]="script"
g.vs[2009]["type"]="sub"
g.vs[2010]["type"]="sub"
g.vs[2011]["type"]="sub"
g.vs[2012]["type"]="sub"
g.vs[2013]["type"]="sub"
g.vs[2014]["type"]="sub"
g.vs[2015]["type"]="script"
g.vs[2016]["type"]="sub"
g.vs[2017]["type"]="script"
g.vs[2018]["type"]="sub"
g.vs[2019]["type"]="sub"
g.vs[2020]["type"]="sub"
g.vs[2021]["type"]="sub"
g.vs[2022]["type"]="script"
g.vs[2023]["type"]="script"
g.vs[2024]["type"]="sub"
g.vs[2025]["type"]="sub"
g.vs[2026]["type"]="script"
g.vs[2027]["type"]="sub"
g.vs[2028]["type"]="sub"
g.vs[2029]["type"]="script"
g.vs[2030]["type"]="sub"
g.vs[2031]["type"]="script"
g.vs[2032]["type"]="script"
g.vs[2033]["type"]="sub"
g.vs[2034]["type"]="sub"
g.vs[2035]["type"]="sub"
g.vs[2036]["type"]="sub"
g.vs[2037]["type"]="sub"
g.vs[2038]["type"]="sub"
g.vs[2039]["type"]="sub"
g.vs[2040]["type"]="sub"
g.vs[2041]["type"]="sub"
g.vs[2042]["type"]="script"
g.vs[2043]["type"]="sub"
g.vs[2044]["type"]="sub"
g.vs[2045]["type"]="sub"
g.vs[2046]["type"]="sub"
g.vs[2047]["type"]="sub"
g.vs[2048]["type"]="sub"
g.vs[2049]["type"]="sub"
g.vs[2050]["type"]="sub"
g.vs[2051]["type"]="sub"
g.vs[2052]["type"]="sub"
g.vs[2053]["type"]="sub"
g.vs[2054]["type"]="sub"
g.vs[2055]["type"]="sub"
g.vs[2056]["type"]="sub"
g.vs[2057]["type"]="sub"
g.vs[2058]["type"]="script"
g.vs[2059]["type"]="script"
g.vs[2060]["type"]="script"
g.vs[2061]["type"]="sub"
g.vs[2062]["type"]="sub"
g.vs[2063]["type"]="sub"
g.vs[2064]["type"]="sub"
g.vs[2065]["type"]="sub"
g.vs[2066]["type"]="sub"
g.vs[2067]["type"]="sub"
g.vs[2068]["type"]="sub"
g.vs[2069]["type"]="sub"
g.vs[2070]["type"]="sub"
g.vs[2071]["type"]="script"
g.vs[2072]["type"]="script"
g.vs[2073]["type"]="script"
g.vs[2074]["type"]="sub"
g.vs[2075]["type"]="sub"
g.vs[2076]["type"]="script"
g.vs[2077]["type"]="script"
g.vs[2078]["type"]="script"
g.vs[2079]["type"]="sub"
g.vs[2080]["type"]="sub"
g.vs[2081]["type"]="script"
g.vs[2082]["type"]="script"
g.vs[2083]["type"]="sub"
g.vs[2084]["type"]="sub"
g.vs[2085]["type"]="script"
g.vs[2086]["type"]="sub"
g.vs[2087]["type"]="sub"
g.vs[2088]["type"]="script"
g.vs[2089]["type"]="sub"
g.vs[2090]["type"]="script"
g.vs[2091]["type"]="sub"
g.vs[2092]["type"]="script"
g.vs[2093]["type"]="sub"
g.vs[2094]["type"]="sub"
g.vs[2095]["type"]="sub"
g.vs[2096]["type"]="script"
g.vs[2097]["type"]="script"
g.vs[2098]["type"]="sub"
g.vs[2099]["type"]="script"
g.vs[2100]["type"]="script"
g.vs[2101]["type"]="script"
g.vs[2102]["type"]="sub"
g.vs[2103]["type"]="sub"
g.vs[2104]["type"]="sub"
g.vs[2105]["type"]="sub"
g.vs[2106]["type"]="sub"
g.vs[2107]["type"]="sub"
g.vs[2108]["type"]="script"
g.vs[2109]["type"]="script"
g.vs[2110]["type"]="sub"
g.vs[2111]["type"]="sub"
g.vs[2112]["type"]="script"
g.vs[2113]["type"]="script"
g.vs[2114]["type"]="script"
g.vs[2115]["type"]="sub"
g.vs[2116]["type"]="sub"
g.vs[2117]["type"]="script"
g.vs[2118]["type"]="sub"
g.vs[2119]["type"]="sub"
g.vs[2120]["type"]="script"
g.vs[2121]["type"]="sub"
g.vs[2122]["type"]="sub"
g.vs[2123]["type"]="sub"
g.vs[2124]["type"]="script"
g.vs[2125]["type"]="sub"
g.vs[2126]["type"]="sub"
g.vs[2127]["type"]="script"
g.vs[2128]["type"]="sub"
g.vs[2129]["type"]="script"
g.vs[2130]["type"]="script"
g.vs[2131]["type"]="script"
g.vs[2132]["type"]="script"
g.vs[2133]["type"]="script"
g.vs[2134]["type"]="script"
g.vs[2135]["type"]="sub"
g.vs[2136]["type"]="sub"
g.vs[2137]["type"]="script"
g.vs[2138]["type"]="sub"
g.vs[2139]["type"]="script"
g.vs[2140]["type"]="sub"
g.vs[2141]["type"]="sub"
g.vs[2142]["type"]="sub"
g.vs[2143]["type"]="script"
g.vs[2144]["type"]="sub"
g.vs[2145]["type"]="script"
g.vs[2146]["type"]="sub"
g.vs[2147]["type"]="sub"
g.vs[2148]["type"]="sub"
g.vs[2149]["type"]="script"
g.vs[2150]["type"]="sub"
g.vs[2151]["type"]="sub"
g.vs[2152]["type"]="sub"
g.vs[2153]["type"]="script"
g.vs[2154]["type"]="script"
g.vs[2155]["type"]="sub"
g.vs[2156]["type"]="sub"
g.vs[2157]["type"]="sub"
g.vs[2158]["type"]="sub"
g.vs[2159]["type"]="sub"
g.vs[2160]["type"]="sub"
g.vs[2161]["type"]="sub"
g.vs[2162]["type"]="sub"
g.vs[2163]["type"]="script"
g.vs[2164]["type"]="script"
g.vs[2165]["type"]="script"
g.vs[2166]["type"]="script"
g.vs[2167]["type"]="sub"
g.vs[2168]["type"]="sub"
g.vs[2169]["type"]="sub"
g.vs[2170]["type"]="sub"
g.vs[2171]["type"]="script"
g.vs[2172]["type"]="sub"
g.vs[2173]["type"]="script"
g.vs[2174]["type"]="script"
g.vs[2175]["type"]="script"
g.vs[2176]["type"]="sub"
g.vs[2177]["type"]="sub"
g.vs[2178]["type"]="sub"
g.vs[2179]["type"]="script"
g.vs[2180]["type"]="sub"
g.vs[2181]["type"]="script"
g.vs[2182]["type"]="script"
g.vs[2183]["type"]="sub"
g.vs[2184]["type"]="sub"
g.vs[2185]["type"]="sub"
g.vs[2186]["type"]="sub"
g.vs[2187]["type"]="sub"
g.vs[2188]["type"]="script"
g.vs[2189]["type"]="sub"
g.vs[2190]["type"]="sub"
g.vs[2191]["type"]="sub"
g.vs[2192]["type"]="sub"
g.vs[2193]["type"]="sub"
g.vs[2194]["type"]="sub"
g.vs[2195]["type"]="sub"
g.vs[2196]["type"]="sub"
g.vs[2197]["type"]="sub"
g.vs[2198]["type"]="sub"
g.vs[2199]["type"]="sub"
g.vs[2200]["type"]="sub"
g.vs[2201]["type"]="sub"
g.vs[2202]["type"]="sub"
g.vs[2203]["type"]="sub"
g.vs[2204]["type"]="sub"
g.vs[2205]["type"]="sub"
g.vs[2206]["type"]="sub"
g.vs[2207]["type"]="sub"
g.vs[2208]["type"]="sub"
g.vs[2209]["type"]="sub"
g.vs[2210]["type"]="sub"
g.vs[2211]["type"]="sub"
g.vs[2212]["type"]="sub"
g.vs[2213]["type"]="sub"
g.vs[2214]["type"]="sub"
g.vs[2215]["type"]="sub"
g.vs[2216]["type"]="sub"
g.vs[2217]["type"]="sub"
g.vs[2218]["type"]="sub"
g.vs[2219]["type"]="sub"
g.vs[2220]["type"]="sub"
g.vs[2221]["type"]="sub"
g.vs[2222]["type"]="script"
g.vs[2223]["type"]="sub"
g.vs[2224]["type"]="sub"
g.vs[2225]["type"]="sub"
g.vs[2226]["type"]="sub"
g.vs[2227]["type"]="sub"
g.vs[2228]["type"]="sub"
g.vs[2229]["type"]="sub"
g.vs[2230]["type"]="sub"
g.vs[2231]["type"]="sub"
g.vs[2232]["type"]="sub"
g.vs[2233]["type"]="sub"
g.vs[2234]["type"]="sub"
g.vs[2235]["type"]="sub"
g.vs[2236]["type"]="sub"
g.vs[2237]["type"]="script"
g.vs[2238]["type"]="sub"
g.vs[2239]["type"]="sub"
g.vs[2240]["type"]="sub"
g.vs[2241]["type"]="sub"
g.vs[2242]["type"]="sub"
g.vs[2243]["type"]="sub"
g.vs[2244]["type"]="sub"
g.vs[2245]["type"]="sub"
g.vs[2246]["type"]="sub"
g.vs[2247]["type"]="sub"
g.vs[2248]["type"]="sub"
g.vs[2249]["type"]="sub"
g.vs[2250]["type"]="sub"
g.vs[2251]["type"]="sub"
g.vs[2252]["type"]="sub"
g.vs[2253]["type"]="sub"
g.vs[2254]["type"]="sub"
g.vs[2255]["type"]="sub"
g.vs[2256]["type"]="sub"
g.vs[2257]["type"]="sub"
g.vs[2258]["type"]="sub"
g.vs[2259]["type"]="sub"
g.vs[2260]["type"]="sub"
g.vs[2261]["type"]="sub"
g.vs[2262]["type"]="sub"
g.vs[2263]["type"]="sub"
g.vs[2264]["type"]="sub"
g.vs[2265]["type"]="sub"
g.vs[2266]["type"]="script"
g.vs[2267]["type"]="script"
g.vs[2268]["type"]="script"
g.vs[2269]["type"]="script"
g.vs[2270]["type"]="script"
g.vs[2271]["type"]="sub"


g3.vs["label"] = g3.vs["name"]
color_dict = {"m": "blue", "f": "pink"}
g3.vs["color"] = [color_dict[gender] for gender in g3.vs["gender"]]
plot(g3, layout = layout, bbox = (300, 300), margin = 20)


#g.vs["label"] = g.vs["name"]
color_dict = {"sub": "blue", "mod": "pink","script": "red","Notset": "gray" }
g.vs["color"] = [color_dict[type] for type in g.vs["type"]]


# Make very pretty
visual_style = {}
visual_style["vertex_size"] = 4
#visual_style["vertex_label_angle"] = 20
#visual_style["vertex_label_distance"] = 20
visual_style["vertex_color"] = [color_dict[type] for type in g.vs["type"]]
#visual_style["vertex_label"] = g.vs["name"]
visual_style["margin"] = 40
visual_style["vertex.label"]=None

plot(g, layout = layout, **visual_style)


#visual_style["edge_width"] = [1 + 2 * int(is_formal) for is_formal in g3.es["is_formal"]]
#visual_style["layout"] = layout
#visual_style["bbox"] = (300, 300)

plot(g, layout = layout, vertex.label=NA, **visual_style)




# Select a layout and plot - tree hierarchy
layout = g.layout("rt")
plot(g, layout = layout)


# Select a layout and plot
layout = g.layout("rt_circular")
plot(g, layout = layout)


# Select a layout and plot
layout = g.layout("large")
plot(g, layout = layout)


# Select a layout and plot
layout = g.layout("drl")
plot(g, layout = layout)



